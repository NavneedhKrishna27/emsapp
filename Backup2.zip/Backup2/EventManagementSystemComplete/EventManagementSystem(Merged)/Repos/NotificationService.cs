﻿using EventManagementSystemMerged.Data;
using EventManagementSystemMerged.Models;

namespace EventManagement_Merged_.Repos
{
    public class NotificationServices
    {
        public void SendNotification(int userId, int eventId, bool bookingStatus, string eventName, DateTime eventDate, string customMessage = null)
        {
            using (var context = new AppDbContext())
            {
                var message = customMessage ?? (bookingStatus
                    ? $"Your booking for {eventName} on {eventDate} is confirmed."
                    : $"Your booking for {eventName} on {eventDate} failed.");

                var notification = new Notification
                {
                    UserID = userId,
                    EventID = eventId,
                    Message = message,
                    SentTimestamp = DateTime.Now
                };

                SaveNotification(notification);
            }
        }


        public List<Notification> GetNotificationsByUserId(int userId)
        {
            using (var context = new AppDbContext())
            {
                return context.Notifications
                    .Where(n => n.UserID == userId)
                    .OrderByDescending(n => n.SentTimestamp) // Sort by the most recent notifications
                    .ToList();
            }
        }



        private void SaveNotification(Notification notification)
        {
            using (var context = new AppDbContext())
            {
                context.Notifications.Add(notification);
                context.SaveChanges();
            }
        }


    }
}

