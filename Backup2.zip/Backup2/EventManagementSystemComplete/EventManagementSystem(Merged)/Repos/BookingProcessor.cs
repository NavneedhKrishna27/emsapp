﻿
using EventManagement_Merged_.Repos;
using EventManagementSystemMerged.Data;
using EventManagementSystemMerged.Models;
using System;
using System.Linq;

namespace EventManagementSystemMerged.Repo
{
    public class BookingProcessor
    {
        private readonly NotificationServices _notificationService;

        public BookingProcessor()
        {
            _notificationService = new NotificationServices();
        }

        public string ProcessTicketBooking(int userId, int eventId, int ticketCount)
        {
            using (var context = new AppDbContext())
            {
                var eventEntity = context.Events.Find(eventId);
                var location = context.Locations.Find(eventEntity.LocationID);

                if (DateTime.Now > eventEntity.EndDate)
                {
                    return "Cannot book the event as it is already completed.";
                }

                if (eventEntity.BookedCapacity + ticketCount > location.Capacity)
                {
                    return "Capacity is full. Cannot book the ticket for the event.";
                }

                decimal amount = GetEventPrice(eventId) * ticketCount;
                bool paymentStatus = true;

                if (paymentStatus)
                {
                    var ticket = new Ticket
                    {
                        UserID = userId,
                        EventID = eventId,
                        BookingDate = DateTime.Now,
                        Status = "Confirmed",
                        TicketCount = ticketCount
                    };

                    var payment = new Payment
                    {
                        UserID = userId,
                        EventID = eventId,
                        Amount = amount,
                        PaymentDate = DateTime.Now,
                        PaymentStatus = true
                    };

                    context.Tickets.Add(ticket);
                    context.Payments.Add(payment);

                    eventEntity.BookedCapacity += ticketCount;
                    context.SaveChanges();

                    var eventName = GetEventName(eventId);
                    var eventDate = GetEventStartDate(eventId);

                    // Send booking notification
                    _notificationService.SendNotification(userId, eventId, true, eventName, eventDate, $"Your booking for {eventName} on {eventDate} has been confirmed.");

                    return "Booking processed successfully.";
                }
                else
                {
                    var eventName = GetEventName(eventId);
                    var eventDate = GetEventStartDate(eventId);

                    // Send failed booking notification
                    _notificationService.SendNotification(userId, eventId, false, eventName, eventDate, $"Your booking for {eventName} on {eventDate} failed due to payment issues.");

                    return "Payment failed. Booking not processed.";
                }
            }
        }

        public string? GetBookingStatus(int userId, int eventId)
        {
            using (var context = new AppDbContext())
            {
                var ticket = context.Tickets.FirstOrDefault(t => t.UserID == userId && t.EventID == eventId);
                return ticket?.Status; // Return the status if the ticket exists, otherwise null
            }
        }

        public string? GetLatestBookingStatus(int userId, int eventId)
        {
            using (var context = new AppDbContext())
            {
                var ticket = context.Tickets
                    .Where(t => t.UserID == userId && t.EventID == eventId)
                    .OrderByDescending(t => t.BookingDate) // Ensure the latest booking is fetched
                    .FirstOrDefault();

                return ticket?.Status; // Return the status if the ticket exists, otherwise null
            }
        }

        public string CancelTicketBooking(int userId, int eventId)
        {
            using (var context = new AppDbContext())
            {
                // Find the ticket for the given user and event with a "Confirmed" status
                var ticket = context.Tickets.FirstOrDefault(t => t.UserID == userId && t.EventID == eventId && t.Status == "Confirmed");
                if (ticket == null)
                {
                    return "No confirmed booking found for the given user and event.";
                }

                // Update the ticket status to "Cancelled" but keep the ticket count unchanged
                ticket.Status = "Cancelled";

                // Find the event associated with the ticket
                var eventEntity = context.Events.Find(eventId);
                if (eventEntity != null)
                {
                    // Reduce the booked capacity of the event by the ticket count
                    eventEntity.BookedCapacity -= ticket.TicketCount;
                    if (eventEntity.BookedCapacity < 0)
                    {
                        eventEntity.BookedCapacity = 0; // Ensure booked capacity does not go below zero
                    }
                }

                // Save changes to the database
                context.SaveChanges();

                // Retrieve event details for the notification
                var eventName = GetEventName(eventId);
                var eventDate = GetEventStartDate(eventId);

                // Send cancellation notification to the user
                _notificationService.SendNotification(userId, eventId, false, eventName, eventDate, $"Your booking for {eventName} on {eventDate} has been cancelled.");

                return "Booking cancelled successfully.";
            }
        }





        private decimal GetEventPrice(int eventId)
        {
            using (var context = new AppDbContext())
            {
                var eventEntity = context.Events.Find(eventId);
                return eventEntity?.Price ?? 0;
            }
        }

        private string GetEventName(int eventId)
        {
            using (var context = new AppDbContext())
            {
                var eventEntity = context.Events.Find(eventId);
                return eventEntity?.Name ?? "Unknown Event";
            }
        }

        private DateTime GetEventStartDate(int eventId)
        {
            using (var context = new AppDbContext())
            {
                var eventEntity = context.Events.Find(eventId);
                return eventEntity?.StartDate ?? DateTime.MinValue;
            }
        }
    }
}