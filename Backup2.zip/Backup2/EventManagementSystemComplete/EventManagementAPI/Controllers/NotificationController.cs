﻿using EventManagement_Merged_.Repos;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NotificationController : ControllerBase
    {
        private readonly NotificationServices _notificationServices;

        public NotificationController()
        {
            _notificationServices = new NotificationServices();
        }

        [HttpGet("user/{userId}")]
        public IActionResult GetNotificationsByUserId(int userId)
        {
            if (userId <= 0)
            {
                return BadRequest("Invalid user ID.");
            }

            var notifications = _notificationServices.GetNotificationsByUserId(userId);
            if (notifications == null || !notifications.Any())
            {
                return NotFound(new { message = "No notifications found for the given user." });
            }

            return Ok(notifications);
        }
    }

}
