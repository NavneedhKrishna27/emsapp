﻿
using EventManagementSystem_Merged_.Repos;
using EventManagementSystemMerged.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketController : ControllerBase
    {
        private readonly TicketService _ticketService;

        public TicketController(TicketService ticketService)
        {
            _ticketService = ticketService;
        }

        [HttpGet]
        public ActionResult<List<Ticket>> GetTickets()
        {
            var tickets = _ticketService.GetAllTickets();
            return Ok(tickets);
        }

        [HttpGet("{ticketId}")]
        public ActionResult<Ticket> GetTicketId(int ticketId)
        {
            var ticket = _ticketService.GetTicketById(ticketId);
            if (ticket == null)
            {
                return NotFound(new { message = "Ticket not found" });
            }
            return Ok(ticket);
        }

        [HttpGet("tickets-sold/{eventId}")]
        public ActionResult<int> GetTicketsSold(int eventId)
        {
            var ticketsSold = _ticketService.GetNumberOfTicketsSold(eventId);
            return Ok(ticketsSold);
        }

        [HttpPost]
        public IActionResult AddTicket([FromBody] Ticket ticket)
        {
            _ticketService.AddTicket(ticket);
            return Ok(new { message = "Ticket added successfully." });
        }

        [HttpPut("{ticketId}")]
        public IActionResult UpdateTicket(int ticketId, [FromBody] Ticket ticket)
        {
            var existingTicket = _ticketService.GetTicketById(ticketId);
            if (existingTicket == null)
            {
                return NotFound(new { message = "Ticket not found" });
            }

            existingTicket.TicketCount = ticket.TicketCount;
            _ticketService.UpdateTicket(existingTicket);

            return Ok(new { message = "Ticket updated successfully." });
        }

        [HttpGet("participants/{eventId}")]
        public ActionResult<List<User>> GetParticipants(int eventId)
        {
            var participants = _ticketService.GetParticipants(eventId);
            return Ok(participants);
        }
        [HttpGet("user/{userId}")]
        public ActionResult<List<Ticket>> GetTicketsByUserId(int userId)
        {
            var tickets = _ticketService.GetTicketsByUserId(userId);
            if (tickets == null || tickets.Count == 0)
            {
                return NotFound(new { message = "No tickets found for the specified user." });
            }
            return Ok(tickets);
        }

        [HttpGet("event/{eventId}/user/{userId}")]
        public ActionResult<Ticket> GetTicketByEventAndUser(int eventId, int userId)
        {
            var ticket = _ticketService.GetTicketByEventAndUser(eventId, userId);
            if (ticket == null)
            {
                return NotFound(new { message = "No ticket found for the specified event and user." });
            }
            return Ok(ticket);
        }
        [HttpGet("details/{ticketId}")]
        public ActionResult<object> GetTicketDetails(int ticketId)
        {
            var ticketDetails = _ticketService.GetTicketDetails(ticketId);
            if (ticketDetails == null)
            {
                return NotFound(new { message = "Ticket details not found." });
            }
            return Ok(ticketDetails);
        }
        [HttpGet("status/{ticketId}")]
        public ActionResult<string> GetTicketStatus(int ticketId)
        {
            var ticketStatus = _ticketService.GetTicketStatus(ticketId);
            if (ticketStatus == null)
            {
                return NotFound(new { message = "Ticket not found or status unavailable." });
            }
            return Ok(ticketStatus);
        }




    }
}