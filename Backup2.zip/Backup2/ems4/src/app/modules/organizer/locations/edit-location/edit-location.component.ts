import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}
@Component({
  selector: 'app-edit-location',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-location.component.html',
  styleUrls: ['./edit-location.component.css']
})
export class EditLocationComponent implements OnInit {
  locationForm!: FormGroup;
  locationId!: number;
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.initForm();
    this.locationId = Number(this.route.snapshot.paramMap.get('id'));
    this.fetchLocation();
  }

  private initForm() {
    this.locationForm = this.fb.group({
      locationName: ['', [Validators.required, Validators.minLength(3)]],
      capacity: ['', [Validators.required, Validators.min(1)]],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      postalCode: ['', Validators.required],
      primaryContact: ['', [Validators.required, Validators.pattern('^[+]?[0-9-]+$')]],
      secondaryContact: ['', Validators.pattern('^[+]?[0-9-]+$')]
    });
  }

  private fetchLocation() {
    this.http.get<Location>(`${this.baseUrl}/Location/${this.locationId}`)
      .subscribe({
        next: (location) => {
          this.locationForm.patchValue(location);
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load location';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  onSubmit() {
    if (this.locationForm.valid) {
      const updatedLocation = {
        ...this.locationForm.value,
        locationID: this.locationId
      };

      this.http.put(`${this.baseUrl}/Location/${this.locationId}`, updatedLocation)
        .subscribe({
          next: () => {
            this.router.navigate(['/organizer/locations']);
          },
          error: (error) => {
            this.error = 'Failed to update location';
            console.error('Error:', error);
          }
        });
    }
  }

  onCancel() {
    this.router.navigate(['/organizer/locations']);
  }
}
