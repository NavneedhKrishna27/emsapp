import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';
import * as XLSX from 'xlsx';

interface Event {
  eventID: number;
  name: string;
  startDate: string;
  endDate: string;
  isPrice: boolean;
  price: number;
  bookedCapacity: number;
  locationID: number;
}

interface EventReport {
  eventId: number;
  eventName: string;
  ticketsSold: number;
  totalTickets: number;
  revenue: number;
  targetRevenue: number;
  profit: number;
  targetProfit: number;
  feedbacks: Feedback[];
  status: 'Upcoming' | 'Active' | 'Completed';
  startDate: string;
  endDate: string;
  totalRevenue: number;
  averageTicketPrice: number;
  bookingRate: number;
  peakBookingTime?: string;
  categoryName?: string;
  locationDetails: {
    name: string;
    address: string;
    capacity: number;
    utilization: number;
  };
  statistics: {
    dailyBookings: { date: string; count: number }[];
    revenueByDay: { date: string; amount: number }[];
  };
}

interface Feedback {
  customerName: string;
  rating: number;
  comment: string;
  date: string;
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, NgSelectModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  selectedEventId: number | null = null;
  events: Event[] = [];
  eventReport: EventReport | null = null;
  loading = false;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';
  searchTerm: string = '';
  defaultEventId: number = 1; // Set your default event ID

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEvents();
    // Load default event
    if (this.defaultEventId) {
      this.fetchEventReport(this.defaultEventId);
    }
  }

  fetchEvents() {
    this.loading = true;
    this.http.get<Event[]>(`${this.baseUrl}/Event/index`).subscribe({
      next: (events) => {
        if (!events || events.length === 0) {
          this.error = 'No events found';
        } else {
          this.events = events;
          this.error = null;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching events:', error);
        this.error = 'Failed to load events. Please try again later.';
        this.loading = false;
      }
    });
  }

  onEventChange(selectedEvent: any) {
    if (selectedEvent) {
      this.loading = true;
      this.selectedEventId = selectedEvent.eventID;
      this.fetchEventReport(selectedEvent.eventID);
    } else {
      this.eventReport = null;
    }
  }

  private async fetchEventReport(eventId: number) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/Event/view-event/${eventId}`).toPromise();
      if (!event) throw new Error('Event not found');

      // Get location and tickets sold
      const [location, ticketsSold] = await Promise.all([
        this.http.get<any>(`${this.baseUrl}/Location/${event.locationID}`).toPromise(),
        this.http.get<number>(`${this.baseUrl}/Ticket/tickets-sold/${eventId}`).toPromise()
      ]);

      // Calculate utilization and revenue
      const soldTickets = ticketsSold || 0;
      const venueCapacity = location?.capacity || 0;
      const utilization = venueCapacity > 0 ? (soldTickets / venueCapacity) * 100 : 0;
      const revenue = event.isPrice ? soldTickets * event.price : 0;
      const targetRevenue = event.isPrice ? event.price * venueCapacity : 0;

      this.eventReport = {
        eventId: event.eventID,
        eventName: event.name,
        ticketsSold: soldTickets,
        totalTickets: venueCapacity,
        revenue: revenue,
        targetRevenue: targetRevenue,
        profit: revenue * 0.7,
        targetProfit: targetRevenue * 0.7,
        status: this.getEventStatus(event),
        startDate: event.startDate,
        endDate: event.endDate,
        totalRevenue: revenue,
        averageTicketPrice: event.price,
        bookingRate: utilization,
        locationDetails: {
          name: location.locationName,
          address: location.address,
          capacity: venueCapacity,
          utilization: utilization
        },
        statistics: {
          dailyBookings: [],
          revenueByDay: []
        },
        feedbacks: []
      };

      // Fetch feedbacks if needed
      if (this.eventReport.status === 'Completed') {
        try {
          const feedbacks = await this.http.get<any[]>(`${this.baseUrl}/Feedback/Get-feedbacks-by-eventid/${eventId}`).toPromise();
          if (feedbacks) {
            this.eventReport.feedbacks = feedbacks.map(f => ({
              customerName: `Customer ${f.userID}`,
              rating: f.rating,
              comment: f.comments,
              date: f.submittedTimestamp
            }));
          }
        } catch (error) {
          console.log('No feedback data available');
        }
      }

    } catch (error) {
      console.error('Error fetching report:', error);
      this.error = 'Failed to load report';
    } finally {
      this.loading = false;
    }
  }

  getEventStatus(event: Event): 'Upcoming' | 'Active' | 'Completed' {
    const now = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getProgressClass(percentage: number): string {
    if (percentage >= 90) return 'bg-success';
    if (percentage >= 60) return 'bg-info';
    if (percentage >= 30) return 'bg-warning';
    return 'bg-danger';
  }

  getProgressBarClass(percentage: number): string {
    if (percentage >= 90) {
      return 'bg-success';
    } else if (percentage >= 60) {
      return 'bg-info';
    } else if (percentage >= 30) {
      return 'bg-warning';
    } else {
      return 'bg-danger';
    }
  }

  downloadReport() {
    if (!this.eventReport) return;

    // Prepare data for Excel
    const reportData = [
      ['Event Report', ''],
      ['Generated Date', new Date().toLocaleString()],
      ['', ''],
      ['Event Details', ''],
      ['Event Name', this.eventReport.eventName],
      ['Status', this.eventReport.status],
      ['Start Date', new Date(this.eventReport.startDate).toLocaleDateString()],
      ['End Date', new Date(this.eventReport.endDate).toLocaleDateString()],
      ['', ''],
      ['Ticket Statistics', ''],
      ['Total Tickets', this.eventReport.totalTickets],
      ['Tickets Sold', this.eventReport.ticketsSold],
      ['Booking Rate', `${this.eventReport.bookingRate.toFixed(2)}%`],
      ['', ''],
      ['Financial Statistics', ''],
      ['Total Revenue', `$${this.eventReport.revenue.toFixed(2)}`],
      ['Target Revenue', `$${this.eventReport.targetRevenue.toFixed(2)}`],
      ['Profit', `$${this.eventReport.profit.toFixed(2)}`],
      ['Target Profit', `$${this.eventReport.targetProfit.toFixed(2)}`],
      ['Average Ticket Price', `$${this.eventReport.averageTicketPrice.toFixed(2)}`],
      ['', ''],
      ['Location Details', ''],
      ['Venue Name', this.eventReport.locationDetails.name],
      ['Address', this.eventReport.locationDetails.address],
      ['Capacity', this.eventReport.locationDetails.capacity],
      ['Utilization', `${this.eventReport.locationDetails.utilization.toFixed(2)}%`],
      ['', ''],
    ];

    // Add feedback section if available
    if (this.eventReport.feedbacks.length > 0) {
      reportData.push(['Feedback Summary', '']);
      reportData.push(['Customer', 'Rating', 'Comment', 'Date']);
      this.eventReport.feedbacks.forEach(feedback => {
        reportData.push([
          feedback.customerName,
          feedback.rating.toString(),
          feedback.comment,
          new Date(feedback.date).toLocaleString()
        ]);
      });
    }

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(reportData);

    // Set column widths
    const colWidths = [{ wch: 20 }, { wch: 50 }];
    ws['!cols'] = colWidths;

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Event Report');

    // Generate Excel file
    XLSX.writeFile(wb, `event-report-${this.eventReport.eventId}.xlsx`);
  }

  getTicketProgress(): number {
    if (!this.eventReport || !this.eventReport.totalTickets) return 0;
    return (this.eventReport.ticketsSold / this.eventReport.totalTickets) * 100;
  }

  getRevenueProgress(): number {
    if (!this.eventReport || !this.eventReport.targetRevenue) return 0;
    return (this.eventReport.revenue / this.eventReport.targetRevenue) * 100;
  }

  getProfitProgress(): number {
    if (!this.eventReport || !this.eventReport.targetProfit) return 0;
    return (this.eventReport.profit / this.eventReport.targetProfit) * 100;
  }

  getRatingStars(rating: number): string[] {
    return Array(5).fill(0).map((_, index) =>
      index < rating ? 'bi-star-fill' : 'bi-star');
  }

  get filteredEvents() {
    return this.events.filter(event =>
      event.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  onSearch(searchTerm: string) {
    if (searchTerm) {
      this.loading = true;
      const filteredEvents = this.events.filter(event =>
        event.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      this.events = filteredEvents;
      this.loading = false;
    } else {
      this.fetchEvents();
    }
  }
}
