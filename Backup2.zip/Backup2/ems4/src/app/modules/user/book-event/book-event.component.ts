import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { UserService } from '../../../services/UserService';
import { TicketResponse } from '../../../model/interface/TicketResponse';
import Swal from 'sweetalert2'; // Import SweetAlert2 for nice notifications

@Component({
  selector: 'app-book-event',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './book-event.component.html',
  styleUrls: ['./book-event.component.css']
})
export class BookEventComponent implements OnInit {
  bookingForm: FormGroup;
  eventId: number;
  loading = false;
  error: string | null = null;
  ticketCount: number = 1;
  eventDetails: any = null;
  paymentInProgress: boolean = false;
  hasExistingBooking: boolean = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService
  ) {
    this.eventId = Number(this.route.snapshot.paramMap.get('id'));
    this.ticketCount = Number(this.route.snapshot.queryParamMap.get('tickets')) || 1;

    this.bookingForm = this.fb.group({
      ticketCount: [this.ticketCount, [Validators.required, Validators.min(1), Validators.max(10)]]
    });

    this.bookingForm.get('ticketCount')?.valueChanges.subscribe(value => {
      this.ticketCount = value;
    });
  }

  ngOnInit() {
    if (!this.userService.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }

    const user = this.userService.getCurrentUser();
    if (user) {
      // Check if user has already booked this event
      this.checkExistingBooking(user.userID);
    }

    // Fetch event details
    this.http.get<any>(`https://localhost:7149/api/Event/view-event/${this.eventId}`)
      .subscribe({
        next: (event) => {
          this.eventDetails = event;
        },
        error: (error) => {
          this.error = 'Failed to load event details';
          console.error(error);
        }
      });
  }

  onSubmit() {
    if (this.bookingForm.valid) {
      const user = this.userService.getCurrentUser();
      if (!user) {
        this.error = 'Please login to book tickets';
        return;
      }

      const bookingData = {
        userID: user.userID,
        eventID: this.eventId,
        ticketCount: this.bookingForm.get('ticketCount')?.value
      };

      this.loading = true;
      this.http.post('https://localhost:7149/api/Booking/book', bookingData)
        .subscribe({
          next: () => {
            this.loading = false;
            this.router.navigate(['/events', this.eventId]);
          },
          error: (error) => {
            this.loading = false;
            this.error = error.error || 'Failed to book tickets';
          }
        });
    }
  }

  private checkExistingBooking(userId: number) {
    this.http.get<any>(`https://localhost:7149/api/Booking/check/${userId}/${this.eventId}`)
      .subscribe({
        next: (response) => {
          if (response.bookingStatus === 'Confirmed') {
            this.hasExistingBooking = true;
            Swal.fire({
              icon: 'warning',
              title: 'Already Booked',
              text: 'You have already booked tickets for this event.',
              confirmButtonText: 'View My Tickets',
              showCancelButton: true,
              cancelButtonText: 'Close'
            }).then((result) => {
              if (result.isConfirmed) {
                this.router.navigate(['/tickets']);
              } else {
                this.router.navigate(['/events']);
              }
            });
          }
        },
        error: (error) => {
          console.error('Error checking booking status:', error);
        }
      });
  }

  processPayment() {
    if (this.hasExistingBooking) {
      Swal.fire({
        icon: 'warning',
        title: 'Already Booked',
        text: 'You have already booked tickets for this event.'
      });
      return;
    }

    this.paymentInProgress = true;
    const user = this.userService.getCurrentUser();

    if (!user || !this.eventDetails) {
      this.error = 'Unable to process payment';
      this.paymentInProgress = false;
      return;
    }

    const paymentData = {
      userID: user.userID,
      eventID: this.eventId,
      ticketCount: this.ticketCount
    };

    // First make the booking request
    this.http.post('https://localhost:7149/api/Booking/book', paymentData, { observe: 'response' })
      .subscribe({
        next: (response) => {
          // Check the booking status after successful booking
          setTimeout(() => {
            this.http.get<any>(`https://localhost:7149/api/Booking/check/${user.userID}/${this.eventId}`)
              .subscribe({
                next: (checkResponse) => {
                  this.paymentInProgress = false;
                  if (checkResponse.bookingStatus === 'Confirmed') {
                    Swal.fire({
                      icon: 'success',
                      title: 'Booking Successful!',
                      text: 'Your tickets have been booked successfully.',
                      showConfirmButton: true,
                      confirmButtonText: 'View My Tickets'
                    }).then((result) => {
                      if (result.isConfirmed) {
                        this.router.navigate(['/tickets']);
                      }
                    });
                  }
                },
                error: () => {
                  // Even if status check fails, assume booking was successful
                  this.paymentInProgress = false;
                  Swal.fire({
                    icon: 'success',
                    title: 'Booking Successful!',
                    text: 'Your tickets have been booked successfully.',
                    showConfirmButton: true,
                    confirmButtonText: 'View My Tickets'
                  }).then((result) => {
                    if (result.isConfirmed) {
                      this.router.navigate(['/tickets']);
                    }
                  });
                }
              });
          }, 1000); // Small delay to ensure booking is processed
        },
        error: (error) => {
          this.paymentInProgress = false;
          // If we get a 200-299 status code, treat it as success despite parsing error
          if (error.status >= 200 && error.status < 300) {
            Swal.fire({
              icon: 'success',
              title: 'Booking Successful!',
              text: 'Your tickets have been booked successfully.',
              showConfirmButton: true,
              confirmButtonText: 'View My Tickets'
            }).then((result) => {
              if (result.isConfirmed) {
                this.router.navigate(['/tickets']);
              }
            });
          } else {
            // Real error case
            const errorMessage = typeof error.error === 'string' ? error.error : 'An unexpected error occurred';
            Swal.fire({
              icon: 'error',
              title: 'Booking Failed',
              text: errorMessage
            });
          }
        }
      });
  }

  // Add this new method to verify booking status
  private checkBookingStatus(userId: number) {
    this.http.get<any>(`https://localhost:7149/api/Booking/check/${userId}/${this.eventId}`)
      .subscribe({
        next: (response) => {
          if (response.bookingStatus === 'Confirmed') {
            Swal.fire({
              icon: 'success',
              title: 'Booking Successful!',
              text: 'Your tickets have been booked successfully.',
              showConfirmButton: false,
              timer: 2000
            }).then(() => {
              this.router.navigate(['/tickets'], {
                state: { fromBooking: true }
              });
            });
          }
        },
        error: (error) => {
          console.error('Error verifying booking:', error);
        }
      });
  }

  // Add helper method for total amount
  getTotalAmount(): number {
    if (!this.eventDetails?.price || !this.ticketCount) {
      return 0;
    }
    return this.eventDetails.price * this.ticketCount;
  }
}
