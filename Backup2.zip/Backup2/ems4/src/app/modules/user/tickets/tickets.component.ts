import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../../../services/UserService';
import { RouterLink } from '@angular/router';

import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import { Ticket } from '../../../model/interface/Ticket';

@Component({
  selector: 'app-tickets',
  standalone: true,
  imports: [CommonModule, RouterLink, DatePipe],
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.css']
})
export class TicketsComponent implements OnInit {
  tickets: Ticket[] = [];
  loading = true;
  error: string | null = null;
  sortField: string = 'bookingDate';
  sortDirection: 'asc' | 'desc' = 'desc';

  constructor(
    private http: HttpClient,
    private userService: UserService
  ) {}

  ngOnInit() {
    this.loadTickets();
  }

  private loadTickets() {
    const user = this.userService.getCurrentUser();
    if (!user) {
      this.error = 'Please login to view tickets';
      this.loading = false;
      return;
    }

    this.loading = true;
    this.http.get<Ticket[]>(`https://localhost:7149/api/Ticket/user/${user.userID}`)
      .subscribe({
        next: (response) => {
          this.tickets = this.sortTickets(response);
          this.loading = false;

          if (history.state.fromBooking) {
            Swal.fire({
              icon: 'success',
              title: 'Welcome to Your Tickets!',
              text: 'Here are your booking details.',
              timer: 2000
            });
          }
        },
        error: (error) => {
          this.error = 'Failed to load tickets';
          this.loading = false;
        }
      });
  }

  sortTickets(tickets: Ticket[]): Ticket[] {
    return tickets.sort((a, b) => {
      let comparison = 0;
      switch (this.sortField) {
        case 'bookingDate':
          comparison = new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime();
          break;
        case 'status':
          comparison = a.status.localeCompare(b.status);
          break;
        case 'eventDate':
          comparison = new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime();
          break;
        default:
          comparison = new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime();
      }
      return this.sortDirection === 'asc' ? -comparison : comparison;
    });
  }

  changeSorting(field: string) {
    if (this.sortField === field) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = field;
      this.sortDirection = 'desc';
    }
    this.tickets = this.sortTickets([...this.tickets]);
  }

  getStatusClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'confirmed':
        return 'status-confirmed';
      case 'cancelled':
        return 'status-cancelled';
      case 'pending':
        return 'status-pending';
      default:
        return '';
    }
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
