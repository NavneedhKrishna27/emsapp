import { Component, EventEmitter, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { EventFilterService } from '../../../services/event-filter.service';
import { FormsModule } from '@angular/forms';

interface Location {
  locationID: number;
  locationName: string;
}

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  template: `
    <header class="header">
      <div class="header-content">
        <div class="header-left">
          <button class="menu-toggle" (click)="toggleSidenav.emit()">
            <i class="bi bi-list"></i>
          </button>
          <div class="brand">
            <i class="bi bi-calendar-event-fill"></i>
            <span>Eventify</span>
          </div>
        </div>

        <div class="header-right">
          <div class="location-picker">
            <i class="bi bi-geo-alt"></i>
            <select [(ngModel)]="selectedLocationId" (change)="onLocationChange()">
              <option [ngValue]="null">All Locations</option>
              <option *ngFor="let location of locations" [ngValue]="location.locationID">
                {{location.locationName}}
              </option>
            </select>
          </div>

          <div class="notifications">
            <button class="notification-btn" [class.has-notifications]="true">
              <i class="bi bi-bell"></i>
              <span class="notification-badge">3</span>
            </button>
          </div>

          <div class="user-profile">
            <img src="assets/avatar.png" alt="User" class="avatar">
          </div>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .header {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 64px;
      background: #ffffff;
      box-shadow: 0 2px 4px rgba(0,0,0,0.08);
      z-index: 1000;
    }

    .header-content {
      display: flex;
      justify-content: space-between;
      align-items: center;
      height: 100%;
      padding: 0 1.5rem;
    }

    .header-left {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .menu-toggle {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #1a1a1a;
      cursor: pointer;
      padding: 0.5rem;
      border-radius: 8px;
      transition: background-color 0.2s;
    }

    .menu-toggle:hover {
      background-color: #f5f5f5;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      font-size: 1.25rem;
      font-weight: 600;
      color: #1a1a1a;
    }

    .brand i {
      color: #3498db;
    }

    .header-right {
      display: flex;
      align-items: center;
      gap: 1.5rem;
    }

    .location-picker {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: #f8f9fa;
      padding: 0.5rem 1rem;
      border-radius: 8px;
    }

    .location-picker i {
      color: #3498db;
    }

    .location-picker select {
      border: none;
      background: none;
      outline: none;
      color: #1a1a1a;
      font-size: 0.9rem;
    }

    .notifications {
      position: relative;
    }

    .notification-btn {
      background: none;
      border: none;
      font-size: 1.25rem;
      padding: 0.5rem;
      border-radius: 8px;
      color: #1a1a1a;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .notification-btn:hover {
      background-color: #f5f5f5;
    }

    .notification-badge {
      position: absolute;
      top: 0;
      right: 0;
      background: #e74c3c;
      color: white;
      font-size: 0.75rem;
      padding: 0.25rem 0.5rem;
      border-radius: 12px;
      min-width: 20px;
      text-align: center;
    }

    .user-profile {
      padding: 0.25rem;
    }

    .avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      object-fit: cover;
    }
  `]
})
export class HeaderComponent implements OnInit {
  @Output() toggleSidenav = new EventEmitter<void>();
  locations: Location[] = [];
  selectedLocationId: number | null = null;

  constructor(
    private http: HttpClient,
    private eventFilterService: EventFilterService,
    private router: Router
  ) {}

  ngOnInit() {
    this.fetchLocations();
  }

  private async fetchLocations() {
    try {
      const response = await this.http.get<Location[]>('https://localhost:7149/api/Location').toPromise();
      this.locations = response || [];
    } catch (error) {
      console.error('Error fetching locations:', error);
    }
  }

  onLocationChange() {
    this.eventFilterService.updateSelectedLocation(this.selectedLocationId);

    // If currently on events page, trigger refresh
    // If not on events page, navigate to events page with selected location
    if (!this.router.url.includes('/events')) {
      this.router.navigate(['/events']);
    }
  }
}
