import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router, RouterLink, NavigationEnd } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { UserService } from '../../../../services/UserService';
import { filter } from 'rxjs/operators';

declare var bootstrap: any;

interface Event {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  locationID: number;
  categoryID: number;
  price: number;
  isPrice: boolean;
  bookedCapacity: number;
  thumbnailUrl?: string;
  image1Url?: string;
  image2Url?: string;
  image3Url?: string;
  image4Url?: string;
  locationName?: string;
  categoryName?: string;
}

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}

interface EventStats {
  totalCapacity: number;
  registeredCount: number;
  remainingCapacity: number;
}

interface Feedback {
  feedbackID: number;
  eventID: number;
  userID: number;
  rating: number;
  comment: string;
  userName: string;
  createdAt: string;
}

interface RatingCounts {
  [key: string]: number;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

@Component({
  selector: 'app-view-event',
  standalone: true,
  imports: [CommonModule, RouterLink],
  providers: [UserService],
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.css'],
})
export class ViewEventComponent implements OnInit, AfterViewInit, OnDestroy {
  event: Event | null = null;
  location: Location | null = null;
  stats: EventStats | null = null;
  feedbacks: Feedback[] = [];
  timeUntilEvent: string = '';
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149';
  private carousel: any;
  private timerInterval: any;
  private routerSubscription: any;

  averageRating: number = 0;
  ratingCounts: RatingCounts = {};
  ticketsSold: number = 0;
  category: Category | null = null;
  hasBooked: boolean = false;

  ticketCount: number = 1;
  readonly maxTickets = 10;

  private timeLeft: { days: number; hours: number; minutes: number; seconds: number } = {
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private userService: UserService
  ) {
    // Add router event subscription
    this.routerSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(() => {
      this.refreshData();
    });
  }

  ngOnInit() {
    const eventId = this.route.snapshot.paramMap.get('id');
    if (eventId) {
      this.fetchEventDetails(eventId).then(() => {
        if (this.event && !this.isEventCompleted()) {
          this.startEventTimer();
        }
      });
      this.fetchEventStats(eventId);
      this.fetchLocation(eventId);
      this.fetchCategory(eventId);
      this.fetchTicketsSold(eventId);
      if (this.isEventCompleted()) {
        this.fetchFeedbacks(eventId);
        this.fetchRatingCounts(eventId);
        this.fetchAverageRating();
      }
      this.checkUserBooking();
    }
  }

  ngAfterViewInit() {
    setTimeout(() => {
      const carouselElement = document.getElementById('eventImageCarousel');
      if (carouselElement && typeof bootstrap !== 'undefined') {
        this.carousel = new bootstrap.Carousel(carouselElement, {
          interval: false, // Disable auto-play
          wrap: true, // Allow wrapping
          keyboard: true, // Enable keyboard controls
          pause: 'hover', // Pause on hover
        });
      }
    }, 100);
  }

  ngOnDestroy() {
    // Clean up subscriptions
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  private async fetchEventDetails(eventId: string) {
    try {
      this.loading = true;
      this.event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise() || null;
    } catch (error) {
      console.error('Error fetching event details:', error);
      this.error = 'Failed to load event details';
    } finally {
      this.loading = false;
    }
  }

  private async fetchEventStats(eventId: string) {
    try {
      this.stats = await this.http.get<EventStats>(`${this.baseUrl}/api/Event/stats/${eventId}`).toPromise() || null;
    } catch (error) {
      console.error('Error fetching event stats:', error);
    }
  }

  private async fetchLocation(eventId: string) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise();
      if (event?.locationID) {
        this.location = await this.http.get<Location>(`${this.baseUrl}/api/Location/${event.locationID}`).toPromise() || null;
      }
    } catch (error) {
      console.error('Error fetching location:', error);
    }
  }

  private async fetchCategory(eventId: string) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise();
      if (event?.categoryID) {
        this.category = await this.http.get<Category>(`${this.baseUrl}/api/Categories/${event.categoryID}`).toPromise() || null;
      }
    } catch (error) {
      console.error('Error fetching category:', error);
    }
  }

  private async fetchTicketsSold(eventId: string) {
    try {
      this.ticketsSold = await this.http.get<number>(`${this.baseUrl}/api/Ticket/tickets-sold/${eventId}`).toPromise() || 0;
    } catch (error) {
      console.error('Error fetching tickets sold:', error);
      this.ticketsSold = 0;
    }
  }

  private async fetchFeedbacks(eventId: string) {
    try {
      this.feedbacks = await this.http.get<Feedback[]>(`${this.baseUrl}/api/Feedback/Get-feedbacks-by-eventid/${eventId}`).toPromise() || [];
    } catch (error) {
      console.error('Error fetching feedbacks:', error);
    }
  }

  private async fetchRatingCounts(eventId: string) {
    try {
      this.ratingCounts = await this.http.get<RatingCounts>(`${this.baseUrl}/api/Feedback/rating-counts/${eventId}`).toPromise() || {};
    } catch (error) {
      console.error('Error fetching rating counts:', error);
    }
  }

  private async fetchAverageRating() {
    try {
      const response = await this.http.get<{ averageRating: number }>(`${this.baseUrl}/api/Feedback/average`).toPromise();
      this.averageRating = response?.averageRating || 0;
    } catch (error) {
      console.error('Error fetching average rating:', error);
    }
  }

  private startEventTimer() {
    if (!this.event) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const eventStart = new Date(this.event!.startDate).getTime();
      const timeDistance = eventStart - now;

      if (timeDistance < 0) {
        // Event has started
        this.timeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };
        clearInterval(this.timerInterval);
        return;
      }

      this.timeLeft = {
        days: Math.floor(timeDistance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((timeDistance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((timeDistance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((timeDistance % (1000 * 60)) / 1000)
      };
    };

    // Update immediately and then every second
    updateTimer();
    this.timerInterval = setInterval(updateTimer, 1000);
  }

  getDays(): string {
    return this.timeLeft.days.toString().padStart(2, '0');
  }

  getHours(): string {
    return this.timeLeft.hours.toString().padStart(2, '0');
  }

  getMinutes(): string {
    return this.timeLeft.minutes.toString().padStart(2, '0');
  }

  getSeconds(): string {
    return this.timeLeft.seconds.toString().padStart(2, '0');
  }

  getEventStatus(): string {
    if (!this.event) return 'Unknown';
    const now = new Date();
    const startDate = new Date(this.event.startDate);
    const endDate = new Date(this.event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getStatusClass(): string {
    const status = this.getEventStatus();
    switch (status) {
      case 'Active': return 'bg-warning text-dark';
      case 'Completed': return 'bg-secondary';
      case 'Upcoming': return 'bg-primary';
      default: return 'bg-secondary';
    }
  }

  getStatusIcon(): string {
    const status = this.getEventStatus();
    switch (status) {
      case 'Active': return 'bi-play-circle-fill';
      case 'Completed': return 'bi-check-circle-fill';
      case 'Upcoming': return 'bi-calendar-event-fill';
      default: return 'bi-question-circle-fill';
    }
  }

  isEventCompleted(): boolean {
    if (!this.event) return true;
    return new Date(this.event.endDate) < new Date();
  }

  isEventSoldOut(): boolean {
    if (!this.location || this.ticketsSold === undefined) return false;
    return this.ticketsSold >= this.location.capacity;
  }

  getImageUrl(path: string | undefined): SafeUrl {
    if (!path) return 'assets/images/event-placeholder.jpg';
    return this.sanitizer.bypassSecurityTrustUrl(`${this.baseUrl}${path}`);
  }

  getEventImages(): string[] {
    if (!this.event) return [];
    // Put thumbnail first, then other images
    const images = [
      this.event.thumbnailUrl,
      ...[
        this.event.image1Url,
        this.event.image2Url,
        this.event.image3Url,
        this.event.image4Url
      ].filter(url => url && url !== this.event?.thumbnailUrl) // Avoid duplicate thumbnail
    ].filter(url => url) as string[];

    return images;
  }

  prevImage() {
    if (this.carousel) {
      this.carousel.prev();
    }
  }

  nextImage() {
    if (this.carousel) {
      this.carousel.next();
    }
  }

  bookEvent() {
    // Implement booking logic
    console.log('Booking event:', this.event?.eventID);
  }

  incrementTickets() {
    if (this.ticketCount < this.maxTickets) {
      this.ticketCount++;
    }
  }

  decrementTickets() {
    if (this.ticketCount > 1) {
      this.ticketCount--;
    }
  }

  onBookNowClick() {
    if (this.isEventSoldOut()) {
      return;
    }
    if (!this.userService.isLoggedIn()) {
      this.router.navigate(['/login']);
      return;
    }
    // Pass ticket count to booking page
    this.router.navigate(['/book-event', this.event?.eventID], {
      queryParams: { tickets: this.ticketCount }
    })
    .then(() => {
      this.checkUserBooking();
    });
  }

  shareEvent() {
    if (!this.event) return;
    const url = window.location.href;
    const text = `Check out ${this.event.name} - ${url}`;

    if (navigator.share) {
      navigator.share({
        title: this.event.name,
        text: this.event.description,
        url: url
      }).catch(err => console.error('Error sharing:', err));
    } else {
      navigator.clipboard.writeText(text)
        .then(() => alert('Event link copied to clipboard!'))
        .catch(err => console.error('Error copying to clipboard:', err));
    }
  }

  getDurationText(): string {
    if (!this.event) return '';
    const start = new Date(this.event.startDate);
    const end = new Date(this.event.endDate);
    const hours = Math.abs(end.getTime() - start.getTime()) / 36e5;

    if (hours < 24) {
      return `${Math.round(hours)} hours`;
    }
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''}`;
  }

  getRemainingCapacity(): number {
    if (!this.location || !this.ticketsSold) return 0;
    return this.location.capacity - this.ticketsSold;
  }

  getCapacityPercentage(): number {
    if (!this.location || !this.ticketsSold) return 0;
    return (this.ticketsSold / this.location.capacity) * 100;
  }

  getTotalRatings(): number {
    return Object.values(this.ratingCounts).reduce((sum, count) => sum + count, 0);
  }

  getRatingPercentage(rating: number): number {
    const total = this.getTotalRatings();
    if (!total) return 0;
    return (this.ratingCounts[rating] || 0) / total * 100;
  }

  getCapacityInfo() {
    if (!this.location) return {
      total: 0,
      sold: 0,
      remaining: 0,
      percentage: 0
    };

    const total = this.location.capacity;
    const sold = this.ticketsSold;
    const remaining = total - sold;
    const percentage = (sold / total) * 100;

    return {
      total,
      sold,
      remaining,
      percentage
    };
  }

  getProgressBarClass(percentage: number): string {
    if (percentage >= 80) return 'bg-success';
    if (percentage >= 50) return 'bg-info';
    if (percentage >= 25) return 'bg-warning';
    return 'bg-danger';
  }

  checkUserBooking() {
    const user = this.userService.getCurrentUser();
    if (!user || !this.event) return;

    this.http.get(`https://localhost:7149/api/Booking/check/${user.userID}/${this.event.eventID}`)
      .subscribe({
        next: (hasBooked: any) => {
          this.hasBooked = hasBooked;
        },
        error: (error) => console.error('Error checking booking:', error)
      });
  }

  cancelBooking(): void {
    const user = this.userService.getCurrentUser();
    if (!user || !this.event) return;

    const cancelData = {
      userID: user.userID,
      eventID: this.event.eventID
    };

    this.http.post('https://localhost:7149/api/Booking/cancel', cancelData)
      .subscribe({
        next: () => {
          this.hasBooked = false;
          window.location.reload();
        },
        error: (error) => console.error('Error cancelling booking:', error)
      });
  }

  refreshData() {
    const eventId = this.route.snapshot.paramMap.get('id');
    if (eventId) {
      this.fetchEventDetails(eventId);
      this.fetchEventStats(eventId);
      this.fetchTicketsSold(eventId);
      this.checkUserBooking();
    }
  }
}
