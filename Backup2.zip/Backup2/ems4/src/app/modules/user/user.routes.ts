import { Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { EventsComponent } from './events/events.component';
import { ViewEventComponent } from './events/view-event/view-event.component';
import { BookEventComponent } from './book-event/book-event.component';
import { TicketsComponent } from './tickets/tickets.component';
import { ViewTicketComponent } from './tickets/view-ticket/view-ticket.component';

export const USER_ROUTES: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      {
        path: 'events',
        children: [
          { path: '', component: EventsComponent },
          { path: ':id', component: ViewEventComponent },
          { path: ':id/book', component: BookEventComponent }
        ]
      },
      {
        path: 'bookings',
        loadComponent: () => import('./bookings/bookings.component').then(m => m.BookingsComponent)
      },
      {
        path: 'tickets',
        children: [
          { path: '', component: TicketsComponent },
          { path: ':ticketId', component: ViewTicketComponent }
        ]
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/profile.component').then(m => m.ProfileComponent)
      },
      {
        path: '',
        redirectTo: 'events',
        pathMatch: 'full'
      }
    ]
  }
];
