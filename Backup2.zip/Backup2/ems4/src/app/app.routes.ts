import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { BookEventComponent } from './modules/user/book-event/book-event.component';

export const routes: Routes = [
  {
    path: 'auth',
    loadChildren: () => import('./modules/auth/auth.routes').then(m => m.AUTH_ROUTES)
  },
  {
    path: 'user',
    loadChildren: () => import('./modules/user/user.routes').then(m => m.USER_ROUTES),

  },
  {
    path: 'organizer',
    loadChildren: () => import('./modules/organizer/organizer.routes').then(m => m.ORGANIZER_ROUTES)
  },
  {
    path: '',
    redirectTo: 'organizer/dashboard',
    pathMatch: 'full'
  },
  {
    path: '',
    loadChildren: () => import('./modules/user/user.routes').then(m => m.USER_ROUTES)
  },
  {
    path: 'book-event/:id',
    component: BookEventComponent
  }
];
