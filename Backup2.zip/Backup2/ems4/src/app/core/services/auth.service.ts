import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, from, Observable, tap } from 'rxjs';
import { LoginRequest, LoginResponse, RegisterRequest } from '../../model/interface/auth';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'https://localhost:7149/api';
  private currentUserSubject = new BehaviorSubject<any>(null);

  constructor(private http: HttpClient) {
    const token = this.getToken();
    if (token) {
      const user = this.parseJwt(token);
      this.currentUserSubject.next(user);
    }
  }

  login(credentials: LoginRequest): Observable<LoginResponse> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    return this.http.post<LoginResponse>(
      `${this.baseUrl}/Auth/login`,
      credentials,
      {
        headers,
        withCredentials: true
      }
    ).pipe(
      tap(response => {
        this.setToken(response.token);
        const user = this.parseJwt(response.token);
        this.currentUserSubject.next(user);
      })
    );
  }

  register(userData: RegisterRequest): Observable<any> {
    return this.http.post(`${this.baseUrl}/Auth/register`, userData);
  }

  logout(): void {
    this.removeToken();
    this.currentUserSubject.next(null);
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getCurrentUser() {
    return this.currentUserSubject.value;
  }

  getToken(): string | null {
    const match = document.cookie.match(/auth_token=([^;]+)/);
    return match ? match[1] : null;
  }

  private setToken(token: string): void {
    document.cookie = `auth_token=${token}; path=/; secure;`;
  }

  private removeToken(): void {
    document.cookie = 'auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
  }

  private parseJwt(token: string) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  }
}
