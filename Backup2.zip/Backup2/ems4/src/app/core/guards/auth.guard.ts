import { inject } from '@angular/core';
import { Router, CanActivateFn } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard: CanActivateFn = (route) => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (!authService.isLoggedIn()) {
    router.navigate(['/auth/login']);
    return false;
  }

  const requiredRole = route.data['role'];
  if (requiredRole) {
    const user = authService.getCurrentUser();
    if (user.role !== requiredRole) {
      router.navigate(['/']);
      return false;
    }
  }

  return true;
};
