export interface Ticket {
    ticketID: number;
    userID: number;
    eventID: number;
    ticketCount: number;
    bookingDate: string;
    eventDate: string;
    status: string;
    // Add any other properties that might be needed
}
