export interface User {
  userID: number;
  name: string;
  email: string;
  password: string;
  contactNumber: string;
  userType: string;
  isDelete: number;
}
