export interface Ievents {
  eventID: number;
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  locationID: number;
  categoryID: number;
  bookedCapacity: number;
  totalCapacity: number;
  isPrice: boolean;
  price: number;
  isActive: boolean;
}
