export interface Ticket {
  ticketID: number;
  eventID: number;
  eventName: string;
  ticketStatus: string;
  bookingDate: string;
  numberOfTickets: number;
  totalAmount: number;
  eventDetails: {
    startDate: string;
    endDate: string;
    category: string;
    pricePerTicket: number;
    thumbnailUrl?: string;
  };
  venueDetails: {
    location: string;
    address: string;
    city: string;
  };
}
