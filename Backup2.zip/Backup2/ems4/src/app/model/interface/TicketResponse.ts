// Required API Endpoint: GET /api/Ticket/user/{userId}
// Response structure:
export interface TicketResponse {
  ticketId: number;
  eventId: number;
  eventName: string;
  ticketCount: number;
  bookingDate: string;
  status: string;
  amount: number;
  eventDetails: {
    name: string;
    startDate: string;
    endDate: string;
    locationName: string;
    price: number;
  };
}
