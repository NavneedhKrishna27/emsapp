export interface IDBEventTarget extends EventTarget {
  result: IDBDatabase;
}

export interface IDBEvent extends Event {
  target: IDBEventTarget;
}
