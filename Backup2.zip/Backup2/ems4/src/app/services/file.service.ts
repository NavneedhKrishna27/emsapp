import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  constructor(private http: HttpClient) {}

  async saveFile(file: File, eventName: string, type: string): Promise<string> {
    // Sanitize event name for folder path
    const sanitizedEventName = eventName.replace(/[^a-z0-9]/gi, '_').toLowerCase();

    // Generate unique filename
    const extension = file.name.split('.').pop();
    const fileName = `${type}_${Date.now()}.${extension}`;

    // Create the path that will be stored in database
    const relativePath = `/public/${sanitizedEventName}/${fileName}`;

    // Convert file to base64 for temporary storage
    const base64Data = await this.fileToBase64(file);

    // Store in sessionStorage temporarily (we'll implement proper storage later)
    sessionStorage.setItem(relativePath, base64Data);

    return relativePath;
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        if (reader.result) {
          resolve(reader.result.toString());
        } else {
          reject('Failed to read file');
        }
      };
      reader.onerror = (error) => reject(error);
    });
  }
}
