import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private baseUrl = 'https://localhost:7149/api';

  constructor(private http: HttpClient) { }

  uploadEventImages(eventId: number, formData: FormData): Observable<any> {
    return this.http.post(`${this.baseUrl}/Event/${eventId}/upload-images`, formData);
  }

  deleteEventImage(eventId: number, imageType: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/Event/${eventId}/delete-image/${imageType}`);
  }
}
