import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  profile = {
    name: 'John Doe',
    email: 'john@example.com',
    phone: '+1234567890',
    company: 'Event Pro Inc.',
    address: '123 Event Street',
    bio: 'Professional event organizer with 5 years of experience',
    avatar: 'https://via.placeholder.com/150'
  };

  stats = {
    eventsOrganized: 45,
    totalAttendees: 5000,
    totalRevenue: 150000,
    avgRating: 4.8
  };
}
