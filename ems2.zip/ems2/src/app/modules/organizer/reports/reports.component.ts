import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

interface EventReport {
  eventId: number;
  eventName: string;
  ticketsSold: number;
  totalTickets: number;
  revenue: number;
  targetRevenue: number;
  profit: number;
  targetProfit: number;
  feedbacks: Feedback[];
}

interface Feedback {
  customerName: string;
  rating: number;
  comment: string;
  date: string;
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  selectedEventId: number | null = null;
  events: any[] = [];
  eventReport: EventReport | null = null;
  loading = false;
  private apiUrl = 'https://localhost:7183/api';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEvents();
  }

  fetchEvents() {
    this.http.get<any[]>(`${this.apiUrl}/Event/list`).subscribe({
      next: (events) => {
        this.events = events;
      },
      error: (error) => {
        console.error('Error fetching events:', error);
        // Fallback dummy data
        this.events = [
          { eventId: 1, name: 'Tech Conference 2024' },
          { eventId: 2, name: 'Music Festival' }
        ];
      }
    });
  }

  onEventChange(event: Event) {
    const select = event.target as HTMLSelectElement;
    const eventId = parseInt(select.value, 10);
    if (!isNaN(eventId)) {
      this.loading = true;
      this.selectedEventId = eventId;
      this.fetchEventReport(eventId);
    } else {
      this.eventReport = null;
    }
  }

  private fetchEventReport(eventId: number) {
    this.http.get<EventReport>(`${this.apiUrl}/Reports/${eventId}`).subscribe({
      next: (report) => {
        this.eventReport = report;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching report:', error);
        // Fallback dummy data
        this.eventReport = {
          eventId: eventId,
          eventName: 'Tech Conference 2024',
          ticketsSold: 150,
          totalTickets: 200,
          revenue: 15000,
          targetRevenue: 20000,
          profit: 10000,
          targetProfit: 15000,
          feedbacks: [
            {
              customerName: 'John Doe',
              rating: 4,
              comment: 'Great event! Very well organized.',
              date: '2024-04-30'
            }
          ]
        };
        this.loading = false;
      }
    });
  }

  getTicketProgress(): number {
    return this.eventReport ?
      (this.eventReport.ticketsSold / this.eventReport.totalTickets) * 100 : 0;
  }

  getRevenueProgress(): number {
    return this.eventReport ?
      (this.eventReport.revenue / this.eventReport.targetRevenue) * 100 : 0;
  }

  getProfitProgress(): number {
    return this.eventReport ?
      (this.eventReport.profit / this.eventReport.targetProfit) * 100 : 0;
  }

  getRatingStars(rating: number): string[] {
    return Array(5).fill(0).map((_, index) =>
      index < rating ? 'bi-star-fill' : 'bi-star');
  }
}
