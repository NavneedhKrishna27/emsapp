import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-create-event',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent {
  eventForm: FormGroup;
  loading = false;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      locationID: ['', Validators.required],
      categoryID: ['', Validators.required],
      totalCapacity: ['', Validators.required],
      isPrice: [false],
      price: [0],
    });
  }

  onSubmit() {
    if (this.eventForm.valid) {
      this.loading = true;
      this.http.post('https://localhost:7183/api/Event', this.eventForm.value)
        .subscribe({
          next: () => {
            this.router.navigate(['/organizer/events']);
          },
          error: (error) => {
            console.error('Error creating event:', error);
            this.loading = false;
          }
        });
    }
  }
}
