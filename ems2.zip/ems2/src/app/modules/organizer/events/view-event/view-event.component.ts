import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { catchError, of } from 'rxjs';

interface Event {
  eventID: number;
  name: string;
  description?: string;
  startDate: string;
  endDate: string;
  locationID: number;
  categoryID: number;
  bookedCapacity: number;
  totalCapacity: number;
  isPrice: boolean;
  price: number;
  isActive: boolean;
}

@Component({
  selector: 'app-view-event',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.css']
})
export class ViewEventComponent implements OnInit {
  event: Event | null = null;
  loading = true;
  error: string | null = null;
  private apiUrl = 'https://localhost:7183/api';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.fetchEventDetails(params['id']);
      }
    });
  }

  fetchEventDetails(id: string) {
    this.loading = true;
    this.error = null;

    // Fallback data in case API fails
    const dummyEvent: Event = {
      eventID: parseInt(id),
      name: 'Tech Conference 2024',
      description: 'Annual Technology Conference',
      startDate: '2024-06-15T09:00:00',
      endDate: '2024-06-17T18:00:00',
      locationID: 1,
      categoryID: 1,
      bookedCapacity: 150,
      totalCapacity: 200,
      isPrice: true,
      price: 299.99,
      isActive: true
    };

    this.http.get<Event>(`${this.apiUrl}/Event/${id}`).pipe(
      catchError(() => {
        // Return dummy data if API fails
        return of(dummyEvent);
      })
    ).subscribe({
      next: (data) => {
        this.event = data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load event details';
        this.loading = false;
      }
    });
  }

  getLocationName(locationId: number): string {
    const locations = new Map([
      [1, 'Convention Center'],
      [2, 'City Park Arena'],
      [3, 'Business Center']
    ]);
    return locations.get(locationId) || `Location ${locationId}`;
  }

  getCategoryName(categoryId: number): string {
    const categories = new Map([
      [1, 'Technology'],
      [2, 'Entertainment'],
      [3, 'Business']
    ]);
    return categories.get(categoryId) || `Category ${categoryId}`;
  }

  getEventStatus(event: Event): string {
    if (!event.isActive) return 'Cancelled';

    const currentDate = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (currentDate < startDate) {
      return 'Upcoming';
    } else if (currentDate >= startDate && currentDate <= endDate) {
      return 'In Progress';
    } else {
      return 'Completed';
    }
  }

  getStatusClass(status: string): string {
    switch(status) {
      case 'Upcoming': return 'bg-primary';
      case 'In Progress': return 'bg-warning';
      case 'Completed': return 'bg-success';
      case 'Cancelled': return 'bg-danger';
      default: return 'bg-secondary';
    }
  }
}
