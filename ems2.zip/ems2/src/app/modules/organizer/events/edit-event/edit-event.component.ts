import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Ievents } from '../../../../model/interface/Events';

@Component({
  selector: 'app-edit-event',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {
  eventForm: FormGroup;
  loading = false;
  eventId: string | null = null;
  error: string | null = null;

  categories = [
    { id: 1, name: 'Technology' },
    { id: 2, name: 'Entertainment' },
    { id: 3, name: 'Business' }
  ];

  locations = [
    { id: 1, name: 'Convention Center' },
    { id: 2, name: 'City Park Arena' },
    { id: 3, name: 'Business Center' }
  ];

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: [''],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      locationID: ['', Validators.required],
      categoryID: ['', Validators.required],
      totalCapacity: ['', [Validators.required, Validators.min(1)]],
      isPrice: [false],
      price: [{ value: 0, disabled: true }],
      isActive: [true]
    });

    // Enable/disable price based on isPrice checkbox
    this.eventForm.get('isPrice')?.valueChanges.subscribe(isPrice => {
      const priceControl = this.eventForm.get('price');
      if (isPrice) {
        priceControl?.enable();
        priceControl?.setValidators([Validators.required, Validators.min(0)]);
      } else {
        priceControl?.disable();
        priceControl?.clearValidators();
        priceControl?.setValue(0);
      }
      priceControl?.updateValueAndValidity();
    });
  }

  ngOnInit() {
    this.eventId = this.route.snapshot.paramMap.get('id');
    if (this.eventId) {
      this.http.get<Ievents>(`https://localhost:7183/api/Event/${this.eventId}`).subscribe({
        next: (event) => {
          this.eventForm.patchValue(event);
        },
        error: (error) => console.error('Error fetching event:', error)
      });
    }
  }

  onSubmit() {
    if (this.eventForm.valid && this.eventId) {
      this.loading = true;
      this.http.put(`https://localhost:7183/api/Event/${this.eventId}`, this.eventForm.value)
        .subscribe({
          next: () => {
            this.router.navigate(['/organizer/events']);
          },
          error: (error) => {
            console.error('Error updating event:', error);
            this.loading = false;
          }
        });
    }
  }
}
