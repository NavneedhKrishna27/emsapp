import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterModule } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, forkJoin, of, Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import { Ievents } from '../../../model/interface/Events';
import { Ilocations } from '../../../model/interface/Locations';
import { Icategory } from '../../../model/interface/Categories';



@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule, RouterModule, RouterLink],
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  private apiUrl = 'https://localhost:7183/api';
  eventlist: Ievents[] = [];
  locations: Map<number, string> = new Map();
  categories: Map<number, string> = new Map();
  loading = false;
  error: string | null = null;
  http = inject(HttpClient);

  searchTerm: string = '';
  searchSubject = new Subject<string>();
  filteredEvents: Ievents[] = [];

  // Dummy data for testing
  dummyEvents: Ievents[] = [
    {
      eventID: 1,
      name: 'Tech Summit 2024',
      description: 'Annual Technology Conference',
      startDate: '2024-06-15T09:00:00',
      endDate: '2024-06-17T18:00:00',
      locationID: 1,
      categoryID: 1,
      bookedCapacity: 150,
      totalCapacity: 200,
      isPrice: true,
      price: 299.99,
      isActive: true
    },
    {
      eventID: 2,
      name: 'Music Festival',
      description: 'Summer Music Extravaganza',
      startDate: '2024-07-20T14:00:00',
      endDate: '2024-07-22T23:00:00',
      locationID: 2,
      categoryID: 2,
      bookedCapacity: 450,
      totalCapacity: 500,
      isPrice: true,
      price: 149.99,
      isActive: true
    },
    {
      eventID: 3,
      name: 'Business Workshop',
      description: 'Leadership and Management Workshop',
      startDate: '2024-05-10T10:00:00',
      endDate: '2024-05-10T17:00:00',
      locationID: 3,
      categoryID: 3,
      bookedCapacity: 30,
      totalCapacity: 50,
      isPrice: true,
      price: 99.99,
      isActive: false
    }
  ];

  dummyLocations = new Map([
    [1, 'Convention Center'],
    [2, 'City Park Arena'],
    [3, 'Business Center']
  ]);

  dummyCategories = new Map([
    [1, 'Technology'],
    [2, 'Entertainment'],
    [3, 'Business']
  ]);

  ngOnInit(): void {
    this.loading = true;
    this.fetchEvents();

    // Setup search with debounce
    this.searchSubject.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(term => {
      this.searchTerm = term;
      this.filterEvents();
      this.currentPage = 1; // Reset to first page when searching
    });
  }

  private fetchEvents() {
    // Try API call first, fallback to dummy data if it fails
    this.http.get<Ievents[]>(`${this.apiUrl}/Event/index`).pipe(
      catchError((error: HttpErrorResponse) => {
        console.warn('API call failed, using dummy data:', error);
        return of(this.dummyEvents);
      })
    ).subscribe({
      next: (events) => {
        this.eventlist = events;
        this.filteredEvents = [...events];
        this.fetchLocationAndCategories(events);
      },
      error: (error) => {
        this.error = 'Failed to load events';
        console.error('Error:', error);
      }
    });
  }

  private fetchLocationAndCategories(events: Ievents[]) {
    const locationIds = [...new Set(events.map(e => e.locationID))];
    const categoryIds = [...new Set(events.map(e => e.categoryID))];

    // Try API calls first, fallback to dummy data if they fail
    const locationRequests = locationIds.map(id =>
      this.http.get<Ilocations>(`${this.apiUrl}/Location/${id}`).pipe(
        catchError(() => of({ locationID: id, locationName: this.dummyLocations.get(id) || `Location ${id}` }))
      )
    );

    const categoryRequests = categoryIds.map(id =>
      this.http.get<Icategory>(`${this.apiUrl}/Categories/${id}`).pipe(
        catchError(() => of({ categoryID: id, categoryName: this.dummyCategories.get(id) || `Category ${id}` }))
      )
    );

    forkJoin([
      forkJoin(locationRequests),
      forkJoin(categoryRequests)
    ]).subscribe({
      next: ([locations, categories]) => {
        locations.forEach(location => {
          this.locations.set(location.locationID, location.locationName);
        });
        categories.forEach(category => {
          this.categories.set(category.categoryID, category.categoryName);
        });
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching locations or categories:', error);
        this.loading = false;

        // Fallback to dummy data
        this.locations = this.dummyLocations;
        this.categories = this.dummyCategories;
      }
    });
  }

  openDeleteConfirmation(event: Ievents) {
    if (confirm(`Are you sure you want to delete "${event.name}"?`)) {
      this.http.delete(`${this.apiUrl}/Event/${event.eventID}`).subscribe({
        next: () => {
          this.eventlist = this.eventlist.filter(e => e.eventID !== event.eventID);
          this.filterEvents();
        },
        error: (error) => {
          console.error('Error deleting event:', error);
          alert('Failed to delete event. Please try again.');
        }
      });
    }
  }

  getLocationName(locationId: number): string {
    return this.locations.get(locationId) || `Location ${locationId}`;
  }

  getCategoryName(categoryId: number): string {
    return this.categories.get(categoryId) || `Category ${categoryId}`;
  }

  getEventStatus(event: Ievents): 'Upcoming' | 'In Progress' | 'Completed' | 'Cancelled' {
    if (!event.isActive) return 'Cancelled';

    const currentDate = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (currentDate < startDate) {
      return 'Upcoming';
    } else if (currentDate >= startDate && currentDate <= endDate) {
      return 'In Progress';
    } else {
      return 'Completed';
    }
  }

  get activeEvents(): number {
    return this.eventlist.filter(event => this.getEventStatus(event) === 'In Progress').length;
  }

  get upcomingEvents(): number {
    return this.eventlist.filter(event => this.getEventStatus(event) === 'Upcoming').length;
  }

  get completedEvents(): number {
    return this.eventlist.filter(event => this.getEventStatus(event) === 'Completed').length;
  }

  get cancelledEvents(): number {
    return this.eventlist.filter(event => !event.isActive).length;
  }

  currentPage = 1;
  itemsPerPage = 5;

  get totalPages(): number {
    return Math.ceil(this.filteredEvents.length / this.itemsPerPage);
  }

  get paginatedEvents(): Ievents[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredEvents.slice(startIndex, endIndex);
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  setPage(page: number): void {
    if (page < 1) page = 1;
    if (page > this.totalPages) page = this.totalPages;
    this.currentPage = page;
  }

  getStatusClass(event: Ievents): string {
    const status = this.getEventStatus(event);
    switch(status) {
      case 'Upcoming': return 'bg-primary';
      case 'In Progress': return 'bg-warning';
      case 'Completed': return 'bg-success';
      case 'Cancelled': return 'bg-danger';
      default: return 'bg-secondary';
    }
  }

  getStatusIcon(event: Ievents): string {
    const status = this.getEventStatus(event);
    switch(status) {
      case 'Upcoming': return 'bi-calendar';
      case 'In Progress': return 'bi-play-circle';
      case 'Completed': return 'bi-check-circle';
      case 'Cancelled': return 'bi-x-circle';
      default: return 'bi-question-circle';
    }
  }

  getPaginationInfo(): string {
    const start = (this.currentPage - 1) * this.itemsPerPage + 1;
    const end = Math.min(this.currentPage * this.itemsPerPage, this.filteredEvents.length);
    return `Showing ${start} to ${end} of ${this.filteredEvents.length} entries`;
  }

  onSearch(event: any) {
    const term = event.target.value;
    this.searchSubject.next(term);
  }

  private filterEvents() {
    if (!this.searchTerm.trim()) {
      this.filteredEvents = [...this.eventlist];
      return;
    }

    const searchTermLower = this.searchTerm.toLowerCase();
    this.filteredEvents = this.eventlist.filter(event =>
      event.name.toLowerCase().includes(searchTermLower) ||
      this.getLocationName(event.locationID).toLowerCase().includes(searchTermLower) ||
      this.getCategoryName(event.categoryID).toLowerCase().includes(searchTermLower) ||
      this.getEventStatus(event).toLowerCase().includes(searchTermLower)
    );
  }
}
