import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Subject, debounceTime, distinctUntilChanged } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  searchTerm: string = '';
  searchSubject = new Subject<string>();
  private apiUrl = 'https://localhost:7183/api';

  stats = {
    totalEvents: 0,
    activeEvents: 0,
    totalBookings: 0,
    revenue: 0
  };

  eventStats: any[] = [];
  filteredEventStats: any[] = [];
  recentBookings: any[] = [];

  constructor(private http: HttpClient) {
    this.searchSubject.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(term => {
      this.filterEvents(term);
    });
  }

  ngOnInit() {
    this.fetchDashboardStats();
    this.fetchEventStats();
    this.fetchRecentBookings();
  }

  onSearch(event: any) {
    const term = event.target.value;
    this.searchSubject.next(term);
  }

  private filterEvents(term: string) {
    if (!term.trim()) {
      this.filteredEventStats = [...this.eventStats];
      return;
    }

    const searchTerm = term.toLowerCase();
    this.filteredEventStats = this.eventStats.filter(event =>
      event.name.toLowerCase().includes(searchTerm)
    );
  }

  private fetchDashboardStats() {
    this.http.get<any>(`${this.apiUrl}/Dashboard/Stats`).subscribe({
      next: (data) => {
        this.stats = data;
      },
      error: (error) => {
        console.error('Error fetching stats:', error);
        // Fallback to dummy data
        this.stats = {
          totalEvents: 45,
          activeEvents: 12,
          totalBookings: 234,
          revenue: 15000
        };
      }
    });
  }

  private fetchEventStats() {
    this.http.get<any>(`${this.apiUrl}/Dashboard/EventStats`).subscribe({
      next: (data) => {
        this.eventStats = data;
        this.filteredEventStats = [...this.eventStats];
      },
      error: (error) => {
        console.error('Error fetching event stats:', error);
        // Fallback to dummy data
        this.eventStats = [
          {
            id: 1,
            name: 'Tech Conference 2024',
            ticketsSold: 120,
            totalTickets: 200,
            profit: 12000,
            targetProfit: 20000,
            date: '2024-05-15'
          }
        ];
        this.filteredEventStats = [...this.eventStats];
      }
    });
  }

  private fetchRecentBookings() {
    this.http.get<any>(`${this.apiUrl}/Dashboard/RecentBookings`).subscribe({
      next: (data) => {
        this.recentBookings = data;
      },
      error: (error) => {
        console.error('Error fetching bookings:', error);
        // Fallback to dummy data
        this.recentBookings = [
          {
            eventName: 'Tech Conference',
            customerName: 'John Doe',
            tickets: 2,
            amount: 200,
            date: new Date(),
            status: 'Confirmed'
          }
        ];
      }
    });
  }

  getTicketProgress(stat: any): number {
    return (stat.ticketsSold / stat.totalTickets) * 100;
  }

  getProfitProgress(stat: any): number {
    return (stat.profit / stat.targetProfit) * 100;
  }
}
