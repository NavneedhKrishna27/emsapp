import { Routes } from '@angular/router';
import { OrganizerComponent } from './organizer.component';
import { EventsComponent } from './events/events.component';

export const ORGANIZER_ROUTES: Routes = [
  {
    path: '',
    component: OrganizerComponent,
    children: [
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'events',
        children: [
          {
            path: '',
            loadComponent: () => import('./events/events.component').then(m => m.EventsComponent)
          },
          {
            path: 'create',
            loadComponent: () => import('./events/create-event/create-event.component').then(m => m.CreateEventComponent)
          },
          {
            path: 'view/:id',
            loadComponent: () => import('./events/view-event/view-event.component').then(m => m.ViewEventComponent)
          },
          {
            path: 'edit/:id',
            loadComponent: () => import('./events/edit-event/edit-event.component').then(m => m.EditEventComponent)
          }
        ]
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/profile.component').then(m => m.ProfileComponent)
      },
      {
        path: 'reports',
        loadComponent: () => import('./reports/reports.component').then(m => m.ReportsComponent)
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      }
    ]
  }
];
