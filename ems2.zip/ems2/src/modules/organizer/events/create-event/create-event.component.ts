import { Component } from '@angular/core';

@Component({
  selector: 'app-create-event',
  imports: [],
  templateUrl: './create-event.component.html',
  styleUrl: './create-event.component.css'
})
export class CreateEventComponent {

}
