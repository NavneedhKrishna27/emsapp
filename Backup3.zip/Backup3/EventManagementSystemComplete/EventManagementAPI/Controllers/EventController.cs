﻿using EventManagementSystem_Merged_.DTO_s;
using EventManagementSystemMerged.Data;
using EventManagementSystemMerged.Models;
using EventManagementSystemMerged.Repos;
using Microsoft.AspNetCore.Mvc;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly EventService _eventService;
        private readonly AppDbContext _context;

        public EventController()
        {
            _eventService = new EventService();
            _context = new AppDbContext();
        }


        [HttpPost("add-event")]
        public IActionResult AddEvent(EventDTO eventDetails)
        {
            if (!eventDetails.IsPrice)
            {
                eventDetails.Price = 0; // Set price to 0 if IsPrice is not checked
            }
            _eventService.AddEvent(eventDetails);
            return Ok(new { message = "Event added successfully" });
        }

        [HttpPut("edit-event")]
        public IActionResult EditEvent([FromBody] EventDTO evt)
        {
            try
            {
                _eventService.UpdateEvent(evt, evt.EventID);
                return Ok(new { message = "Event updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("user/{userId}/events")]
        public IActionResult GetEventsByUserId(int userId)
        {
            try
            {
                var events = _eventService.GetAllEvents()
                    .Where(e => e.UserID == userId)
                    .ToList();

                if (!events.Any())
                {
                    return Ok(new { message = "No events found for this user", events = new List<EventDTO>() });
                }

                return Ok(events);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("user/{userId}/dashboard")]
        public IActionResult GetOrganizerDashboard(int userId)
        {
            try
            {
                var allEvents = _eventService.GetAllEvents()
                    .Where(e => e.UserID == userId)
                    .ToList();

                // Get all events IDs for this organizer
                var eventIds = allEvents.Select(e => e.EventID).ToList();

                // Get valid tickets (not cancelled) for each event
                var ticketsSoldByEvent = _context.Tickets
                    .Where(t => eventIds.Contains(t.EventID) && t.Status != "Cancelled")
                    .GroupBy(t => t.EventID)
                    .ToDictionary(g => g.Key, g => g.Sum(t => t.TicketCount));

                // Calculate total revenue based on tickets sold × event price
                var totalRevenue = allEvents.Sum(e =>
                    (e.IsPrice ? e.Price ?? 0 : 0) *
                    ticketsSoldByEvent.GetValueOrDefault(e.EventID, 0));

                var dashboard = new
                {
                    totalEvents = allEvents.Count,
                    ongoingEvents = _eventService.GetCurrentEvents()
                        .Count(e => e.UserID == userId),
                    upcomingEvents = _eventService.GetUpcomingEvents()
                        .Count(e => e.UserID == userId),
                    completedEvents = _eventService.GetCompletedEvents()
                        .Count(e => e.UserID == userId),
                    totalRevenue = totalRevenue,
                    totalTicketsSold = ticketsSoldByEvent.Values.Sum()
                };

                return Ok(dashboard);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("user/{userId}/events-details")]
        public IActionResult GetOrganizerEventsDetails(int userId)
        {
            try
            {
                // Get all events for the user
                var events = _eventService.GetAllEvents()
                    .Where(e => e.UserID == userId)
                    .ToList();

                // Get all event IDs
                var eventIds = events.Select(e => e.EventID).ToList();

                // Get location details
                var locationIds = events.Select(e => e.LocationID).Distinct().ToList();
                var locations = _context.Locations
                    .Where(l => locationIds.Contains(l.LocationID))
                    .ToDictionary(l => l.LocationID, l => new { l.Capacity, l.LocationName });

                // Get valid tickets sold for each event (excluding cancelled)
                var ticketsSold = _context.Tickets
                    .Where(t => eventIds.Contains(t.EventID) && t.Status != "Cancelled")
                    .GroupBy(t => t.EventID)
                    .ToDictionary(g => g.Key, g => g.Sum(t => t.TicketCount));

                var eventsDetails = events.Select(e => new
                {
                    eventId = e.EventID,
                    name = e.Name,
                    startDate = e.StartDate,
                    endDate = e.EndDate,
                    status = _eventService.GetEventStatus(e.EventID),
                    location = locations.GetValueOrDefault(e.LocationID)?.LocationName,
                    capacity = locations.GetValueOrDefault(e.LocationID)?.Capacity ?? 0,
                    ticketsSold = ticketsSold.GetValueOrDefault(e.EventID, 0),
                    price = e.Price,
                    revenue = (e.IsPrice ? e.Price ?? 0 : 0) * ticketsSold.GetValueOrDefault(e.EventID, 0),
                    isActive = e.IsActive,
                    availableCapacity = (locations.GetValueOrDefault(e.LocationID)?.Capacity ?? 0) -
                                       ticketsSold.GetValueOrDefault(e.EventID, 0)
                })
                .OrderByDescending(e => e.startDate)
                .ToList();

                return Ok(eventsDetails);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("index")]
        public IActionResult Index()
        {
            var events = _eventService.GetAllEvents();
            return Ok(events);
        }

        [HttpPost("upload-file")]
        public async Task<IActionResult> UploadFile(IFormFile file, [FromForm] string eventName, [FromForm] string fileType)
        {
            try
            {
                if (file == null || file.Length == 0)
                    return BadRequest("No file uploaded");

                // Create the public folder path
                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                var eventPath = Path.Combine(publicPath, eventName);

                // Create directories if they don't exist
                Directory.CreateDirectory(eventPath);

                // Generate file name
                var fileName = $"{fileType}_{DateTime.Now.Ticks}.{Path.GetExtension(file.FileName)}";
                var filePath = Path.Combine(eventPath, fileName);

                // Save the file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Return the relative path for database storage
                return Ok(new { path = $"/public/{eventName}/{fileName}" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("delete-files/{eventId}")]
        public IActionResult DeleteEventFiles(int eventId)
        {
            try
            {
                // Get event details to get file paths
                var eventDetails = _eventService.GetEventById(eventId);
                if (eventDetails == null)
                    return NotFound("Event not found");

                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                var eventFolderPath = Path.Combine(publicPath, eventDetails.Name.Replace(" ", "_").ToLower());

                // Delete all event files if they exist
                if (Directory.Exists(eventFolderPath))
                {
                    Directory.Delete(eventFolderPath, true);
                }

                return Ok(new { message = "Event files deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("view-event/{id}")]
        public IActionResult ViewEventByID(int id)
        {
            var eventDetails = _eventService.GetEventById(id);
            if (eventDetails == null)
            {
                return NotFound(new { message = "Event not found" });
            }
            return Ok(eventDetails);
        }

        [HttpDelete("delete-event/{id}")]
        public IActionResult DeleteConfirmation(int id)
        {
            try
            {
                // Delete files first
                var result = DeleteEventFiles(id) as ObjectResult;
                if (result?.StatusCode != 200)
                {
                    return result;
                }

                // Then delete event from database
                _eventService.DeleteEvent(id);
                return Ok(new { message = "Event and associated files deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("details/{id}")]
        public IActionResult Details(int id)
        {
            var eventDetails = _eventService.GetEventById(id);
            if (eventDetails == null)
            {
                return NotFound(new { message = "Event not found" });
            }
            return Ok(eventDetails);
        }

        [HttpGet("{eventId}/users")]
        public IActionResult GetUsersForEvent(int eventId)
        {
            var users = _eventService.GetUsersForEvent(eventId);
            return Ok(users);
        }

        [HttpGet("{eventId}/tickets-sold")]
        public IActionResult GetTicketsSoldForEvent(int eventId)
        {
            var ticketsSold = _eventService.GetTicketsSoldForEvent(eventId);
            return Ok(ticketsSold);
        }

        [HttpGet("{eventId}/revenue")]
        public IActionResult GetRevenueForEvent(int eventId)
        {
            var revenue = _eventService.GetRevenueForEvent(eventId);
            return Ok(revenue);
        }

        [HttpGet("{eventId}/status")]
        public IActionResult GetEventStatus(int eventId)
        {
            var status = _eventService.GetEventStatus(eventId);
            return Ok(status);
        }

        [HttpGet("completed")]
        public IActionResult GetCompletedEvents()
        {
            var events = _eventService.GetCompletedEvents();
            return Ok(events);
        }

        [HttpGet("upcoming")]
        public IActionResult GetUpcomingEvents()
        {
            var events = _eventService.GetUpcomingEvents();
            return Ok(events);
        }

        [HttpGet("current")]
        public IActionResult GetCurrentEvents()
        {
            var events = _eventService.GetCurrentEvents();
            return Ok(events);
        }
        [HttpPost("add-image/{id}/{type}")]
        public async Task<IActionResult> AddImage(int id, string type, IFormFile file)
        {
            try
            {
                var eventDetails = _eventService.GetEventById(id);
                if (eventDetails == null)
                    return NotFound("Event not found");

                if (file == null || file.Length == 0)
                    return BadRequest("No file uploaded");

                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                var eventFolderName = eventDetails.Name.Replace(" ", "_").ToLower();
                var eventPath = Path.Combine(publicPath, eventFolderName);

                Directory.CreateDirectory(eventPath);

                var fileName = $"{type}_{DateTime.Now.Ticks}{Path.GetExtension(file.FileName)}";
                var filePath = Path.Combine(eventPath, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var relativePath = $"public/{eventFolderName}/{fileName}";  // Include 'public' in the path

                // Update specific image URL
                switch (type)
                {
                    case "thumbnail":
                        eventDetails.ThumbnailUrl = relativePath;
                        break;
                    case "image1":
                        eventDetails.Image1Url = relativePath;
                        break;
                    case "image2":
                        eventDetails.Image2Url = relativePath;
                        break;
                    case "image3":
                        eventDetails.Image3Url = relativePath;
                        break;
                    case "image4":
                        eventDetails.Image4Url = relativePath;
                        break;
                }

                _eventService.UpdateEvent(eventDetails, id);
                return Ok(new { path = relativePath });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpDelete("delete-image/{id}/{type}")]
        public IActionResult DeleteImage(int id, string type)
        {
            try
            {
                var eventDetails = _eventService.GetEventById(id);
                if (eventDetails == null)
                    return NotFound("Event not found");

                string? currentPath = type switch
                {
                    "thumbnail" => eventDetails.ThumbnailUrl,
                    "image1" => eventDetails.Image1Url,
                    "image2" => eventDetails.Image2Url,
                    "image3" => eventDetails.Image3Url,
                    "image4" => eventDetails.Image4Url,
                    _ => null
                };

                if (!string.IsNullOrEmpty(currentPath))
                {
                    var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                    var fullPath = Path.Combine(publicPath, currentPath.TrimStart('/'));
                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }

                    // Clear the specific image URL
                    switch (type)
                    {
                        case "thumbnail":
                            eventDetails.ThumbnailUrl = null;
                            break;
                        case "image1":
                            eventDetails.Image1Url = null;
                            break;
                        case "image2":
                            eventDetails.Image2Url = null;
                            break;
                        case "image3":
                            eventDetails.Image3Url = null;
                            break;
                        case "image4":
                            eventDetails.Image4Url = null;
                            break;
                    }

                    _eventService.UpdateEvent(eventDetails, id);
                }

                return Ok(new { message = "Image deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("images/{eventName}/{fileName}")]
        public IActionResult GetImage(string eventName, string fileName)
        {
            try
            {
                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                var filePath = Path.Combine(publicPath, eventName, fileName);

                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound();
                }

                var fileStream = System.IO.File.OpenRead(filePath);
                return File(fileStream, "image/jpeg"); // Adjust content type as needed
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("images/{*imagePath}")]
        public IActionResult GetImage(string imagePath)
        {
            try
            {
                // Decode the URL-encoded path
                imagePath = Uri.UnescapeDataString(imagePath);

                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                var filePath = Path.Combine(publicPath, imagePath);

                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound($"Image not found: {imagePath}");
                }

                // Determine content type based on file extension
                var mimeType = GetContentType(Path.GetExtension(filePath));

                // Use PhysicalFile to properly serve the image with correct content type
                return PhysicalFile(filePath, mimeType);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

       

        private string GetContentType(string fileExtension)
        {
            return fileExtension.ToLower() switch
            {
                ".jpg" or ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream"
            };
        }

        [HttpPost("update-images/{id}")]
        public async Task<IActionResult> UpdateEventImages(int id, [FromForm] IFormCollection formData)
        {
            try
            {
                var eventDetails = _eventService.GetEventById(id);
                if (eventDetails == null)
                    return NotFound("Event not found");

                var publicPath = Path.Combine(Directory.GetCurrentDirectory(), "public");
                Directory.CreateDirectory(publicPath);

                var eventFolderName = eventDetails.Name.Replace(" ", "_").ToLower();
                var eventPath = Path.Combine(publicPath, eventFolderName);
                Directory.CreateDirectory(eventPath);

                bool anyChanges = false;

                // Handle new files
                foreach (var file in formData.Files)
                {
                    if (file.Length > 0)
                    {
                        anyChanges = true;
                        var fileName = $"{file.Name}_{DateTime.Now.Ticks}{Path.GetExtension(file.FileName)}";
                        var filePath = Path.Combine(eventPath, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        // Store path with event folder name
                        var relativePath = $"/{eventFolderName}/{fileName}";

                        switch (file.Name)
                        {
                            case "thumbnail":
                                eventDetails.ThumbnailUrl = relativePath;
                                break;
                            case "image1":
                                eventDetails.Image1Url = relativePath;
                                break;
                            case "image2":
                                eventDetails.Image2Url = relativePath;
                                break;
                            case "image3":
                                eventDetails.Image3Url = relativePath;
                                break;
                            case "image4":
                                eventDetails.Image4Url = relativePath;
                                break;
                        }
                    }
                }

                // Handle deletions
                foreach (var key in formData.Keys.Where(k => k.StartsWith("delete_")))
                {
                    anyChanges = true;
                    var imageType = key.Substring(7);
                    var oldImagePath = imageType switch
                    {
                        "thumbnail" => eventDetails.ThumbnailUrl,
                        "image1" => eventDetails.Image1Url,
                        "image2" => eventDetails.Image2Url,
                        "image3" => eventDetails.Image3Url,
                        "image4" => eventDetails.Image4Url,
                        _ => null
                    };

                    // Delete physical file if it exists
                    if (!string.IsNullOrEmpty(oldImagePath))
                    {
                        var fullPath = Path.Combine(publicPath, oldImagePath.TrimStart('/'));
                        if (System.IO.File.Exists(fullPath))
                        {
                            System.IO.File.Delete(fullPath);
                        }
                    }

                    switch (imageType)
                    {
                        case "thumbnail":
                            eventDetails.ThumbnailUrl = null;
                            break;
                        case "image1":
                            eventDetails.Image1Url = null;
                            break;
                        case "image2":
                            eventDetails.Image2Url = null;
                            break;
                        case "image3":
                            eventDetails.Image3Url = null;
                            break;
                        case "image4":
                            eventDetails.Image4Url = null;
                            break;
                    }
                }

                if (anyChanges)
                {
                    _eventService.UpdateEvent(eventDetails, id);
                }

                return Ok(new { message = "Images updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}

