﻿using EventManagementSystem_Merged_.Repos;
using EventManagementSystemMerged.Data;
using EventManagementSystemMerged.Models;
using EventManagementSystemMerged.Repos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using static EventManagementSystem_Merged_.Repos.FeedbackService;

namespace EventManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbackController : ControllerBase
    {
        private readonly FeedbackService _feedbackService;

        // Constructor Injection
        public FeedbackController(FeedbackService feedbackService)
        {
            _feedbackService = feedbackService;
        }

        //[Authorize]
        [HttpGet("Get-feedbacks-by-eventid/{eventid:int}")]
        public IActionResult GetFeedbacks([FromRoute] int eventid)
        {
            if (eventid <= 0)
            {
                return BadRequest(new { message = "Invalid event ID. Event ID must be a positive integer." });
            }

            var feedbacks = _feedbackService.ViewFeedbacks(eventid);
            if (feedbacks == null || feedbacks.Count == 0)
            {
                return NotFound(new { message = "No feedbacks found for the given event ID." });
            }

            return Ok(feedbacks);
        }


        //[Authorize(Policy = "UserOnly")]
        [HttpPost("Add feedbacks by Ticketid")]
        public IActionResult AddFeedback([FromForm] FeedbackDTO feedback, int userid, int ticketid)
        {
            Event e = new Event();
            if (DateTime.UtcNow < e.EndDate)
            {
                return BadRequest("The event is ongoing");
            }

            _feedbackService.AddFeedback(feedback, userid, ticketid);
            return Ok(new { message = "Feedback added successfully" });
        }

        //[Authorize(Policy = "UserOnly")]
        [HttpGet("average-rating/{eventId}")]
        public IActionResult GetAverageRating(int eventId)
        {
            var averageRating = _feedbackService.GetAverageRating(eventId);
            return Ok(new { averageRating });
        }

        //[Authorize]
        [HttpGet("rating-counts/{eventId}")]
        public IActionResult GetRatingCounts(int eventId)
        {
            var ratingCounts = _feedbackService.GetRatingCounts(eventId);
            return Ok(ratingCounts);
        }

        //[Authorize(Policy = "UserOnly")]
        [HttpDelete("{feedbackId}")]
        public IActionResult DeleteFeedback(int feedbackId, int eventid)
        {
            var result = _feedbackService.DeleteFeedbacks(feedbackId, eventid);
            return Ok(result);
        }
    }
}


