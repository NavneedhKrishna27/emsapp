﻿using EventManagementSystemMerged.Data;
using EventManagementSystemMerged.Models;
using System.Collections.Generic;
using System.Linq;

namespace EventManagementSystem_Merged_.Repos
{
    public class TicketService
    {
        private readonly AppDbContext _context;

        public TicketService(AppDbContext context)
        {
            _context = context;
        }

        public List<Ticket> GetAllTickets()
        {
            return _context.Tickets.ToList();
        }

        public Ticket GetTicketById(int ticketId)
        {
            return _context.Tickets.Find(ticketId);
        }

        public int GetNumberOfTicketsSold(int eventId)
        {
            return _context.Tickets
                .Where(t => t.EventID == eventId && t.Status == "Confirmed") // Include only confirmed tickets
                .Sum(t => t.TicketCount); // Sum TicketCount
        }

        public List<User> GetParticipants(int eventId)
        {
            return _context.Tickets
                .Where(t => t.EventID == eventId)
                .Join(_context.Users,
                    ticket => ticket.UserID,
                    user => user.UserID,
                    (ticket, user) => user)
                .ToList();
        }

        public void AddTicket(Ticket ticket)
        {
            _context.Tickets.Add(ticket);
            _context.SaveChanges();
        }

        public void UpdateTicket(Ticket ticket)
        {
            _context.Tickets.Update(ticket);
            _context.SaveChanges();
        }

        public List<Ticket> GetTicketsByUserId(int userId)
        {
            return _context.Tickets.Where(t => t.UserID == userId).ToList();
        }

        public Ticket GetTicketByEventAndUser(int eventId, int userId)
        {
            return _context.Tickets.FirstOrDefault(t => t.EventID == eventId && t.UserID == userId);
        }

        public string? GetTicketStatus(int ticketId)
        {
            return _context.Tickets
                .Where(t => t.TicketID == ticketId)
                .Select(t => t.Status)
                .FirstOrDefault();
        }

        public object GetTicketDetails(int ticketId)
        {
            var ticketDetails = (from ticket in _context.Tickets
                                 join eventEntity in _context.Events on ticket.EventID equals eventEntity.EventID
                                 join category in _context.Categories on eventEntity.CategoryID equals category.CategoryID
                                 join location in _context.Locations on eventEntity.LocationID equals location.LocationID
                                 where ticket.TicketID == ticketId
                                 select new
                                 {
                                     TicketID = ticket.TicketID,
                                     EventID = ticket.EventID, // Include EventID
                                     EventName = eventEntity.Name, // Include Event Name
                                     TicketStatus = ticket.Status, // Include Ticket Status
                                     BookingDate = ticket.BookingDate,
                                     NumberOfTickets = ticket.TicketCount,
                                     TotalAmount = ticket.TicketCount * (eventEntity.Price ?? 0), // Handle nullable Price
                                     EventDetails = new
                                     {
                                         StartDate = eventEntity.StartDate,
                                         EndDate = eventEntity.EndDate,
                                         Category = category.CategoryName,
                                         PricePerTicket = eventEntity.Price ?? 0 // Handle nullable Price
                                     },
                                     VenueDetails = new
                                     {
                                         Location = location.LocationName,
                                         Address = location.Address,
                                         City = location.City
                                     }
                                 }).FirstOrDefault();

            return ticketDetails;
        }
    }

}
