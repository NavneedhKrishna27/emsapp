import { Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';
import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { OrganizerRegisterComponent } from './components/auth/organizer-register/organizer-register.component';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'register/organizer', component: OrganizerRegisterComponent },
  {
    path: 'user',
    loadChildren: () => import('./components/user/user.route').then(m => m.USER_ROUTES),
    canActivate: [AuthGuard],
    data: { roles: ['User'] }
  },
  {
    path: 'organizer',
    loadChildren: () => import('./components/organizer/organizer.route').then(m => m.ORGANIZER_ROUTES),
    canActivate: [AuthGuard],
    data: { roles: ['Organizer'] }
  },
  { path: '**', redirectTo: '/login' }
];