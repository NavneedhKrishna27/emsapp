import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventFilterService {
  private selectedLocationSubject = new BehaviorSubject<number | null>(null);
  selectedLocation$ = this.selectedLocationSubject.asObservable();

  updateSelectedLocation(locationId: number | null) {
    this.selectedLocationSubject.next(locationId);
  }
}
