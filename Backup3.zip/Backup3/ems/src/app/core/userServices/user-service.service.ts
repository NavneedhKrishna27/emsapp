import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { UserProfile } from '../../interfaces/user.interface';
import { AuthService } from '../authServices/auth.service';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private readonly API_URL = 'https://localhost:7149/api';
  private cachedProfile: UserProfile | null = null;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  getUserProfile(forceRefresh: boolean = false): Observable<UserProfile> {
    const userId = this.authService.getUserId();
    
    if (!userId) {
      return throwError(() => new Error('No authenticated user found'));
    }

    if (this.cachedProfile && !forceRefresh) {
      return of(this.cachedProfile);
    }

    return this.http.get<UserProfile>(`${this.API_URL}/User/${userId}`).pipe(
      tap(profile => this.cachedProfile = profile),
      catchError(error => {
        console.error('API Error:', error);
        return throwError(() => new Error('Failed to load profile'));
      })
    );
  }

  updateUserProfile(updateData: Partial<UserProfile>): Observable<UserProfile> {
    const userId = this.authService.getUserId();
    
    if (!userId) {
      return throwError(() => new Error('No authenticated user found'));
    }

    return this.http.put<UserProfile>(`${this.API_URL}/User/${userId}`, updateData).pipe(
      tap(profile => this.cachedProfile = profile),
      catchError(error => {
        console.error('API Error:', error);
        return throwError(() => new Error('Failed to update profile'));
      })
    );
  }

  clearCache(): void {
    this.cachedProfile = null;
  }
}
