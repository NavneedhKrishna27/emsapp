import { Component } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [HeaderComponent, SidenavComponent, RouterOutlet],
  template: `
    <app-header (toggleSidenav)="toggleSidenav()"></app-header>
    <app-sidenav [isExpanded]="isSidenavExpanded"></app-sidenav>
    <main [class.sidenav-expanded]="isSidenavExpanded">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    main {
      margin-left: 70px;
      margin-top: 64px;
      padding: 2rem;
      transition: margin-left 0.3s ease;
    }

    main.sidenav-expanded {
      margin-left: 240px;
    }
  `]
})
export class UserComponent {
  isSidenavExpanded = false;

  toggleSidenav() {
    this.isSidenavExpanded = !this.isSidenavExpanded;
  }
}
