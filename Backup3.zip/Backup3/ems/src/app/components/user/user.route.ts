import { Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { EventsComponent } from './events/events.component';
import { TicketsComponent } from './tickets/tickets.component';
import { ProfileComponent } from './profile/profile.component';
import { NotificationsComponent } from './notifications/notifications.component';
// import { ViewEventComponent } from './events/view-event/view-event.component';
// import { BookEventComponent } from './events/book-event/book-event.component';
export const USER_ROUTES: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      { path: '', redirectTo: 'events', pathMatch: 'full' },
      {
        path: 'events',
        children: [
          { path: '', component: EventsComponent }
          // { path: ':id', component: ViewEventComponent },
          // { path: ':id/book', component: BookEventComponent }
        ]
      },
      { path: 'tickets', component: TicketsComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'notifications', component: NotificationsComponent }
    ]
  }
];