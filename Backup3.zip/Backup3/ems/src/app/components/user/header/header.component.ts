import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../../core/authServices/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <header class="navbar navbar-expand-lg navbar-dark">
      <div class="container-fluid">
        <button class="btn btn-link sidebar-toggle" (click)="toggleSidenav.emit()">
          <i class="bi bi-list"></i>
        </button>

        <a class="navbar-brand">
          <i class="bi bi-calendar-event"></i> EMS
        </a>

        <div class="ms-auto d-flex align-items-center">
          <div class="nav-item dropdown">
            <button class="btn btn-link notification-btn position-relative">
              <i class="bi bi-bell"></i>
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                0
              </span>
            </button>
          </div>

          <div class="nav-item dropdown ms-3">
            <button class="btn btn-link profile-btn" (click)="logout()">
              <i class="bi bi-box-arrow-right"></i>
              Logout
            </button>
          </div>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .navbar {
      background: linear-gradient(135deg, #2c3e50, #3498db);
      padding: 1rem;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1040;
    }

    .navbar-brand {
      font-size: 1.5rem;
      font-weight: 600;
      color: white !important;
      cursor: pointer;
    }

    .sidebar-toggle {
      color: white;
      font-size: 1.5rem;
      padding: 0.25rem;
    }

    .notification-btn, .profile-btn {
      color: white;
      font-size: 1.25rem;
      padding: 0.5rem;
    }
  `]
})
export class HeaderComponent {
  @Output() toggleSidenav = new EventEmitter<void>();

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
