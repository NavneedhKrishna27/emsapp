import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';
import * as XLSX from 'xlsx';
import { forkJoin, Subscription } from 'rxjs';
import { AuthService } from '../../../core/authServices/auth.service';
interface EventDetails {
  eventId: number;
  name: string;
  startDate: string;
  endDate: string;
  status: string;
  location: string;
  capacity: number;
  ticketsSold: number;
  price: number;
  revenue: number;
  isActive: boolean;
  availableCapacity: number;
}

interface DashboardStats {
  totalEvents: number;
  ongoingEvents: number;
  upcomingEvents: number;
  completedEvents: number;
  totalRevenue: number;
  totalTicketsSold: number;
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, NgSelectModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit, OnDestroy {
  events: EventDetails[] = [];
  stats: DashboardStats | null = null;
  loading = false;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';
  searchTerm: string = '';
  selectedEventId: number | null = null;
  private subscription: Subscription | null = null;

  constructor(
    private http: HttpClient,
    private authService: AuthService // Add AuthService injection
  ) {}

  ngOnInit() {
    this.fetchDashboardData();
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  private fetchDashboardData() {
    this.loading = true;
    const userId = this.authService.getUserId(); // Now this will work

    this.subscription = forkJoin({
      events: this.http.get<EventDetails[]>(`${this.baseUrl}/Event/user/${userId}/events-details`),
      dashboard: this.http.get<DashboardStats>(`${this.baseUrl}/Event/user/${userId}/dashboard`)
    }).subscribe({
      next: (data) => {
        this.events = data.events;
        this.stats = data.dashboard;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching dashboard data:', error);
        this.error = 'Failed to load report data';
        this.loading = false;
      }
    });
  }

  getProgressBarClass(percentage: number): string {
    if (percentage >= 90) return 'bg-success';
    if (percentage >= 60) return 'bg-info';
    if (percentage >= 30) return 'bg-warning';
    return 'bg-danger';
  }

  downloadReport(event: EventDetails) {
    // Header style
    const headerStyle = {
        fill: { fgColor: { rgb: '4472C4' } },
        font: { color: { rgb: 'FFFFFF' }, bold: true },
        alignment: { horizontal: 'center' }
    };

    // Section header style
    const sectionStyle = {
        fill: { fgColor: { rgb: '8EA9DB' } },
        font: { bold: true },
        alignment: { horizontal: 'left' }
    };

    // Data cell style
    const dataCellStyle = {
        alignment: { horizontal: 'left' },
        font: { color: { rgb: '000000' } }
    };

    // Prepare data with formatting
    const reportData = [
        [{ v: 'EVENT REPORT', t: 's', s: headerStyle }, { v: '', t: 's', s: headerStyle }],
        [{ v: 'Generated on: ' + new Date().toLocaleString(), t: 's', s: dataCellStyle }, { v: '', t: 's' }],
        [{ v: '', t: 's' }, { v: '', t: 's' }],
        
        // Event Details Section
        [{ v: 'EVENT DETAILS', t: 's', s: sectionStyle }, { v: '', t: 's', s: sectionStyle }],
        [{ v: 'Event Name', t: 's', s: dataCellStyle }, { v: event.name, t: 's', s: dataCellStyle }],
        [{ v: 'Status', t: 's', s: dataCellStyle }, { v: event.status, t: 's', s: dataCellStyle }],
        [{ v: 'Start Date', t: 's', s: dataCellStyle }, { v: new Date(event.startDate).toLocaleDateString(), t: 's', s: dataCellStyle }],
        [{ v: 'End Date', t: 's', s: dataCellStyle }, { v: new Date(event.endDate).toLocaleDateString(), t: 's', s: dataCellStyle }],
        [{ v: '', t: 's' }, { v: '', t: 's' }],
        
        // Ticket Statistics Section
        [{ v: 'TICKET STATISTICS', t: 's', s: sectionStyle }, { v: '', t: 's', s: sectionStyle }],
        [{ v: 'Total Capacity', t: 's', s: dataCellStyle }, { v: event.capacity, t: 'n', s: dataCellStyle }],
        [{ v: 'Tickets Sold', t: 's', s: dataCellStyle }, { v: event.ticketsSold, t: 'n', s: dataCellStyle }],
        [{ v: 'Available Capacity', t: 's', s: dataCellStyle }, { v: event.availableCapacity, t: 'n', s: dataCellStyle }],
        [{ v: '', t: 's' }, { v: '', t: 's' }],
        
        // Financial Statistics Section
        [{ v: 'FINANCIAL STATISTICS', t: 's', s: sectionStyle }, { v: '', t: 's', s: sectionStyle }],
        [{ v: 'Ticket Price', t: 's', s: dataCellStyle }, { v: `$${event.price.toFixed(2)}`, t: 's', s: dataCellStyle }],
        [{ v: 'Total Revenue', t: 's', s: dataCellStyle }, { v: `$${event.revenue.toFixed(2)}`, t: 's', s: dataCellStyle }],
        [{ v: '', t: 's' }, { v: '', t: 's' }],
        
        // Location Details Section
        [{ v: 'LOCATION DETAILS', t: 's', s: sectionStyle }, { v: '', t: 's', s: sectionStyle }],
        [{ v: 'Venue', t: 's', s: dataCellStyle }, { v: event.location, t: 's', s: dataCellStyle }]
    ];

    // Create workbook and worksheet
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(reportData);

    // Set column widths
    ws['!cols'] = [
        { wch: 25 }, // Column A width
        { wch: 40 }  // Column B width
    ];

    // Set row heights
    ws['!rows'] = reportData.map(() => ({ hpt: 25 })); // Set all rows to height 25

    // Merge cells for headers
    ws['!merges'] = [
        { s: { r: 0, c: 0 }, e: { r: 0, c: 1 } }, // Title merge
        { s: { r: 3, c: 0 }, e: { r: 3, c: 1 } }, // Event Details merge
        { s: { r: 9, c: 0 }, e: { r: 9, c: 1 } }, // Ticket Statistics merge
        { s: { r: 14, c: 0 }, e: { r: 14, c: 1 } }, // Financial Statistics merge
        { s: { r: 18, c: 0 }, e: { r: 18, c: 1 } }  // Location Details merge
    ];

    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Event Report');

    // Generate Excel file with current timestamp
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    XLSX.writeFile(wb, `event-report-${event.name}-${timestamp}.xlsx`);
  }

  get filteredEvents() {
    return this.events.filter(event =>
      event.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  onSearch(searchTerm: string) {
    this.searchTerm = searchTerm;
  }
}
