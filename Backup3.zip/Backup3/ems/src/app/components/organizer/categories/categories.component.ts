import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

interface Category {
  categoryID: number;
  categoryName: string;
}

@Component({
  selector: 'app-categories',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {
  categories: Category[] = [];
  categoryForm!: FormGroup;
  loading = false;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.initForm();
    this.fetchCategories();
  }

  private initForm() {
    this.categoryForm = this.fb.group({
      categoryName: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  private fetchCategories() {
    this.loading = true;
    this.http.get<Category[]>(`${this.baseUrl}/Categories`)
      .subscribe({
        next: (categories) => {
          this.categories = categories;
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load categories';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  onSubmit() {
    if (this.categoryForm.valid) {
      const category: Category = {
        categoryID: 0,
        categoryName: this.categoryForm.get('categoryName')?.value?.trim()
      };

      this.http.post<Category>(`${this.baseUrl}/Categories`, category)
        .subscribe({
          next: () => {
            // Reset form and refresh categories
            this.categoryForm.reset();
            this.fetchCategories();
          },
          error: () => {
            // Even if we get an error, try to refresh categories as the item might have been added
            this.fetchCategories();
            this.categoryForm.reset();
          }
        });
    }
  }
}
