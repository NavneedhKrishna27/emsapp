import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../../core/authServices/auth.service';
import { take } from 'rxjs/operators';

interface Location {
  locationID: number;
  locationName: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

@Component({
  selector: 'app-edit-event',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './edit-event.component.html',
  styleUrls: ['./edit-event.component.css']
})
export class EditEventComponent implements OnInit {
  eventId!: number;
  eventForm!: FormGroup;
  loading = true;
  error: string | null = null;
  locations: Location[] = [];
  categories: Category[] = [];
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private fb: FormBuilder,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.initForm();
    this.eventId = parseInt(this.route.snapshot.paramMap.get('id') || '0', 10);
    this.fetchData();
  }

  private async fetchData() {
    try {
      const [locations, categories] = await Promise.all([
        this.http.get<Location[]>(`${this.baseUrl}/Location`).toPromise(),
        this.http.get<Category[]>(`${this.baseUrl}/Categories`).toPromise()
      ]);

      if (locations && categories) {
        this.locations = locations;
        this.categories = categories;
        await this.fetchEventDetails();
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      this.error = 'Failed to load required data';
      this.loading = false;
    }
  }

  private async fetchEventDetails() {
    try {
      const event = await this.http.get<any>(`${this.baseUrl}/Event/view-event/${this.eventId}`).toPromise();
      if (event) {
        this.eventForm.patchValue({
          name: event.name,
          description: event.description,
          startDate: event.startDate.split('T')[0],
          endDate: event.endDate.split('T')[0],
          locationID: event.locationID,
          categoryID: event.categoryID,
          price: event.price,
          isPrice: event.isPrice,
          thumbnailUrl: event.thumbnailUrl,
          image1Url: event.image1Url,
          image2Url: event.image2Url,
          image3Url: event.image3Url,
          image4Url: event.image4Url
        });
      }
      this.loading = false;
    } catch (error) {
      console.error('Error fetching event:', error);
      this.error = 'Failed to load event details';
      this.loading = false;
    }
  }

  private initForm() {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      locationID: ['', Validators.required],
      categoryID: ['', Validators.required],
      price: [0],
      isPrice: [true],
      thumbnailUrl: [''],
      image1Url: [''],
      image2Url: [''],
      image3Url: [''],
      image4Url: ['']
    });
  }

  onSubmit() {
    if (this.eventForm.valid) {
      this.loading = true;
      this.error = null;

      const userId = this.authService.getUserId(); // Get userId directly from auth service
      if (!userId) {
        this.error = 'User not authenticated';
        this.loading = false;
        return;
      }

      const eventData = {
        ...this.eventForm.value,
        eventID: this.eventId,
        isActive: true,
        userID: userId // Use the actual userId from auth service
      };

      console.log('Updating event with data:', eventData);

      this.http.put(`${this.baseUrl}/Event/edit-event`, eventData).subscribe({
        next: (response) => {
          console.log('Update successful:', response);
          this.loading = false;
          this.router.navigate(['/organizer/events/view', this.eventId]);
        },
        error: (error) => {
          console.error('Error updating event:', error);
          this.error = 'Failed to update event. Please try again.';
          this.loading = false;
        }
      });
    } else {
      console.log('Form validation errors:', this.eventForm.errors);
      this.markFormGroupTouched(this.eventForm);
    }
  }

  // Add this helper method to show validation errors
  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  cancel() {
    this.router.navigate(['/organizer/events']);
  }
}