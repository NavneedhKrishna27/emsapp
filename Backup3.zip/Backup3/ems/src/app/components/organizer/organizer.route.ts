import { Routes } from '@angular/router';
import { OrganizerComponent } from './organizer.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EventsComponent } from './events/events.component';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { EditEventComponent } from './events/edit-event/edit-event.component';
import { ViewEventComponent } from './events/view-event/view-event.component';
import { CategoriesComponent } from './categories/categories.component';
import { LocationsComponent } from './locations/locations.component';
import { ReportsComponent } from './reports/reports.component';
import { ProfileComponent } from './profile/profile.component';
import { AuthGuard } from '../../core/guards/auth.guard';
import { CreateLocationComponent } from './locations/create-location/create-location.component';
import { ViewLocationComponent } from './locations/view-location/view-location.component';
import { EditLocationComponent } from './locations/edit-location/edit-location.component';

export const ORGANIZER_ROUTES: Routes = [
  {
    path: '',
    component: OrganizerComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { 
        path: 'events',
        children: [
          { path: '', component: EventsComponent },
          { path: 'create', component: CreateEventComponent },
          { path: 'edit/:id', component: EditEventComponent },
          { path: 'view/:id', component: ViewEventComponent }
        ]
      },
      { path: 'categories', component: CategoriesComponent },
      {
        path: 'locations',
        children: [
          { path: '', component: LocationsComponent },
          { path: 'create', component: CreateLocationComponent },
          { path: 'view/:id', component: ViewLocationComponent },
          { path: 'edit/:id', component: EditLocationComponent }
        ]
      },
      { path: 'reports', component: ReportsComponent },
      { path: 'profile', component: ProfileComponent }
    ],
    canActivate: [AuthGuard],
    data: { roles: ['Organizer'] }
  }
];