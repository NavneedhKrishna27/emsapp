import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../../core/authServices/auth.service';

@Component({
  selector: 'app-organizer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="wrapper">
      <!-- Static Sidenav -->
      <nav class="sidebar bg-light">
        <div class="text-center py-4">
          <h4 class="fw-bold">Eventify</h4>
        </div>
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link" routerLink="dashboard" routerLinkActive="active">
              <i class="bi bi-speedometer2 me-2"></i>
              Dashboard
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" routerLink="events" routerLinkActive="active">
              <i class="bi bi-calendar-event me-2"></i>
              Events
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" routerLink="categories" routerLinkActive="active">
              <i class="bi bi-tags me-2"></i>
              Categories
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" routerLink="locations" routerLinkActive="active">
              <i class="bi bi-geo-alt me-2"></i>
              Locations
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" routerLink="reports" routerLinkActive="active">
              <i class="bi bi-graph-up me-2"></i>
              Reports
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" routerLink="profile" routerLinkActive="active">
              <i class="bi bi-person me-2"></i>
              Profile
            </a>
          </li>
          <!-- Logout Button -->
          <li class="nav-item mt-auto">
            <a class="nav-link logout-link" (click)="logout()">
              <i class="bi bi-box-arrow-right me-2"></i>
              Logout
            </a>
          </li>
        </ul>
      </nav>
      <!-- Main Content -->
      <main class="content">
        <router-outlet></router-outlet>
      </main>
    </div>
  `,
  styles: [`
    .wrapper {
      display: flex;
      width: 100%;
      height: 100vh;
    }

    .sidebar {
      width: 250px;
      min-width: 250px;
      position: fixed;
      top: 0;
      left: 0;
      height: 100vh;
      z-index: 100;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      overflow-y: auto;
      display: flex;
      flex-direction: column;
    }

    .nav {
      flex-grow: 1;
      display: flex;
      flex-direction: column;
    }

    .content {
      margin-left: 250px;
      width: calc(100% - 250px);
      padding: 20px;
    }

    .nav-link {
      color: #333;
      padding: 0.8rem 1rem;
      border-radius: 5px;
      margin: 2px 8px;
      transition: all 0.3s;
    }

    .nav-link:hover {
      background-color: #e9ecef;
      cursor: pointer;
    }

    .nav-link.active {
      color: #0d6efd;
      background-color: #e7f1ff;
    }

    .logout-link {
      color: #dc3545 !important;
      margin-top: auto;
      border-top: 1px solid #dee2e6;
      margin-top: 2rem;
      padding-top: 1rem;
    }

    .logout-link:hover {
      background-color: #ffebee !important;
    }

    @media (max-width: 768px) {
      .sidebar {
        position: fixed;
        left: -250px;
      }

      .content {
        margin-left: 0;
        width: 100%;
      }
    }
  `]
})
export class OrganizerComponent {
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
