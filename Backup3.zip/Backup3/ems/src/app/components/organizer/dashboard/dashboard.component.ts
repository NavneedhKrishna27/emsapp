import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { forkJoin } from 'rxjs';
import { Router } from '@angular/router';

import { AuthService } from '../../../core/authServices/auth.service';

interface DashboardStats {
  totalEvents: number;
  ongoingEvents: number;
  upcomingEvents: number;
  completedEvents: number;
  totalRevenue: number;
  totalTicketsSold: number;
}

interface EventDetails {
  eventId: number;
  name: string;
  startDate: string;
  endDate: string;
  status: string;
  location: string;
  capacity: number;
  ticketsSold: number;
  price: number;
  revenue: number;
  isActive: boolean;
  availableCapacity: number;
}

interface EventProgress {
  event: EventDetails;
  revenue: number;
  ticketsSold: number;
  revenuePercentage: number;
  ticketsPercentage: number;
  maxPossibleRevenue: number;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats = {
    totalEvents: 0,
    ongoingEvents: 0,
    upcomingEvents: 0,
    completedEvents: 0,
    totalRevenue: 0,
    totalTicketsSold: 0
  };

  eventProgress: EventProgress[] = [];
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';
  sortBy: string = 'name';
  sortDirection: 'asc' | 'desc' = 'asc';

  constructor(
    private http: HttpClient, 
    private router: Router,
    private authService: AuthService  // Add AuthService to constructor
  ) {}

  ngOnInit() {
    this.fetchDashboardData();
  }

  private fetchDashboardData() {
    const userId = this.authService.getUserId() ; // Get this from auth service
    forkJoin({
      dashboard: this.http.get<DashboardStats>(`${this.baseUrl}/Event/user/${userId}/dashboard`),
      events: this.http.get<EventDetails[]>(`${this.baseUrl}/Event/user/${userId}/events-details`)
    }).subscribe({
      next: (data) => {
        this.stats = data.dashboard;

        // Simplify progress calculation using API values
        this.eventProgress = data.events.map(event => ({
          event,
          revenue: event.revenue,
          ticketsSold: event.ticketsSold,
          revenuePercentage: (event.revenue / (event.price * event.capacity)) * 100,
          ticketsPercentage: (event.ticketsSold / event.capacity) * 100,
          maxPossibleRevenue: event.price * event.capacity
        }));

        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching dashboard data:', error);
        this.error = 'Failed to load dashboard data';
        this.loading = false;
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'active': return 'badge-active';
      case 'completed': return 'badge-completed';
      case 'upcoming': return 'badge-upcoming';
      default: return '';
    }
  }

  getStatusIcon(event: EventDetails): string {
    const status = event.status.toLowerCase();
    switch (status) {
      case 'active': return 'bi-play-circle-fill';
      case 'upcoming': return 'bi-calendar-event';
      case 'completed': return 'bi-check-circle-fill';
      default: return 'bi-question-circle';
    }
  }

  getProgressBarClass(percentage: number): string {
    if (percentage < 25) return 'bg-danger';
    if (percentage < 75) return 'bg-warning';
    return 'bg-success';
  }

  get sortedEventProgress(): EventProgress[] {
    return [...this.eventProgress].sort((a, b) => {
      let comparison = 0;
      switch (this.sortBy) {
        case 'name':
          comparison = a.event.name.localeCompare(b.event.name);
          break;
        case 'revenue':
          comparison = a.revenue - b.revenue;
          break;
        case 'tickets':
          comparison = a.ticketsSold - b.ticketsSold;
          break;
        case 'status':
          comparison = a.event.status.localeCompare(b.event.status);
          break;
      }
      return this.sortDirection === 'asc' ? comparison : -comparison;
    });
  }

  sortEvents(criteria: string) {
    if (this.sortBy === criteria) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = criteria;
      this.sortDirection = 'asc';
    }
  }

  getSortIcon(column: string): string {
    if (this.sortBy !== column) return 'bi-arrow-down-up';
    return this.sortDirection === 'asc' ? 'bi-arrow-up' : 'bi-arrow-down';
  }

  viewEvent(eventId: number) {
    this.router.navigate(['/events/view', eventId]);
  }

  getEventStatus(event: EventDetails): string {
    return event.status;
  }
}
