import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}

@Component({
  selector: 'app-view-location',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './view-location.component.html',
  styleUrls: ['./view-location.component.css']
})
export class ViewLocationComponent implements OnInit {
  location: Location | null = null;
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.fetchLocationDetails(Number(id));
  }

  private fetchLocationDetails(id: number) {
    this.http.get<Location>(`${this.baseUrl}/Location/${id}`)
      .subscribe({
        next: (location) => {
          this.location = location;
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load location details';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  onBack() {
    this.router.navigate(['/organizer/locations']);
  }
}
