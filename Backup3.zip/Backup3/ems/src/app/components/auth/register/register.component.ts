import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink, RouterModule, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../../core/authServices/auth.service';
import { CommonModule } from '@angular/common';

interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  contactNumber: string;
  userType: string;
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterLink, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  isSubmitting = false;
  error: string | null = null;
  showSuccessMessage = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    const userType = this.route.snapshot.data['userType'] || 'User';
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      contactNumber: ['', Validators.required],
      userType: [userType]
    });
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      this.isSubmitting = true;
      this.error = null;

      const registerData: RegisterRequest = {
        email: this.registerForm.value.email,
        password: this.registerForm.value.password,
        name: this.registerForm.value.name,
        contactNumber: this.registerForm.value.contactNumber,
        userType: 'User' // Default to User role
      };

      this.authService.register(registerData).subscribe({
        next: (response) => {
          this.isSubmitting = false;
          // Show success message
          this.showSuccessMessage = true;
          // Navigate to login page after successful registration
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000); // Wait 2 seconds before redirecting
        },
        error: (error) => {
          this.isSubmitting = false;
          this.error = error.message;
          console.error('Registration failed:', error);
        }
      });
    }
  }
}
