export interface Icategory {
  categoryID: number;
  categoryName: string;
}
