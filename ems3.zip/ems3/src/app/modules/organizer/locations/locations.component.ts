import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}
@Component({
  selector: 'app-locations',
  standalone: true,
  imports: [
    CommonModule, 
    RouterModule,
    RouterLink,
    FormsModule
  ],
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.css']
})
export class LocationsComponent implements OnInit {
  locations: Location[] = [];
  loading = false;
  error: string | null = null;
  searchTerm = '';
  currentPage = 1;
  itemsPerPage = 5;
  private baseUrl = 'https://localhost:7149/api';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchLocations();
  }

  fetchLocations() {
    this.loading = true;
    this.http.get<Location[]>(`${this.baseUrl}/Location`)
      .subscribe({
        next: (data) => {
          this.locations = data;
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load locations';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  get filteredLocations(): Location[] {
    return this.locations.filter(location =>
      location.locationName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      location.city.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  get paginatedLocations(): Location[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.filteredLocations.slice(startIndex, startIndex + this.itemsPerPage);
  }

  onSearch(event: Event): void {
    this.searchTerm = (event.target as HTMLInputElement).value;
    this.currentPage = 1;
  }

  deleteLocation(id: number) {
    if (confirm('Are you sure you want to delete this location?')) {
      this.http.delete(`${this.baseUrl}/Location/${id}`)
        .subscribe({
          next: () => {
            this.locations = this.locations.filter(loc => loc.locationID !== id);
          },
          error: (error) => {
            console.error('Error deleting location:', error);
            alert('Failed to delete location');
          }
        });
    }
  }

  get totalPages(): number {
    return Math.ceil(this.filteredLocations.length / this.itemsPerPage);
  }

  onPageChange(page: number): void {
    this.currentPage = page;
  }
}