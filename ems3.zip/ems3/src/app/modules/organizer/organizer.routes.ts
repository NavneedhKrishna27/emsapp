import { Routes } from '@angular/router';
import { OrganizerComponent } from './organizer.component';
import { EventsComponent } from './events/events.component';
import { EventListComponent } from './events/event-list/event-list.component';
import { ViewEventComponent } from './events/view-event/view-event.component';
import { EditEventComponent } from './events/edit-event/edit-event.component';
import { CreateEventComponent } from './events/create-event/create-event.component';
import { LocationsComponent } from './locations/locations.component';
import { EditLocationComponent } from './locations/edit-location/edit-location.component';
import { CreateLocationComponent } from './locations/create-location/create-location.component';
import { ViewLocationComponent } from './locations/view-location/view-location.component';

export const ORGANIZER_ROUTES: Routes = [
  {
    path: '',
    component: OrganizerComponent,
    children: [
      {
        path: 'dashboard',
        loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      {
        path: 'events',
        children: [
          {
            path: '',
            component: EventsComponent
          },
          {
            path: 'view/:id',
            component: ViewEventComponent
          },
          {
            path: 'edit/:id',
            component: EditEventComponent
          },
          {
            path: 'create',
            component: CreateEventComponent
          }
        ]
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/profile.component').then(m => m.ProfileComponent)
      },
      {
        path: 'reports',
        loadComponent: () => import('./reports/reports.component').then(m => m.ReportsComponent)
      },
      {
        path: 'locations',
        children: [
          {
            path: '',
            component: LocationsComponent
          },
          {
            path: 'create',
            component: CreateLocationComponent
          },
          {
            path: 'view/:id',
            component: ViewLocationComponent
          },
          {
            path: 'edit/:id',
            component: EditLocationComponent
          }
        ]
      },
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      }
    ]
  }
];
