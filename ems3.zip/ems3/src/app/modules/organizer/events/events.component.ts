import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import { map } from 'rxjs/operators';

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

interface Event {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  location: string;
  locationID: number;
  categoryID: number;
  price: number;
  isPrice: boolean;
  organizerID: number;
  bookedCapacity: number;
}

interface EventUser {
  userID: number;
  name: string;
  email: string;
  contactNumber: string;
}

interface EventStats {
  ticketsSold: number;
  revenue: number;
  status: string;
}

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [
    CommonModule, 
    RouterModule,
    RouterLink
  ],
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  private baseUrl = 'https://localhost:7149/api';
  events: Event[] = [];
  locations: Location[] = [];
  categories: Category[] = [];
  currentEvents: Event[] = [];
  upcomingEvents: Event[] = [];
  completedEvents: Event[] = [];
  eventStats: Map<number, EventStats> = new Map();

  filteredEvents: Event[] = [];
  loading = false;
  error: string | null = null;

  searchTerm: string = '';
  searchSubject = new Subject<string>();
  currentPage = 1;
  itemsPerPage = 5;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.loading = true;
    this.fetchInitialData();

    this.searchSubject.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(term => {
      this.searchTerm = term;
      this.filterEvents();
      this.currentPage = 1;
    });
  }

  private fetchInitialData() {
    forkJoin({
      locations: this.http.get<Location[]>(`${this.baseUrl}/Location`),
      categories: this.http.get<Category[]>(`${this.baseUrl}/Categories`),
      current: this.http.get<Event[]>(`${this.baseUrl}/Event/current`),
      upcoming: this.http.get<Event[]>(`${this.baseUrl}/Event/upcoming`),
      completed: this.http.get<Event[]>(`${this.baseUrl}/Event/completed`)
    }).subscribe({
      next: (data) => {
        this.locations = data.locations;
        this.categories = data.categories;
        this.currentEvents = data.current;
        this.upcomingEvents = data.upcoming;
        this.completedEvents = data.completed;
        this.events = [...this.currentEvents, ...this.upcomingEvents, ...this.completedEvents];
        this.filteredEvents = [...this.events];
        this.fetchEventStats();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching initial data:', error);
        this.error = 'Failed to load event data';
        this.loading = false;
      }
    });
  }

  // Add this helper method to calculate event status
  private calculateEventStatus(event: Event): string {
    const now = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (!startDate || !endDate) return 'Unknown';
    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  // Update the fetchEventStats method
  private fetchEventStats() {
    this.events.forEach(event => {
      forkJoin({
        revenue: this.http.get<number>(`${this.baseUrl}/Event/${event.eventID}/revenue`),
        ticketsSold: this.http.get<number>(`${this.baseUrl}/Event/${event.eventID}/tickets-sold`)
      }).subscribe({
        next: (stats) => {
          const actualRevenue = event.isPrice ? (Number(stats.revenue) || (event.price * stats.ticketsSold)) : 0;
          this.eventStats.set(event.eventID, {
            ticketsSold: stats.ticketsSold,
            revenue: actualRevenue,
            status: this.calculateEventStatus(event)
          });
        },
        error: (error) => {
          console.error(`Error fetching stats for event ${event.eventID}:`, error);
          const fallbackTickets = event.bookedCapacity || 0;
          const fallbackRevenue = event.isPrice ? (event.price * fallbackTickets) : 0;
          this.eventStats.set(event.eventID, {
            ticketsSold: fallbackTickets,
            revenue: fallbackRevenue,
            status: this.calculateEventStatus(event)
          });
        }
      });
    });
  }

  getLocationName(locationId: number): string {
    return this.locations.find(loc => loc.locationID === locationId)?.locationName || 'Unknown Location';
  }

  getCategoryName(categoryId: number): string {
    return this.categories.find(cat => cat.categoryID === categoryId)?.categoryName || 'Unknown Category';
  }

  getEventStats(eventId: number): EventStats {
    return this.eventStats.get(eventId) || { ticketsSold: 0, revenue: 0, status: 'Unknown' };
  }

  // Update the totalRevenue getter
  get totalRevenue(): number {
    let total = 0;
    this.events.forEach(event => {
      const stats = this.eventStats.get(event.eventID);
      if (stats && (event.isPrice)) {
        // For paid events, use actual revenue from stats
        total += Number(stats.revenue) || (event.price * stats.ticketsSold);
      }
    });
    return total;
  }

  get totalTicketsSold(): number {
    return Array.from(this.eventStats.values())
      .reduce((sum, stats) => sum + stats.ticketsSold, 0);
  }

  get activeEventsCount(): number {
    return this.currentEvents.length;
  }

  get upcomingEventsCount(): number {
    return this.upcomingEvents.length;
  }

  get completedEventsCount(): number {
    return this.completedEvents.length;
  }

  get totalPages(): number {
    return Math.ceil(this.filteredEvents.length / this.itemsPerPage);
  }

  get paginatedEvents(): Event[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredEvents.slice(startIndex, endIndex);
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  setPage(page: number): void {
    if (page < 1) page = 1;
    if (page > this.totalPages) page = this.totalPages;
    this.currentPage = page;
  }

  getPaginationInfo(): string {
    const start = (this.currentPage - 1) * this.itemsPerPage + 1;
    const end = Math.min(this.currentPage * this.itemsPerPage, this.filteredEvents.length);
    return `Showing ${start} to ${end} of ${this.filteredEvents.length} entries`;
  }

  onSearch(event: any) {
    const term = event.target.value;
    this.searchSubject.next(term);
  }

  private filterEvents() {
    if (!this.searchTerm.trim()) {
      this.filteredEvents = [...this.events];
      return;
    }

    const searchTermLower = this.searchTerm.toLowerCase();
    this.filteredEvents = this.events.filter(event =>
      event.name.toLowerCase().includes(searchTermLower) ||
      this.getLocationName(event.locationID).toLowerCase().includes(searchTermLower) ||
      this.getCategoryName(event.categoryID).toLowerCase().includes(searchTermLower) ||
      event.description.toLowerCase().includes(searchTermLower) ||
      new Date(event.startDate).toLocaleDateString().includes(searchTermLower) ||
      new Date(event.endDate).toLocaleDateString().includes(searchTermLower)
    );
  }

  openDeleteConfirmation(event: Event) {
    if (confirm(`Are you sure you want to delete "${event.name}"?`)) {
      this.http.delete(`${this.baseUrl}/Event/delete-event/${event.eventID}`).subscribe({
        next: () => {
          // Remove event from local arrays
          this.events = this.events.filter(e => e.eventID !== event.eventID);
          this.filteredEvents = this.filteredEvents.filter(e => e.eventID !== event.eventID);
          // Update stats
          this.eventStats.delete(event.eventID);
          // Show success message
          alert('Event deleted successfully');
        },
        error: (error) => {
          console.error('Error deleting event:', error);
          alert('Failed to delete event. Please try again.');
        }
      });
    }
  }

  // Update the getStatusClass method to handle all possible statuses
  getStatusClass(event: Event): string {
    const status = this.getEventStats(event.eventID).status.toLowerCase();
    switch (status) {
      case 'active': return 'bg-warning text-dark'; // Yellow with dark text for better visibility
      case 'completed': return 'bg-success';
      case 'upcoming': return 'bg-primary';
      case 'cancelled': return 'bg-danger';
      default: return 'bg-secondary';
    }
  }

  // Update the getStatusIcon method to match the statuses
  getStatusIcon(event: Event): string {
    const status = this.getEventStats(event.eventID).status.toLowerCase();
    switch (status) {
      case 'active': return 'bi-play-circle';
      case 'completed': return 'bi-check-circle';
      case 'upcoming': return 'bi-calendar';
      case 'cancelled': return 'bi-x-circle';
      default: return 'bi-question-circle';
    }
  }

  getEventStatus(event: Event): string {
    return this.getEventStats(event.eventID).status;
  }

  get eventlist(): Event[] {
    return this.events;
  }

  get activeEvents(): number {
    return this.events.filter(e => this.getEventStats(e.eventID).status === 'Active').length;
  }

  get cancelledEvents(): number {
    return this.events.filter(e => this.getEventStats(e.eventID).status === 'Cancelled').length;
  }
}
