import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';

interface Location {
  locationID: number;
  locationName: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

interface CreateEventRequest {
  eventID: number;
  name: string;
  categoryID: number;
  locationID: number;
  startDate: string;
  endDate: string;
  userID: number;
  description: string;
  isPrice: boolean;
  price: number;
  isActive: boolean;
  bookedCapacity: number;
}

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class CreateEventComponent implements OnInit, OnDestroy {
  eventForm!: FormGroup;
  loading = true;
  error: string | null = null;
  apiErrors: any = null;
  locations: Location[] = [];
  categories: Category[] = [];
  private baseUrl = 'https://localhost:7149/api';
  private subscriptions: Subscription[] = [];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.initForm();
    this.fetchData();
    
    // Debug routing
    console.log('Current route config:', this.router.config);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  clearApiError(fieldName: string) {
    if (this.apiErrors && this.apiErrors[fieldName]) {
      delete this.apiErrors[fieldName];
    }
  }

  private initForm() {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      locationID: [0, Validators.required],
      categoryID: [0, Validators.required],
      isPrice: [false],
      price: [0],
    }, { validators: this.dateValidator });

    // Subscribe to value changes to reset API errors
    this.subscriptions.push(
      this.eventForm.valueChanges.subscribe(() => {
        if (this.apiErrors) {
          this.apiErrors = null;
        }
      })
    );
  }

  // Add date validation
  private dateValidator(group: AbstractControl): ValidationErrors | null {
    const start = group.get('startDate')?.value;
    const end = group.get('endDate')?.value;

    if (start && end && new Date(start) > new Date(end)) {
      return { dateRange: true };
    }
    return null;
  }

  private async fetchData() {
    try {
      const [locations, categories] = await Promise.all([
        this.http.get<Location[]>(`${this.baseUrl}/Location`).toPromise(),
        this.http.get<Category[]>(`${this.baseUrl}/Categories`).toPromise()
      ]);

      if (locations && categories) {
        this.locations = locations;
        this.categories = categories;
        this.loading = false;
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      this.error = 'Failed to load required data';
      this.loading = false;
    }
  }

  onSubmit() {
    if (this.eventForm.valid) {
      this.loading = true;
      
      const formData: CreateEventRequest = {
        eventID: 0,
        name: this.eventForm.get('name')?.value?.trim() || '',
        description: this.eventForm.get('description')?.value?.trim() || '',
        categoryID: Number(this.eventForm.get('categoryID')?.value) || 0,
        locationID: Number(this.eventForm.get('locationID')?.value) || 0,
        startDate: new Date(this.eventForm.get('startDate')?.value).toISOString(),
        endDate: new Date(this.eventForm.get('endDate')?.value).toISOString(),
        userID: 0,
        isPrice: this.eventForm.get('isPrice')?.value || false,
        price: this.eventForm.get('isPrice')?.value ? Number(this.eventForm.get('price')?.value) || 0 : 0,
        isActive: true,
        bookedCapacity: 0
      };

      // Log the request data for debugging
      console.log('Submitting form data:', formData);

      this.http.post<any>(`${this.baseUrl}/Event/add-event`, formData)
        .subscribe({
          next: (response) => {
            console.log('Success:', response);
            // Try these navigation paths in order until one works
            this.router.navigate(['/events'])
              .catch(() => this.router.navigate(['/organizer/events']))
              .catch(() => this.router.navigate(['../events'], { relativeTo: this.route }));
          },
          error: (error) => {
            console.error('Error:', error);
            if (error.status === 400 && error.error?.errors) {
              this.apiErrors = error.error.errors;
            } else {
              this.error = 'An error occurred while creating the event.';
            }
            this.loading = false;
          },
          complete: () => {
            this.loading = false;
          }
        });
    } else {
      this.markFormGroupTouched(this.eventForm);
      console.log('Form validation errors:', this.eventForm.errors);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
