import { Component } from '@angular/core';

@Component({
  selector: 'app-bookings',
  imports: [],
  templateUrl: './bookings.component.html',
  styleUrl: './bookings.component.css'
})
export class BookingsComponent {

}
