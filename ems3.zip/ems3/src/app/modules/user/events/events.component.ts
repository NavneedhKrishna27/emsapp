import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface Event {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  isPrice: boolean;
  price: number;
  locationID: number;
  categoryID: number;
  isActive: boolean;
  bookedCapacity: number;
  image?: string;
  venue?: string;
}

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <!-- Hero Section -->
    <section class="hero-section mb-4">
      <div class="container">
        <h1>Discover Events</h1>
        <p class="lead">Find and book the best events in your city</p>
      </div>
    </section>

    <!-- Category Pills -->
    <div class="container mb-4">
      <div class="category-pills">
        <button class="btn btn-pill active">All Events</button>
        <button class="btn btn-pill">Today</button>
        <button class="btn btn-pill">This Weekend</button>
        <button class="btn btn-pill">Music</button>
        <button class="btn btn-pill">Sports</button>
        <button class="btn btn-pill">Theatre</button>
      </div>
    </div>

    <!-- Events Grid -->
    <div class="container">
      <div class="row g-4">
        <div class="col-md-6 col-lg-4" *ngFor="let event of events">
          <div class="event-card">
            <div class="event-image">
              <img [src]="event.image || 'assets/placeholder.jpg'" [alt]="event.name">
              <div class="event-overlay">
                <span class="badge" [ngClass]="event.isPrice ? 'bg-primary' : 'bg-success'">
                  {{ event.isPrice ? '₹' + event.price : 'Free' }}
                </span>
              </div>
            </div>
            <div class="event-content">
              <h5 class="event-title">{{ event.name }}</h5>
              <p class="event-venue">
                <i class="bi bi-geo-alt"></i> {{ event.venue }}
              </p>
              <p class="event-date">
                <i class="bi bi-calendar3"></i> {{ event.startDate | date:'mediumDate' }}
              </p>
              <button class="btn btn-primary w-100">Book Now</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .hero-section {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 4rem 0;
      text-align: center;
    }

    .category-pills {
      display: flex;
      gap: 1rem;
      overflow-x: auto;
      padding-bottom: 1rem;
    }

    .btn-pill {
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      border: 1px solid #dee2e6;
      white-space: nowrap;
    }

    .btn-pill.active {
      background: #4299e1;
      color: white;
      border-color: #4299e1;
    }

    .event-card {
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      transition: transform 0.2s;
      background: white;
    }

    .event-card:hover {
      transform: translateY(-5px);
    }

    .event-image {
      position: relative;
      aspect-ratio: 16/9;
    }

    .event-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .event-overlay {
      position: absolute;
      top: 1rem;
      right: 1rem;
    }

    .event-content {
      padding: 1.5rem;
    }

    .event-title {
      margin-bottom: 0.5rem;
      font-weight: 600;
    }

    .event-venue, .event-date {
      color: #666;
      font-size: 0.9rem;
      margin-bottom: 0.5rem;
    }

    .event-venue i, .event-date i {
      margin-right: 0.5rem;
    }
  `]
})
export class EventsComponent implements OnInit {
  events: Event[] = [];
  loading: boolean = true;
  error: string | null = null;
  baseUrl: string = 'https://localhost:7149/api';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEvents();
  }

  private async fetchEvents() {
    try {
      this.loading = true;
      const events = await this.http.get<Event[]>(`${this.baseUrl}/Event/index`).toPromise();
      this.events = events || [];
    } catch (error) {
      console.error('Error fetching events:', error);
      this.error = 'Failed to load events';
    } finally {
      this.loading = false;
    }
  }
}
