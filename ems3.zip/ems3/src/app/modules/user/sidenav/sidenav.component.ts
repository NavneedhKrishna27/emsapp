import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent {
  @Input() isOpen = false;
  @Output() close = new EventEmitter<void>();

  menuItems = [
    { path: 'events', icon: 'bi-calendar2-event', label: 'Events' },
    { path: 'bookings', icon: 'bi-ticket-perforated', label: 'My Bookings' },
    { path: 'profile', icon: 'bi-person', label: 'Profile' }
  ];

  onClose() {
    this.close.emit();
  }
}
