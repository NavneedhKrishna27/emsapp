import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

interface UserProfile {
  userID: number;
  name: string;
  email: string;
  contactNumber: string;
  userType: string;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile: UserProfile | null = null;
  loading = true;
  error: string | null = null;
  successMessage: string | null = null;
  isEditing = false;
  private baseUrl = 'https://localhost:7149/api';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchUserProfile('3');
  }

  private fetchUserProfile(userId: string) {
    this.http.get<UserProfile>(`${this.baseUrl}/User/${userId}`)
      .subscribe({
        next: (profile) => {
          this.profile = profile;
          this.loading = false;
        },
        error: (error) => {
          console.error('Error fetching profile:', error);
          this.error = 'Failed to load profile';
          this.loading = false;
        }
      });
  }

  updateProfile() {
    if (!this.profile) return;

    const updateData = {
      name: this.profile.name,
      contactNumber: this.profile.contactNumber,
      userType: this.profile.userType
    };

    this.loading = true;
    this.error = null;
    this.successMessage = null;

    this.http.put(`${this.baseUrl}/User/${this.profile.userID}`, updateData)
      .subscribe({
        next: () => {
          this.loading = false;
          this.isEditing = false;
          this.successMessage = 'Profile updated successfully';
          setTimeout(() => this.successMessage = null, 3000);
        },
        error: (error) => {
          console.error('Error updating profile:', error);
          this.error = 'Failed to update profile';
          this.loading = false;
        }
      });
  }
}
