import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { HttpClient } from '@angular/common/http';

interface OrganizerProfile {
  userID: number;
  name: string;
  email: string;
  contactNumber: string;
  userType: string;
  eventsCreated: number;
  totalRevenue: number;
}

@Component({
  selector: 'app-organizer',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './organizer.component.html',
  styleUrls: ['./organizer.component.css']
})
export class OrganizerComponent implements OnInit {
  organizerProfile: OrganizerProfile | null = null;
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private authService: AuthService,
    private http: HttpClient
  ) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user?.UserID) {
      this.fetchOrganizerProfile(user.UserID);
    } else {
      this.error = 'Unauthorized access';
      this.loading = false;
    }
  }

  private fetchOrganizerProfile(userId: string) {
    const token = this.authService.getToken();

    if (!token) {
      this.error = 'Authorization required';
      this.loading = false;
      return;
    }

    this.http.get<OrganizerProfile>(
      `${this.baseUrl}/User/${userId}`,
      {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      }
    ).subscribe({
      next: (profile) => {
        this.organizerProfile = profile;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching organizer profile:', error);
        this.loading = false;

        if (error.status === 403) {
          this.error = 'You can only view your own profile';
        } else if (error.status === 401) {
          this.error = 'Please login again';
          this.authService.logout();
        } else {
          this.error = 'Failed to load organizer profile';
        }
      }
    });
  }
}
