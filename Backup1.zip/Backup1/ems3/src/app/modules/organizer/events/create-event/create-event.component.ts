import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import { FileUploadService } from '../../../../services/file-upload.service';

interface Location {
  locationID: number;
  locationName: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

interface CreateEventRequest {
  eventID: number;
  name: string;
  categoryID: number;
  locationID: number;
  startDate: string;
  endDate: string;
  userID: number;
  description: string;
  isPrice: boolean;
  price: number;
  isActive: boolean;
  bookedCapacity: number;
}

interface EventData {
  eventID: number;
  name: string;
  categoryID: number;
  locationID: number;
  startDate: string;
  endDate: string;
  userID: number;
  description: string;
  isPrice: boolean;
  price: number;
  isActive: boolean;
  bookedCapacity: number;
  thumbnailUrl: string;
  image1Url: string;
  image2Url: string;
  image3Url: string;
  image4Url: string;
}

// Add this interface for error handling
interface ApiError {
  message?: string;
  error?: any;
  status?: number;
}

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  providers: [] // Remove FileService from here since we're using providedIn: 'root'
})
export class CreateEventComponent implements OnInit, OnDestroy {
  eventForm!: FormGroup;
  loading = true;
  error: string | null = null;
  apiErrors: any = null;
  locations: Location[] = [];
  categories: Category[] = [];
  private baseUrl = 'https://localhost:7149/api';
  private subscriptions: Subscription[] = [];

  thumbnailFile: File | null = null;
  thumbnailPreview: string | null = null;
  eventImages: File[] = [];
  eventImagePreviews: string[] = [];
  maxEventImages = 4;
  submitted = false;
  eventData: EventData | null = null;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private fb: FormBuilder,
    private fileUploadService: FileUploadService
  ) {}

  ngOnInit() {
    this.initForm();
    this.fetchData();

    // Debug routing
    console.log('Current route config:', this.router.config);
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());

    // Clean up stored files
    if (this.eventData) {
      this.fileUploadService.cleanup(this.eventData.thumbnailUrl);

      const imageKeys = ['image1Url', 'image2Url', 'image3Url', 'image4Url'] as const;
      type ImageKey = typeof imageKeys[number];

      imageKeys.forEach(key => {
        const imagePath = this.eventData?.[key];
        if (imagePath) {
          this.fileUploadService.cleanup(imagePath);
        }
      });
    }
  }

  clearApiError(fieldName: string) {
    if (this.apiErrors && this.apiErrors[fieldName]) {
      delete this.apiErrors[fieldName];
    }
  }

  private initForm() {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      locationID: [0, Validators.required],
      categoryID: [0, Validators.required],
      isPrice: [false],
      price: [0],
    }, { validators: this.dateValidator });

    // Subscribe to value changes to reset API errors
    this.subscriptions.push(
      this.eventForm.valueChanges.subscribe(() => {
        if (this.apiErrors) {
          this.apiErrors = null;
        }
      })
    );
  }

  // Add date validation
  private dateValidator(group: AbstractControl): ValidationErrors | null {
    const start = group.get('startDate')?.value;
    const end = group.get('endDate')?.value;

    if (start && end && new Date(start) > new Date(end)) {
      return { dateRange: true };
    }
    return null;
  }

  private async fetchData() {
    try {
      const [locations, categories] = await Promise.all([
        this.http.get<Location[]>(`${this.baseUrl}/Location`).toPromise(),
        this.http.get<Category[]>(`${this.baseUrl}/Categories`).toPromise()
      ]);

      if (locations && categories) {
        this.locations = locations;
        this.categories = categories;
        this.loading = false;
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      this.error = 'Failed to load required data';
      this.loading = false;
    }
  }

  onThumbnailSelect(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];

    if (file) {
      this.thumbnailFile = file;
      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>) => {
        if (e.target?.result) {
          this.thumbnailPreview = e.target.result as string;
          const previewElement = document.getElementById('thumbnailPreview') as HTMLImageElement;
          if (previewElement) {
            previewElement.style.display = 'block';
          }
        }
      };
      reader.readAsDataURL(file);
    }
  }

  onEventImagesSelect(event: Event) {
    const input = event.target as HTMLInputElement;
    const files = input.files;

    if (files && this.eventImages.length + files.length <= this.maxEventImages) {
      Array.from(files).forEach(file => {
        if (file.type.startsWith('image/')) {
          this.eventImages.push(file);
          this.previewEventImage(file);
        }
      });
    } else {
      alert(`You can only upload up to ${this.maxEventImages} event images`);
    }
  }

  private previewEventImage(file: File) {
    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      if (e.target?.result) {
        this.eventImagePreviews.push(e.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  }

  removeEventImage(index: number) {
    this.eventImages.splice(index, 1);
    this.eventImagePreviews.splice(index, 1);
  }

  private isValidImageFile(file: File): boolean {
    return file.type.startsWith('image/');
  }

  async onSubmit() {
    this.submitted = true;
    if (this.eventForm.valid && this.thumbnailFile) {
      try {
        const eventName = this.eventForm.get('name')?.value;
        const sanitizedName = eventName.replace(/[^a-z0-9]/gi, '_').toLowerCase();

        const eventData: EventData = {
          eventID: 0,
          name: eventName,
          categoryID: Number(this.eventForm.get('categoryID')?.value),
          locationID: Number(this.eventForm.get('locationID')?.value),
          startDate: this.eventForm.get('startDate')?.value,
          endDate: this.eventForm.get('endDate')?.value,
          userID: 1,
          description: this.eventForm.get('description')?.value,
          isPrice: Boolean(this.eventForm.get('isPrice')?.value),
          price: this.eventForm.get('isPrice')?.value ? Number(this.eventForm.get('price')?.value) : 0,
          isActive: true,
          bookedCapacity: 0,
          thumbnailUrl: '',
          image1Url: '',
          image2Url: '',
          image3Url: '',
          image4Url: ''
        };

        // Save files and update paths in eventData
        await this.saveFiles(sanitizedName, eventData);

        // Send to backend - the paths are now in eventData
        const response = await this.http.post(`${this.baseUrl}/Event/add-event`, eventData).toPromise();
        console.log('Event created successfully:', response);

        this.eventData = eventData;

        // Navigate to correct route
        await this.router.navigate(['/organizer/events']);
      } catch (err: unknown) {
        this.handleError(err);
      }
    } else {
      this.markFormGroupTouched(this.eventForm);
      if (!this.thumbnailFile) {
        this.error = 'Please select a thumbnail image for the event';
      }
    }
  }

  private async saveFiles(eventDir: string, eventData: EventData): Promise<void> {
    try {
      // Process thumbnail first
      if (this.thumbnailFile) {
        eventData.thumbnailUrl = await this.fileUploadService.processFileUpload(
          this.thumbnailFile,
          eventDir,
          'thumbnail'
        );
      }

      // Process event images
      for (let i = 0; i < this.eventImages.length; i++) {
        const imageKey = `image${i + 1}Url` as keyof Pick<EventData, 'image1Url' | 'image2Url' | 'image3Url' | 'image4Url'>;
        const imagePath = await this.fileUploadService.processFileUpload(
          this.eventImages[i],
          eventDir,
          `image${i + 1}`
        );
        eventData[imageKey] = imagePath;
      }
    } catch (error) {
      console.error('Error processing files:', error);
      throw new Error('Failed to process image files. Please try again.');
    }
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  // Update the handleError method
  private handleError(err: unknown): void {
    if (err instanceof Error) {
      this.error = err.message;
    } else if (typeof err === 'object' && err !== null) {
      const apiError = err as ApiError;
      if (apiError.error && typeof apiError.error === 'object') {
        this.apiErrors = apiError.error;
      } else {
        this.error = apiError.message || 'An unknown error occurred';
      }
    } else {
      this.error = 'An unexpected error occurred';
    }
    this.loading = false;
  }
}
