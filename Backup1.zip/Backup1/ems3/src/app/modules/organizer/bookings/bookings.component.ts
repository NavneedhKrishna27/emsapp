import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

interface Booking {
  bookingId: number;
  eventId: number;
  eventName: string;
  userId: number;
  userName: string;
  bookingDate: string;
  status: string;
}

interface EventBookings {
  eventId: number;
  eventName: string;
  totalBookings: number;
  bookings: Booking[];
}

@Component({
  selector: 'app-bookings',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {
  eventBookings: EventBookings[] = [];
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEventBookings();
  }

  private fetchEventBookings() {
    this.http.get<EventBookings[]>(`${this.baseUrl}/Bookings/events`)
      .subscribe({
        next: (data) => {
          this.eventBookings = data;
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load bookings';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }
}
