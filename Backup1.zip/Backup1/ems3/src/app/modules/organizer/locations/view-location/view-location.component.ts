import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

interface LocationWithStats {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
  eventCount?: number;
  upcomingEvents?: number;
  totalBookings?: number;
}

@Component({
  selector: 'app-view-location',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './view-location.component.html',
  styleUrls: ['./view-location.component.css']
})
export class ViewLocationComponent implements OnInit {
  location: LocationWithStats | null = null;
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.fetchLocationDetails(Number(id));
  }

  private fetchLocationDetails(id: number) {
    this.http.get<LocationWithStats>(`${this.baseUrl}/Location/${id}`)
      .subscribe({
        next: (location) => {
          this.location = location;
          this.fetchLocationStats(id);
        },
        error: (error) => {
          this.error = 'Failed to load location details';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  private fetchLocationStats(id: number) {
    this.http.get<any>(`${this.baseUrl}/Event/location-stats/${id}`)
      .subscribe({
        next: (stats) => {
          if (this.location) {
            this.location = { ...this.location, ...stats };
          }
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading stats:', error);
          this.loading = false;
        }
      });
  }

  onBack() {
    this.router.navigate(['/organizer/locations']);
  }
}
