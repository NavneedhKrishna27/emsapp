import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-create-location',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './create-location.component.html',
  styleUrls: ['./create-location.component.css']
})
export class CreateLocationComponent implements OnInit {
  locationForm!: FormGroup;
  loading = false;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit() {
    this.initForm();
  }

  private initForm() {
    this.locationForm = this.fb.group({
      locationName: ['', [Validators.required, Validators.minLength(3)]],
      capacity: ['', [Validators.required, Validators.min(1)]],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      postalCode: ['', Validators.required],
      primaryContact: ['', [Validators.required]],
      secondaryContact: ['']
    });

    // Debug form state changes
    this.locationForm.statusChanges.subscribe(status => {
      console.log('Form Status:', status);
      console.log('Form Valid:', this.locationForm.valid);
      console.log('Form Errors:', this.locationForm.errors);
    });
  }

  onSubmit() {
    if (this.locationForm.valid) {
      this.loading = true;
      const formData = {
        ...this.locationForm.value,
        locationID: 0
      };

      this.http.post(`${this.baseUrl}/Location`, formData)
        .subscribe({
          next: () => {
            this.router.navigate(['/organizer/locations']);
          },
          error: (error) => {
            this.error = 'Failed to create location';
            this.loading = false;
            console.error('Error:', error);
          }
        });
    } else {
      // Mark all fields as touched to trigger validation display
      Object.keys(this.locationForm.controls).forEach(key => {
        const control = this.locationForm.get(key);
        control?.markAsTouched();
      });
    }
  }

  onCancel() {
    this.router.navigate(['/organizer/locations']);
  }
}
