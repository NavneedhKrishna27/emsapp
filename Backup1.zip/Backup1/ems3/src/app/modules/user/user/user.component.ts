import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { SideNavComponent } from '../sidenav/sidenav.component';
import { UserService } from '../../../services/UserService';
import { User } from '../../../model/interface/User';
@Component({
  selector: 'app-user',
  standalone: true,
  imports: [CommonModule, RouterModule, HeaderComponent, SideNavComponent],
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  isSidenavOpen = false;
  currentUser: User | null = null;

  constructor(private userService: UserService) {}

  ngOnInit() {
    // Subscribe to user changes
    this.userService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  toggleSidenav() {
    this.isSidenavOpen = !this.isSidenavOpen;
  }

  closeSidenav() {
    this.isSidenavOpen = false;
  }

  // Example method to use user data
  getUserDetails(): string {
    if (this.currentUser) {
      return `Welcome ${this.currentUser.name}`;
    }
    return 'Please log in';
  }

  // Example of checking user status before an operation
  async bookEvent(eventId: number) {
    if (!this.userService.isLoggedIn()) {
      // Handle not logged in state
      return;
    }

    const user = this.userService.getCurrentUser();
    if (user) {
      // Proceed with booking using user.userID
    }
  }
}
