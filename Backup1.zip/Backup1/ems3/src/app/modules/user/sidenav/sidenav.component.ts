import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <aside class="sidenav" [class.expanded]="isOpen">
      <div class="nav-items">
        <a routerLink="/events" routerLinkActive="active" class="nav-item">
          <i class="bi bi-calendar-event"></i>
          <span class="nav-label">Events</span>
        </a>
        <a routerLink="/bookings" routerLinkActive="active" class="nav-item">
          <i class="bi bi-bookmark-check"></i>
          <span class="nav-label">My Bookings</span>
        </a>
        <a routerLink="/tickets" routerLinkActive="active" class="nav-item">
          <i class="bi bi-ticket-perforated"></i>
          <span class="nav-label">My Tickets</span>
        </a>
        <a routerLink="/payments" routerLinkActive="active" class="nav-item">
          <i class="bi bi-credit-card"></i>
          <span class="nav-label">Payments</span>
        </a>
        <a routerLink="/profile" routerLinkActive="active" class="nav-item">
          <i class="bi bi-person"></i>
          <span class="nav-label">Profile</span>
        </a>
      </div>
    </aside>
  `,
  styles: [`
    .sidenav {
      position: fixed;
      top: 64px;
      left: 0;
      height: calc(100vh - 64px);
      width: 70px;
      background: #ffffff;
      border-right: 1px solid #eaeaea;
      transition: width 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      overflow: hidden;
      z-index: 100;
    }

    .sidenav.expanded {
      width: 240px;
    }

    .nav-items {
      display: flex;
      flex-direction: column;
      padding: 1rem 0;
      gap: 0.5rem;
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 0.75rem 1rem;
      color: #666;
      text-decoration: none;
      border-radius: 0 8px 8px 0;
      transition: all 0.2s;
      margin: 0 0.5rem;
    }

    .nav-item i {
      font-size: 1.25rem;
      min-width: 32px;
    }

    .nav-label {
      font-size: 0.95rem;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.2s;
    }

    .expanded .nav-label {
      opacity: 1;
    }

    .nav-item:hover {
      background: #f8f9fa;
      color: #3498db;
    }

    .nav-item.active {
      background: #e3f2fd;
      color: #3498db;
      font-weight: 500;
    }
  `]
})
export class SideNavComponent {
  @Input() isOpen = false;
  @Output() close = new EventEmitter<void>();
}
