import { Routes } from '@angular/router';
import { UserComponent } from './user/user.component';
import { EventsComponent } from './events/events.component';
import { ViewEventComponent } from './events/view-event/view-event.component';

export const USER_ROUTES: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      {
        path: 'events',
        children: [
          { path: '', component: EventsComponent },
          { path: ':id', component: ViewEventComponent },
          { path: ':id/book', component: ViewEventComponent } // This will be replaced with BookEventComponent later
        ]
      },
      {
        path: 'bookings',
        loadComponent: () => import('./bookings/bookings.component').then(m => m.BookingsComponent)
      },
      {
        path: 'profile',
        loadComponent: () => import('./profile/profile.component').then(m => m.ProfileComponent)
      },
      {
        path: '',
        redirectTo: 'events',
        pathMatch: 'full'
      }
    ]
  }
];
