import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-4">
      <h2>User Dashboard</h2>
      <p>Welcome to your dashboard!</p>
    </div>
  `
})
export class UserDashboardComponent {}
