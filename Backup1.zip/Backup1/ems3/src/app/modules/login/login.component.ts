import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  loading = false;
  error: string | null = null;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    this.loading = true;
    this.error = null;

    this.authService.login({ email: this.email, password: this.password })
      .subscribe({
        next: () => {
          const user = this.authService.getCurrentUser();
          const route = user.role.toLowerCase();
          this.router.navigate([`/${route}`])
            .then(() => {
              this.loading = false;
            })
            .catch(err => {
              console.error('Navigation error:', err);
              this.error = 'Navigation failed';
              this.loading = false;
            });
        },
        error: (error) => {
          console.error('Login error:', error);
          this.error = 'Invalid email or password';
          this.loading = false;
        }
      });
  }
}
