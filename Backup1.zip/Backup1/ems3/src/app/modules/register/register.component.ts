import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

// Define the exact interface expected by the API
interface RegisterRequest {
  name: string;
  email: string;
  password: string;
  contactNumber: string;
  userType: 'User' | 'Organizer';
}

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  userData: RegisterRequest = {
    name: '',
    email: '',
    password: '',
    contactNumber: '',
    userType: 'User'
  };

  loading = false;
  error: string | null = null;
  userTypes: Array<'User' | 'Organizer'> = ['User', 'Organizer'];

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  onSubmit() {
    this.loading = true;
    this.error = null;

    // Validate data before sending
    if (!this.validateForm()) {
      this.loading = false;
      return;
    }

    // Ensure contact number is exactly 10 digits
    if (!this.userData.contactNumber.match(/^[0-9]{10}$/)) {
      this.error = 'Contact number must be 10 digits';
      this.loading = false;
      return;
    }

    // Trim whitespace from fields
    const requestData: RegisterRequest = {
      ...this.userData,
      name: this.userData.name.trim(),
      email: this.userData.email.trim().toLowerCase(),
      contactNumber: this.userData.contactNumber.trim()
    };

    this.authService.register(requestData).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigate(['/auth/login']);
      },
      error: (error) => {
        this.loading = false;
        if (error.status === 400) {
          // Handle specific validation errors from the API
          this.error = error.error?.message ||
                      'Please check your information and try again';
        } else {
          this.error = 'Registration failed. Please try again later.';
        }
        console.error('Registration error:', error);
      }
    });
  }

  private validateForm(): boolean {
    if (!this.userData.name || this.userData.name.trim().length < 3) {
      this.error = 'Name must be at least 3 characters long';
      return false;
    }

    if (!this.userData.email || !this.userData.email.includes('@')) {
      this.error = 'Please enter a valid email address';
      return false;
    }

    if (!this.userData.password || this.userData.password.length < 6) {
      this.error = 'Password must be at least 6 characters long';
      return false;
    }

    return true;
  }
}
