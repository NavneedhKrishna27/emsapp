import { Injectable } from '@angular/core';
import { User } from '../model/interface/User';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private readonly STORAGE_KEY = 'currentUser';
  private currentUserSubject: BehaviorSubject<User | null>;
  public currentUser$: Observable<User | null>;

  constructor() {
    // Initialize with stored user data or null
    const storedUser = localStorage.getItem(this.STORAGE_KEY);
    this.currentUserSubject = new BehaviorSubject<User | null>(
      storedUser ? JSON.parse(storedUser) : null
    );
    this.currentUser$ = this.currentUserSubject.asObservable();

    // Set default user if none exists
    if (!storedUser) {
      const defaultUser: User = {
        userID: 2,
        name: 'user1',
        email: 'user1@gmail.com',
        password: '123456',
        contactNumber: '1230984765',
        userType: 'User',
        isDelete: 0
      };
      this.setCurrentUser(defaultUser);
    }
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  setCurrentUser(user: User): void {
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  clearCurrentUser(): void {
    localStorage.removeItem(this.STORAGE_KEY);
    this.currentUserSubject.next(null);
  }

  isLoggedIn(): boolean {
    return !!this.getCurrentUser();
  }

  getUserType(): string {
    return this.getCurrentUser()?.userType || '';
  }
}
