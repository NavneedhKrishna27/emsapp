﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventManagementSystem_Merged_.Migrations
{
    /// <inheritdoc />
    public partial class image : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Image1Url",
                table: "Events",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Image2Url",
                table: "Events",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Image3Url",
                table: "Events",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Image4Url",
                table: "Events",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ThumbnailUrl",
                table: "Events",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Image1Url",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "Image2Url",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "Image3Url",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "Image4Url",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "ThumbnailUrl",
                table: "Events");
        }
    }
}
