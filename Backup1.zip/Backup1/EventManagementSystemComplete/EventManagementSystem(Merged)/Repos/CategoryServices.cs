﻿


using EventManagementSystemMerged.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventManagementSystem_Merged_.Repos
{
    public class CategoryServices
    {
        // DB dalObject = new DB();

        private readonly AppDbContext _context;
        public CategoryServices(AppDbContext context)
        {
            _context = context;
        }

        #region Get All Categories
        //public DataTable GetAllCategories()
        //{
        //    string getQuery = @"Select * from Categories";
        //    return dalObject.FillAndReturnDataTable(getQuery);
        //}
        #endregion

        #region Get All Categories Entity Framework
        public List<Category> GetAllCategories()
        {
            return _context.Categories.ToList();
        }
        #endregion

        #region Get Category By Id EntityFrameWork
        public Category GetCategory(int id)
        {
            return _context.Categories.FirstOrDefault(c => c.CategoryID == id);

        }
        #endregion

        #region Get Category By Id ADO.NET
        //public DataTable GettheCategory(int id)
        //{
        //    string getquery = @"Select * from Categories where CategoryId = @CategoryId";
        //    var nvp = new nameValuePairList();
        //    nvp.Add(new nameValuePair("@CategoryId", id));
        //    return dalObject.FillAndReturnDataTable(getquery);
        //}
        #endregion

        #region Add Category Entity FrameWork
        public void AddCategory(Category category)
        {
            _context.Categories.Add(category);
            _context.SaveChanges();
        }
        #endregion

        #region Add Category ADO.NEt
        //public int AddCategory(Category category)
        //{
        //    string insertQuery = @"Insert into [dbo].[Categories] (CategoryName) values (@CategoryName)";
        //    var nvp = new nameValuePairList();
        //    nvp.Add(new nameValuePair("@CategoryName", category.CategoryName));
        //    try
        //    {
        //        return dalObject.InsertUpdateOrDelete(insertQuery,nvp);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception($"Error adding category data: {ex.Message}", ex);
        //    }
        //}
        #endregion
    }
}
