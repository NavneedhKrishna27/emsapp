import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}
@Component({
  selector: 'app-edit-location',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-location.component.html',
  styleUrls: ['./edit-location.component.css']
})
export class EditLocationComponent implements OnInit {
  locationForm!: FormGroup;
  locationId!: number;
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.initForm();
    this.locationId = Number(this.route.snapshot.paramMap.get('id'));
    this.fetchLocation();
  }

  private initForm() {
    this.locationForm = this.fb.group({
      locationName: ['', [Validators.required, Validators.minLength(3)]],
      capacity: ['', [Validators.required, Validators.min(1), Validators.pattern('^[0-9]+$')]],
      address: ['', [Validators.required, Validators.minLength(5)]],
      city: ['', [Validators.required, Validators.minLength(2)]],
      state: ['', [Validators.required, Validators.minLength(2)]],
      country: ['', [Validators.required, Validators.minLength(2)]],
      postalCode: ['', [Validators.required, Validators.pattern('^[0-9A-Za-z-\\s]+$')]],
      primaryContact: ['', [Validators.required, Validators.pattern('^[+]?[0-9-]+$')]],
      secondaryContact: ['', [Validators.pattern('^[+]?[0-9-]+$')]]
    });
  }

  private fetchLocation() {
    this.http.get<Location>(`${this.baseUrl}/Location/${this.locationId}`)
      .subscribe({
        next: (location) => {
          this.locationForm.patchValue(location);
          this.loading = false;
        },
        error: (error) => {
          this.error = 'Failed to load location';
          this.loading = false;
          console.error('Error:', error);
        }
      });
  }

  onSubmit() {
    if (this.locationForm.valid) {
      // Create FormData object
      const formData = new FormData();
      
      // Add form fields to FormData
      formData.append('locationID', this.locationId.toString());
      formData.append('locationName', this.locationForm.get('locationName')?.value?.trim() ?? '');
      formData.append('capacity', this.locationForm.get('capacity')?.value?.toString() ?? '0');
      formData.append('address', this.locationForm.get('address')?.value?.trim() ?? '');
      formData.append('city', this.locationForm.get('city')?.value?.trim() ?? '');
      formData.append('state', this.locationForm.get('state')?.value?.trim() ?? '');
      formData.append('country', this.locationForm.get('country')?.value?.trim() ?? '');
      formData.append('postalCode', this.locationForm.get('postalCode')?.value?.trim() ?? '');
      formData.append('primaryContact', this.locationForm.get('primaryContact')?.value?.trim() ?? '');
      formData.append('secondaryContact', this.locationForm.get('secondaryContact')?.value?.trim() ?? '');

      // Validate capacity
      const capacity = parseInt(this.locationForm.get('capacity')?.value);
      if (capacity <= 0) {
        this.error = 'Capacity must be greater than 0';
        return;
      }

      // Log the payload for debugging
      console.log('Sending update request with payload:', Object.fromEntries(formData));

      this.http.put<Location>(`${this.baseUrl}/Location/${this.locationId}`, formData)
        .subscribe({
          next: () => {
            this.router.navigate(['/organizer/locations']);
          },
          error: (error) => {
            console.error('Update failed:', error);
            if (error.error && typeof error.error === 'object') {
              const validationErrors = Object.values(error.error.errors || {}).flat();
              this.error = validationErrors.length > 0 
                ? validationErrors.join(', ')
                : 'Failed to update location. Please check all fields and try again.';
            } else {
              this.error = 'Failed to update location. Please try again.';
            }
          }
        });
    } else {
      this.error = 'Please fill in all required fields correctly.';
      Object.keys(this.locationForm.controls).forEach(key => {
        const control = this.locationForm.get(key);
        if (control?.invalid) {
          console.log(`${key} is invalid:`, control.errors);
        }
      });
    }
  }

  onCancel() {
    this.router.navigate(['/organizer/locations']);
  }
}
