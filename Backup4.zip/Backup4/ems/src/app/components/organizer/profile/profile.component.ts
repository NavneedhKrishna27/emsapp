import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/authServices/auth.service';
import { OrganizerProfile, OrganizerService, UpdateProfileRequest } from '../../../core/organizerServices/organizer-service.service';
import { forkJoin } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-organizer-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profile: OrganizerProfile | null = null;
  editForm: FormGroup;
  isEditing = false;
  isSubmitting = false;
  error: string | null = null;
  loading = true;

  constructor(
    private organizerService: OrganizerService,
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder,
    private http: HttpClient
  ) {
    this.editForm = this.fb.group({
      name: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]]
    });
  }

  get userInitials(): string {
    if (!this.profile?.name) return '';
    return this.profile.name
      .split(' ')
      .map((n: string) => n[0])
      .join('')
      .toUpperCase();
  }

  ngOnInit(): void {
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/login']);
      return;
    }
    this.loadProfile();
  }

  loadProfile(): void {
    this.error = null;
    this.loading = true;
    
    const userId = this.authService.getUserId();
    if (!userId) {
      this.error = 'No authenticated user found';
      this.loading = false;
      return;
    }

    // Fetch both profile and dashboard data
    forkJoin({
      profile: this.organizerService.getOrganizerProfile(userId),
      dashboard: this.http.get<any>(`https://localhost:7149/api/Event/user/${userId}/dashboard`)
    }).subscribe({
      next: (data) => {
        this.profile = {
          ...data.profile,
          ...data.dashboard,
          eventsCreated: data.dashboard.totalEvents,  // Map totalEvents to eventsCreated
          userType: data.profile.userType || 'Organizer'  // Provide default value
        };
        this.editForm.patchValue({
          name: data.profile.name,
          contactNumber: data.profile.contactNumber
        });
        this.loading = false;
      },
      error: (error: Error) => {
        console.error('Error loading data:', error);
        this.error = 'Failed to load profile';
        this.loading = false;
      }
    });
  }

  startEdit(): void {
    this.isEditing = true;
  }

  cancelEdit(): void {
    this.isEditing = false;
    this.editForm.patchValue({
      name: this.profile?.name,
      contactNumber: this.profile?.contactNumber
    });
  }

  onSubmit(): void {
    if (this.editForm.valid) {
      this.isSubmitting = true;
      const userId = this.authService.getUserId();
      
      if (!userId) {
        this.error = 'No authenticated user found';
        return;
      }

      const updateData: UpdateProfileRequest = {
        name: this.editForm.value.name,
        contactNumber: this.editForm.value.contactNumber,
        userType: this.profile?.userType || 'Organizer'
      };

      this.organizerService.updateOrganizerProfile(userId.toString(), updateData).subscribe({
        next: () => {
          this.isEditing = false;
          this.isSubmitting = false;
          this.loadProfile();
        },
        error: (error: Error) => {
          console.error('Error updating profile:', error);
          this.isSubmitting = false;
          this.error = 'Failed to update profile';
        }
      });
    }
  }
}
