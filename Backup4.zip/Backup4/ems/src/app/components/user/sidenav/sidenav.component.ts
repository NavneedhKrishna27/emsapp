import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <aside class="sidenav" [class.expanded]="isExpanded">
      <div class="nav-items">
        <a routerLink="/user/events" routerLinkActive="active" class="nav-item">
          <i class="bi bi-calendar-event"></i>
          <span class="nav-label">Events</span>
        </a>
        <a routerLink="/user/tickets" routerLinkActive="active" class="nav-item">
          <i class="bi bi-ticket-perforated"></i>
          <span class="nav-label">My Tickets</span>
        </a>
        <a routerLink="/user/notifications" routerLinkActive="active" class="nav-item">
          <i class="bi bi-bell"></i>
          <span class="nav-label">Notifications</span>
        </a>
        <a routerLink="/user/profile" routerLinkActive="active" class="nav-item">
          <i class="bi bi-person"></i>
          <span class="nav-label">Profile</span>
        </a>
      </div>
    </aside>
  `,
  styles: [`
    .sidenav {
      position: fixed;
      top: 64px;
      left: 0;
      height: calc(100vh - 64px);
      width: 70px;
      background: #ffffff;
      border-right: 1px solid #eaeaea;
      transition: width 0.3s ease;
      overflow: hidden;
      z-index: 100;
    }

    .sidenav.expanded {
      width: 240px;
    }

    .nav-items {
      display: flex;
      flex-direction: column;
      padding: 1rem 0;
      gap: 0.5rem;
    }

    .nav-item {
      display: flex;
      align-items: center;
      padding: 0.75rem 1rem;
      color: #666;
      text-decoration: none;
      transition: all 0.2s;
      margin: 0 0.5rem;
      border-radius: 8px;
    }

    .nav-item i {
      font-size: 1.25rem;
      min-width: 32px;
    }

    .nav-label {
      font-size: 0.95rem;
      white-space: nowrap;
      opacity: 0;
      transition: opacity 0.2s;
    }

    .expanded .nav-label {
      opacity: 1;
    }

    .nav-item:hover {
      background: #f8f9fa;
      color: #3498db;
    }

    .nav-item.active {
      background: #e3f2fd;
      color: #3498db;
      font-weight: 500;
    }
  `]
})
export class SidenavComponent {
  @Input() isExpanded = false;
}
