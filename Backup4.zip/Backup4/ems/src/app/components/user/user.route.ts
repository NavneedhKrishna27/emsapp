import { Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { EventsComponent } from './events/events.component';
import { TicketsComponent } from './tickets/tickets.component';
import { ProfileComponent } from './profile/profile.component';
import { ViewEventComponent } from './events/view-event/view-event.component';
import { BookEventComponent } from './events/book-event/book-event.component';
import { ViewTicketComponent } from './tickets/view-ticket/view-ticket.component';
import { NotificationsComponent } from './notifications/notifications.component';
import { PaymentsComponent } from './payments/payments.component';

export const USER_ROUTES: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      { path: '', redirectTo: 'events', pathMatch: 'full' },
      {
        path: 'events',
        children: [
          { path: '', component: EventsComponent },
          { path: ':id', component: ViewEventComponent },
          { path: ':id/book', component: BookEventComponent }
        ]
      },
      {
        path: 'tickets',
        children: [
          { path: '', component: TicketsComponent },
          { path: ':id', component: ViewTicketComponent }
        ]
      },
      { path: 'notifications', component: NotificationsComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'payment', component: PaymentsComponent }
    ]
  }
];
