import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../../core/authServices/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-book-event',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './book-event.component.html',
  styleUrls: ['./book-event.component.css']
})
export class BookEventComponent implements OnInit {
  bookingForm: FormGroup;
  eventId: number;
  loading = false;
  error: string | null = null;
  ticketCount: number = 1;
  eventDetails: any = null;
  paymentInProgress: boolean = false;
  hasExistingBooking: boolean = false;
  private baseUrl = 'https://localhost:7149';

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService
  ) {
    this.eventId = Number(this.route.snapshot.paramMap.get('id'));
    this.ticketCount = Number(this.route.snapshot.queryParamMap.get('tickets')) || 1;

    this.bookingForm = this.fb.group({
      ticketCount: [this.ticketCount, [Validators.required, Validators.min(1), Validators.max(10)]]
    });

    this.bookingForm.get('ticketCount')?.valueChanges.subscribe(value => {
      this.ticketCount = value;
    });
  }

  ngOnInit() {
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/auth/login']);
      return;
    }

    const userId = this.authService.getUserId();
    if (userId) {
      this.checkExistingBooking(userId);
    }

    this.fetchEventDetails();
  }

  private checkExistingBooking(userId: number) {
    this.http.get<any>(`${this.baseUrl}/api/Booking/check/${userId}/${this.eventId}`)
      .subscribe({
        next: (response) => {
          if (response.bookingStatus === 'Confirmed') {
            this.hasExistingBooking = true;
            Swal.fire({
              icon: 'warning',
              title: 'Already Booked',
              text: 'You have already booked tickets for this event.',
              confirmButtonText: 'View My Tickets',
              showCancelButton: true,
              cancelButtonText: 'Close'
            }).then((result) => {
              if (result.isConfirmed) {
                this.router.navigate(['/user/tickets']);
              } else {
                this.router.navigate(['/user/events']);
              }
            });
          }
        },
        error: (error) => console.error('Error checking booking:', error)
      });
  }

  processPayment() {
    if (this.hasExistingBooking) {
      Swal.fire({
        icon: 'warning',
        title: 'Already Booked',
        text: 'You have already booked tickets for this event.'
      });
      return;
    }

    this.paymentInProgress = true;
    const userId = this.authService.getUserId();

    if (!userId || !this.eventDetails) {
      this.error = 'Unable to process payment';
      this.paymentInProgress = false;
      return;
    }

    const paymentData = {
      userID: userId,
      eventID: this.eventId,
      ticketCount: this.ticketCount
    };

    this.http.post(`${this.baseUrl}/api/Booking/book`, paymentData, { observe: 'response' })
      .subscribe({
        next: () => {
          setTimeout(() => {
            this.checkBookingStatus(userId);
          }, 1000);
        },
        error: (error) => {
          this.paymentInProgress = false;
          if (error.status >= 200 && error.status < 300) {
            this.showSuccessAndRedirect();
          } else {
            const errorMessage = typeof error.error === 'string' ? error.error : 'An unexpected error occurred';
            Swal.fire({
              icon: 'error',
              title: 'Booking Failed',
              text: errorMessage
            });
          }
        }
      });
  }

  private checkBookingStatus(userId: number) {
    this.http.get<any>(`${this.baseUrl}/api/Booking/check/${userId}/${this.eventId}`)
      .subscribe({
        next: (response) => {
          this.paymentInProgress = false;
          if (response.bookingStatus === 'Confirmed') {
            this.showSuccessAndRedirect();
          }
        },
        error: () => {
          this.paymentInProgress = false;
          this.showSuccessAndRedirect();
        }
      });
  }

  private showSuccessAndRedirect() {
    Swal.fire({
      icon: 'success',
      title: 'Booking Successful!',
      text: 'Your tickets have been booked successfully.',
      showConfirmButton: true,
      confirmButtonText: 'View My Tickets'
    }).then((result) => {
      if (result.isConfirmed) {
        this.router.navigate(['/user/tickets'], {
          state: { fromBooking: true }
        });
      }
    });
  }

  private fetchEventDetails() {
    this.http.get<any>(`${this.baseUrl}/api/Event/view-event/${this.eventId}`)
      .subscribe({
        next: (event) => {
          this.eventDetails = event;
        },
        error: (error) => {
          this.error = 'Failed to load event details';
          console.error(error);
        }
      });
  }

  getTotalAmount(): number {
    if (!this.eventDetails?.price || !this.ticketCount) {
      return 0;
    }
    return this.eventDetails.price * this.ticketCount;
  }
}
