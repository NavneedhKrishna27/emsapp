import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule, Router, RouterLink, NavigationEnd } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { AuthService } from '../../../../core/authServices/auth.service';
import { filter } from 'rxjs/operators';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import Swal from 'sweetalert2';
declare var bootstrap: any;

interface Event {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  locationID: number;
  categoryID: number;
  price: number;
  isPrice: boolean;
  bookedCapacity: number;
  thumbnailUrl?: string;
  image1Url?: string;
  image2Url?: string;
  image3Url?: string;
  image4Url?: string;
  locationName?: string;
  categoryName?: string;
}

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}

interface EventStats {
  totalCapacity: number;
  registeredCount: number;
  remainingCapacity: number;
}

interface Feedback {
  feedbackID: number;
  eventID: number;
  userID: number;
  userName: string;
  rating: number;
  comments: string;
  submittedTimestamp: string;
}

interface RatingCounts {
  [key: string]: number;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

@Component({
  selector: 'app-view-event',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.css']
})
export class ViewEventComponent implements OnInit, AfterViewInit, OnDestroy {
  event: Event | null = null;
  location: Location | null = null;
  stats: EventStats | null = null;
  feedbacks: Feedback[] = [];
  timeUntilEvent: string = '';
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149';
  private timerInterval: any;
  private routerSubscription: any;

  averageRating: number = 0;
  ratingCounts: RatingCounts = {};
  ticketsSold: number = 0;
  category: Category | null = null;
  hasBooked: boolean = false;

  ticketCount: number = 1;
  readonly maxTickets = 10;

  private timeLeft: { days: number; hours: number; minutes: number; seconds: number } = {
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  };

  feedbackForm: FormGroup;
  userHasTicket: boolean = false;
  hasGivenFeedback: boolean = false;
  userTicketId: number | null = null;
  submitting: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private sanitizer: DomSanitizer,
    private authService: AuthService,
    private fb: FormBuilder
  ) {
    this.routerSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe(() => {
      this.refreshData();
    });

    this.feedbackForm = this.fb.group({
      rating: ['', [Validators.required, Validators.min(1), Validators.max(5)]],
      comments: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  ngOnInit() {
    const eventId = this.route.snapshot.paramMap.get('id');
    if (eventId) {
      this.fetchEventDetails(eventId).then(() => {
        if (this.event) {
          if (!this.isEventCompleted()) {
            this.startEventTimer();
          } else {
            // Only fetch feedbacks for completed events
            this.fetchFeedbacks(eventId);
          }
          // Check if user has a ticket for this event
          this.checkUserTicket(eventId);
        }
      });
    }
  }

  ngAfterViewInit() {
    this.initializeCarousel();
  }

  private initializeCarousel() {
    setTimeout(() => {
      const carouselElement = document.getElementById('eventImageCarousel');
      if (carouselElement) {
        const carousel = new bootstrap.Carousel(carouselElement, {
          interval: 5000, // Auto-play interval in milliseconds
          wrap: true,     // Whether to cycle continuously
          keyboard: true, // Enable keyboard navigation
          pause: 'hover', // Pause on mouse enter
          touch: true     // Enable touch support
        });
      }
    }, 100);
  }

  ngOnDestroy() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
    }
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  private async fetchEventDetails(eventId: string) {
    try {
      this.loading = true;
      this.event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise() || null;
    } catch (error) {
      console.error('Error fetching event details:', error);
      this.error = 'Failed to load event details';
    } finally {
      this.loading = false;
    }
  }

  private async fetchEventStats(eventId: string) {
    try {
      this.stats = await this.http.get<EventStats>(`${this.baseUrl}/api/Event/stats/${eventId}`).toPromise() || null;
    } catch (error) {
      console.error('Error fetching event stats:', error);
    }
  }

  private async fetchLocation(eventId: string) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise();
      if (event?.locationID) {
        this.location = await this.http.get<Location>(`${this.baseUrl}/api/Location/${event.locationID}`).toPromise() || null;
      }
    } catch (error) {
      console.error('Error fetching location:', error);
    }
  }

  private async fetchCategory(eventId: string) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/api/Event/view-event/${eventId}`).toPromise();
      if (event?.categoryID) {
        this.category = await this.http.get<Category>(`${this.baseUrl}/api/Categories/${event.categoryID}`).toPromise() || null;
      }
    } catch (error) {
      console.error('Error fetching category:', error);
    }
  }

  private async fetchTicketsSold(eventId: string) {
    try {
      this.ticketsSold = await this.http.get<number>(`${this.baseUrl}/api/Ticket/tickets-sold/${eventId}`).toPromise() || 0;
    } catch (error) {
      console.error('Error fetching tickets sold:', error);
      this.ticketsSold = 0;
    }
  }

  fetchFeedbacks(eventId: string) {
    this.http.get<Feedback[]>(`${this.baseUrl}/api/Feedback/Get-feedbacks-by-eventid/${eventId}`)
      .subscribe({
        next: (feedbacks) => {
          this.feedbacks = feedbacks;
          // Calculate ratings after fetching feedbacks
          this.averageRating = this.calculateAverageRating();
          this.ratingCounts = this.calculateRatingCounts();
        },
        error: (error) => {
          console.error('Error fetching feedbacks:', error);
        }
      });
  }

  private startEventTimer() {
    if (!this.event) return;

    const updateTimer = () => {
      const now = new Date().getTime();
      const eventStart = new Date(this.event!.startDate).getTime();
      const timeDistance = eventStart - now;

      if (timeDistance < 0) {
        this.timeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };
        clearInterval(this.timerInterval);
        return;
      }

      this.timeLeft = {
        days: Math.floor(timeDistance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((timeDistance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((timeDistance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((timeDistance % (1000 * 60)) / 1000)
      };
    };

    updateTimer();
    this.timerInterval = setInterval(updateTimer, 1000);
  }

  getDays(): string {
    return this.timeLeft.days.toString().padStart(2, '0');
  }

  getHours(): string {
    return this.timeLeft.hours.toString().padStart(2, '0');
  }

  getMinutes(): string {
    return this.timeLeft.minutes.toString().padStart(2, '0');
  }

  getSeconds(): string {
    return this.timeLeft.seconds.toString().padStart(2, '0');
  }

  getEventStatus(): string {
    if (!this.event) return 'Unknown';
    const now = new Date();
    const startDate = new Date(this.event.startDate);
    const endDate = new Date(this.event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getStatusClass(): string {
    const status = this.getEventStatus();
    switch (status) {
      case 'Active': return 'bg-warning text-dark';
      case 'Completed': return 'bg-secondary';
      case 'Upcoming': return 'bg-primary';
      default: return 'bg-secondary';
    }
  }

  getStatusIcon(): string {
    const status = this.getEventStatus();
    switch (status) {
      case 'Active': return 'bi-play-circle-fill';
      case 'Completed': return 'bi-check-circle-fill';
      case 'Upcoming': return 'bi-calendar-event-fill';
      default: return 'bi-question-circle-fill';
    }
  }

  isEventCompleted(): boolean {
    if (!this.event) return true;
    const now = new Date();
    const endDate = new Date(this.event.endDate);
    return endDate < now;
  }

  isEventSoldOut(): boolean {
    if (!this.location || this.ticketsSold === undefined) return false;
    return this.ticketsSold >= this.location.capacity;
  }

  getImageUrl(path: string | undefined): SafeUrl {
    if (!path) return 'assets/images/event-placeholder.jpg';
    return this.sanitizer.bypassSecurityTrustUrl(`${this.baseUrl}${path}`);
  }

  getEventImages(): string[] {
    if (!this.event) return [];
    const images = [
      this.event.thumbnailUrl,
      ...[
        this.event.image1Url,
        this.event.image2Url,
        this.event.image3Url,
        this.event.image4Url
      ].filter(url => url && url !== this.event?.thumbnailUrl)
    ].filter(url => url) as string[];

    return images;
  }

  bookEvent() {
    console.log('Booking event:', this.event?.eventID);
  }

  incrementTickets() {
    if (this.ticketCount < this.maxTickets) {
      this.ticketCount++;
    }
  }

  decrementTickets() {
    if (this.ticketCount > 1) {
      this.ticketCount--;
    }
  }

  onBookNowClick() {
    if (this.isEventCompleted()) {
      return; // Early return if event is completed
    }
    if (this.isEventSoldOut()) {
      return;
    }
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/auth/login']);
      return;
    }
    this.router.navigate(['/user/events', this.event?.eventID, 'book'], {
      queryParams: { tickets: this.ticketCount }
    })
    .then(() => {
      this.checkUserBooking();
    });
  }

  shareEvent() {
    if (!this.event) return;
    const url = window.location.href;
    const text = `Check out ${this.event.name} - ${url}`;

    if (navigator.share) {
      navigator.share({
        title: this.event.name,
        text: this.event.description,
        url: url
      }).catch(err => console.error('Error sharing:', err));
    } else {
      navigator.clipboard.writeText(text)
        .then(() => alert('Event link copied to clipboard!'))
        .catch(err => console.error('Error copying to clipboard:', err));
    }
  }

  getDurationText(): string {
    if (!this.event) return '';
    const start = new Date(this.event.startDate);
    const end = new Date(this.event.endDate);
    const hours = Math.abs(end.getTime() - start.getTime()) / 36e5;

    if (hours < 24) {
      return `${Math.round(hours)} hours`;
    }
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''}`;
  }

  getRemainingCapacity(): number {
    if (!this.location || !this.ticketsSold) return 0;
    return this.location.capacity - this.ticketsSold;
  }

  getCapacityPercentage(): number {
    if (!this.location || !this.ticketsSold) return 0;
    return (this.ticketsSold / this.location.capacity) * 100;
  }

  getTotalRatings(): number {
    return this.feedbacks.length;
  }

  getRatingPercentage(rating: number): number {
    const total = this.getTotalRatings();
    if (!total) return 0;

    const count = this.calculateRatingCounts()[rating.toString()] || 0;
    return (count / total) * 100;
  }

  getCapacityInfo() {
    if (!this.location) return {
      total: 0,
      sold: 0,
      remaining: 0,
      percentage: 0
    };

    const total = this.location.capacity;
    const sold = this.ticketsSold;
    const remaining = total - sold;
    const percentage = (sold / total) * 100;

    return {
      total,
      sold,
      remaining,
      percentage
    };
  }

  getProgressBarClass(percentage: number): string {
    if (percentage >= 80) return 'bg-success';
    if (percentage >= 50) return 'bg-info';
    if (percentage >= 25) return 'bg-warning';
    return 'bg-danger';
  }

  checkUserBooking() {
    const userId = this.authService.getUserId();
    if (!userId || !this.event) return;

    this.http.get(`${this.baseUrl}/api/Booking/check/${userId}/${this.event.eventID}`)
      .subscribe({
        next: (hasBooked: any) => {
          this.hasBooked = hasBooked;
        },
        error: (error) => console.error('Error checking booking:', error)
      });
  }

  cancelBooking(): void {
    const userId = this.authService.getUserId();
    if (!userId || !this.event) return;

    const cancelData = {
      userID: userId,
      eventID: this.event.eventID
    };

    this.http.post('https://localhost:7149/api/Booking/cancel', cancelData)
      .subscribe({
        next: () => {
          this.hasBooked = false;
          window.location.reload();
        },
        error: (error) => console.error('Error cancelling booking:', error)
      });
  }

  refreshData() {
    const eventId = this.route.snapshot.paramMap.get('id');
    if (eventId) {
      this.fetchEventDetails(eventId);
      this.fetchEventStats(eventId);
      this.fetchTicketsSold(eventId);
      this.checkUserBooking();
    }
  }

  checkUserTicket(eventId: string) {
    const userId = this.authService.getUserId();
    if (!userId) return;

    // First get the ticket ID
    this.http.get<number>(`${this.baseUrl}/api/Feedback/ticket/${userId}/${eventId}`)
      .subscribe({
        next: (ticketId) => {
          this.userTicketId = ticketId;
          this.userHasTicket = true;
          // After confirming ticket, check if user has already given feedback
          this.checkExistingFeedback(eventId);
        },
        error: () => {
          this.userHasTicket = false;
          this.userTicketId = null;
        }
      });
  }

  checkExistingFeedback(eventId: string) {
    if (!this.userTicketId) return;

    this.http.get<boolean>(`${this.baseUrl}/api/Feedback/check/${this.userTicketId}`)
      .subscribe({
        next: (hasFeedback) => {
          this.hasGivenFeedback = hasFeedback;
          if (hasFeedback) {
            this.feedbackForm.disable(); // Disable form if feedback already given
          }
        }
      });
  }

  submitFeedback() {
    if (this.feedbackForm.invalid || !this.userTicketId || this.hasGivenFeedback) {
      return;
    }

    const userId = this.authService.getUserId();
    if (!userId) return;

    this.submitting = true;
    const formData = new FormData();
    formData.append('rating', this.feedbackForm.get('rating')?.value);
    formData.append('comments', this.feedbackForm.get('comments')?.value);

    this.http.post(
      `${this.baseUrl}/api/Feedback/Add-feedbacks-by-Ticketid?userid=${userId}&ticketid=${this.userTicketId}`,
      formData
    ).subscribe({
      next: () => {
        Swal.fire({
          icon: 'success',
          title: 'Thank you for your feedback!',
          text: 'Your feedback has been submitted successfully.',
          timer: 2000,
          showConfirmButton: false
        });
        this.hasGivenFeedback = true;
        this.feedbackForm.reset();
        // Refresh feedbacks
        if (this.event) {
          this.fetchFeedbacks(this.event.eventID.toString());
        }
      },
      error: (error) => {
        Swal.fire({
          icon: 'error',
          title: 'Unable to submit feedback',
          text: error.error?.message || 'Please try again later'
        });
      },
      complete: () => {
        this.submitting = false;
      }
    });
  }

  calculateAverageRating(): number {
    if (!this.feedbacks || this.feedbacks.length === 0) return 0;
    const sum = this.feedbacks.reduce((acc, feedback) => acc + feedback.rating, 0);
    return Number((sum / this.feedbacks.length).toFixed(1));
  }

  calculateRatingCounts(): RatingCounts {
    const counts: RatingCounts = {
      '1': 0,
      '2': 0,
      '3': 0,
      '4': 0,
      '5': 0
    };

    this.feedbacks.forEach(feedback => {
      counts[feedback.rating.toString()]++;
    });

    return counts;
  }

  // Add this helper method for star rating display
  getRatingStars(rating: number): string[] {
    return Array(5).fill(0).map((_, i) => i < rating ? 'bi-star-fill' : 'bi-star');
  }
}
