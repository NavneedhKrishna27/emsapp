import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { EventFilterService } from '../../../core/userServices/event-filter.service';

interface EventItem {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  locationID: number;
  locationName?: string;  // Add this property
  categoryID: number;
  price: number;
  isPrice: boolean;
  bookedCapacity: number;
  thumbnailUrl?: string;
  image1Url?: string;
  image2Url?: string;
  image3Url?: string;
  image4Url?: string;
}

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css'],
})
export class EventsComponent implements OnInit, OnDestroy {
  events: EventItem[] = [];
  filteredEvents: EventItem[] = [];
  loading: boolean = true;
  error: string | null = null;
  private baseUrl: string = 'https://localhost:7149'; // Remove /api
  searchTerm: string = '';
  selectedSort: string = '';
  selectedCategory: string = 'All Events';
  categories: string[] = ['All Events', 'Today', 'This Weekend', 'Music', 'Sports', 'Theatre'];
  private locationSubscription?: Subscription; // Add ? to mark as optional

  constructor(
    private http: HttpClient,
    private eventFilterService: EventFilterService
  ) {}

  ngOnInit() {
    this.locationSubscription = this.eventFilterService.selectedLocation$
      .subscribe(locationId => {
        this.filterByLocation(locationId);
      });

    // Initial load of all events
    this.loadEvents(null);
  }

  ngOnDestroy() {
    this.locationSubscription?.unsubscribe(); // Use optional chaining
  }

  private async loadEvents(selectedLocationId: number | null) {
    try {
      this.loading = true;
      const events = await this.http.get<EventItem[]>('https://localhost:7149/api/Event/index').toPromise();
      this.events = events || [];

      // Apply location filter immediately if there's a selected location
      if (selectedLocationId) {
        this.filteredEvents = this.events.filter(event => event.locationID === selectedLocationId);
      } else {
        this.filteredEvents = [...this.events]; // Create a new array copy
      }

      // Apply other active filters
      this.applyFilters();
    } catch (error) {
      console.error('Error loading events:', error);
      this.error = 'Failed to load events';
    } finally {
      this.loading = false;
    }
  }

  filterByLocation(locationId: number | null) {
    // First reset to all events
    this.filteredEvents = [...this.events];

    // Then apply location filter if needed
    if (locationId) {
      this.filteredEvents = this.filteredEvents.filter(event => event.locationID === locationId);
    }

    // Apply other active filters
    this.applyFilters();
  }

  // New method to apply all filters in correct order
  private applyFilters() {
    // Apply category filter
    if (this.selectedCategory !== 'All Events') {
      this.filterByCategory(this.selectedCategory);
    }

    // Apply search filter
    if (this.searchTerm) {
      this.filterEvents();
    }

    // Apply sorting
    this.sortEvents();
  }

  // Update filterEvents to not reset filteredEvents
  filterEvents() {
    if (this.searchTerm) {
      this.filteredEvents = this.filteredEvents.filter(event =>
        event.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    }
    this.sortEvents();
  }

  sortEvents() {
    switch(this.selectedSort) {
      case 'date':
        this.filteredEvents.sort((a, b) =>
          new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
        break;
      case 'price':
        this.filteredEvents.sort((a, b) =>
          (a.isPrice ? a.price : 0) - (b.isPrice ? b.price : 0));
        break;
      case 'name':
        this.filteredEvents.sort((a, b) =>
          a.name.localeCompare(b.name));
        break;
    }
  }

  filterByCategory(category: string) {
    this.selectedCategory = category;
    if (category === 'All Events') {
      this.filteredEvents = this.events;
    } else if (category === 'Today') {
      const today = new Date().toISOString().split('T')[0];
      this.filteredEvents = this.events.filter(event =>
        event.startDate.includes(today));
    } else if (category === 'This Weekend') {
      // Add weekend filtering logic
    } else {
      // Add category filtering logic when you have category data
    }
  }

  isUpcoming(event: EventItem): boolean {
    return new Date(event.startDate) > new Date();
  }

  isEventCompleted(event: EventItem): boolean {
    const endDate = new Date(event.endDate);
    return endDate < new Date();
  }

  getImageUrl(event: EventItem): string {
    if (event.thumbnailUrl) {
      // Don't modify the thumbnailUrl, use it directly
      return `${this.baseUrl}${event.thumbnailUrl}`;
    }
    return '/assets/images/event-placeholder.jpg';
  }

  handleImageError(event: ErrorEvent): void {
    const imgElement = event.target as HTMLImageElement;
    if (imgElement) {
      imgElement.src = '/assets/images/event-placeholder.jpg';
    }
  }
}
