import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../../core/authServices/auth.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { DeleteTicketComponent } from '../delete-event/delete-event.component';
import Swal from 'sweetalert2';

interface TicketDetail {
  ticketID: number;
  eventID: number;
  eventName: string;
  ticketStatus: string;
  bookingDate: string;
  numberOfTickets: number;
  totalAmount: number;
  eventDetails: {
    startDate: string;
    endDate: string;
    category: string;
    pricePerTicket: number;
  };
  venueDetails: {
    location: string;
    address: string;
    city: string;
  };
}

interface EventDetail {
  eventID: number;
  name: string;
  categoryID: number;
  locationID: number;
  startDate: string;
  endDate: string;
  userID: number;
  description: string;
  isPrice: boolean;
  price: number;
  isActive: boolean;
  bookedCapacity: number;
  thumbnailUrl: string;
  image1Url: string;
  image2Url: string;
  image3Url: string;
  image4Url: string;
}

@Component({
  selector: 'app-view-ticket',
  standalone: true,
  imports: [CommonModule, RouterLink, DeleteTicketComponent],
  templateUrl: './view-ticket.component.html',
  styleUrls: ['./view-ticket.component.css']
})
export class ViewTicketComponent implements OnInit {
  private baseUrl = 'https://localhost:7149';
  ticket: TicketDetail | null = null;
  eventDetails: EventDetail | null = null;
  loading = true;
  error: string | null = null;
  eventThumbnail: SafeUrl | null = null;
  showDeleteModal = false;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private authService: AuthService,
    private sanitizer: DomSanitizer,
    private router: Router
  ) {}

  ngOnInit() {
    const ticketId = this.route.snapshot.params['id'];
    const userId = this.authService.getUserId();

    if (!userId) {
      this.error = 'Please login to view ticket details';
      this.loading = false;
      return;
    }

    this.http.get<TicketDetail>(`${this.baseUrl}/api/Ticket/details/${ticketId}`)
      .subscribe({
        next: (ticketResponse) => {
          this.ticket = ticketResponse;
          console.log('Full Ticket Response:', JSON.stringify(ticketResponse, null, 2)); // Better debug log

          // Check if ticket response is valid
          if (!ticketResponse || typeof ticketResponse !== 'object') {
            this.error = 'Invalid ticket response';
            this.loading = false;
            return;
          }

          // Get eventID directly from ticket response
          const eventId = ticketResponse.eventID;
          console.log('Event ID:', eventId); // Debug log for eventID

          if (!eventId) {
            this.error = 'Event ID not found';
            this.loading = false;
            return;
          }

          // Fetch event details with the eventID
          this.http.get<EventDetail>(`${this.baseUrl}/api/Event/view-event/${eventId}`)
            .subscribe({
              next: (eventResponse) => {
                this.eventDetails = eventResponse;
                console.log('Event Response:', eventResponse);

                if (eventResponse?.thumbnailUrl) {
                  const thumbnailUrl = eventResponse.thumbnailUrl;
                  console.log('Raw thumbnail URL:', thumbnailUrl); // Debug log
                  this.eventThumbnail = this.getImageUrl(thumbnailUrl);
                  console.log('Processed thumbnail URL:', this.eventThumbnail);
                }
                this.loading = false;
              },
              error: (error) => {
                console.error('Error fetching event details:', error);
                this.error = `Failed to load event details: ${error.message}`;
                this.loading = false;
              }
            });
        },
        error: (error) => {
          console.error('Error fetching ticket details:', error);
          this.error = `Failed to load ticket details: ${error.message}`;
          this.loading = false;
        }
      });
  }

  getImageUrl(path: string): SafeUrl {
    if (!path) {
      return this.sanitizer.bypassSecurityTrustUrl('/assets/images/event-placeholder.jpg');
    }

    // For absolute URLs
    if (path.startsWith('http')) {
      return this.sanitizer.bypassSecurityTrustUrl(path);
    }

    // For paths with /public
    const formattedPath = path.startsWith('/public') ? path : `/public/${path}`;
    const fullUrl = `${this.baseUrl}${formattedPath}`;
    console.log('Generated Image URL:', fullUrl); // Debug log
    return this.sanitizer.bypassSecurityTrustUrl(fullUrl);
  }

  getStatusClass(): string {
    if (!this.ticket) return '';

    switch (this.ticket.ticketStatus.toLowerCase()) {
      case 'confirmed':
        return 'badge bg-success';
      case 'cancelled':
        return 'badge bg-danger';
      case 'pending':
        return 'badge bg-warning';
      default:
        return 'badge bg-secondary';
    }
  }

  canCancelBooking(): boolean {
    if (!this.ticket) return false;

    const isConfirmed = this.ticket.ticketStatus.toLowerCase() === 'confirmed';
    const eventStartDate = new Date(this.ticket.eventDetails.startDate);
    const eventEndDate = new Date(this.ticket.eventDetails.endDate);
    const now = new Date();

    return isConfirmed && now <= eventEndDate;
  }

  cancelBooking(): void {
    this.showDeleteModal = true;
  }

  onConfirmDelete(): void {
    const userId = this.authService.getUserId();
    if (!this.ticket || !userId) return;

    const cancelRequest = {
      userID: userId,
      eventID: this.ticket.eventID,
      ticketID: this.ticket.ticketID
    };

    this.http.post(`${this.baseUrl}/api/Booking/cancel`, cancelRequest)
      .subscribe({
        next: () => {
          this.showDeleteModal = false;
          Swal.fire({
            icon: 'success',
            title: 'Booking Cancelled',
            text: 'Your refund will be processed within 12 hours.',
            timer: 2000,
            showConfirmButton: false
          }).then(() => {
            this.router.navigate(['/user/tickets']);
          });
        },
        error: () => {
          this.showDeleteModal = false;
          Swal.fire({
            icon: 'success',
            title: 'Booking Cancelled',
            text: 'Your refund will be processed within 12 hours.',
            timer: 2000,
            showConfirmButton: false
          }).then(() => {
            this.router.navigate(['/user/tickets']);
          });
        }
      });
  }

  private checkTicketStatusAndRefresh(): void {
    if (!this.ticket) return;

    this.http.get<string>(`${this.baseUrl}/api/Ticket/status/${this.ticket.ticketID}`)
      .subscribe({
        next: (status) => {
          // Store ticket reference to avoid null checks
          const currentTicket = this.ticket;
          if (!currentTicket) return;

          if (status.toLowerCase() === 'cancelled') {
            // Update the local ticket status immediately
            currentTicket.ticketStatus = 'Cancelled';
            this.showDeleteModal = false;

            Swal.fire({
              icon: 'success',
              title: 'Booking Cancelled',
              text: 'Your refund will be processed within 12 hours.',
              timer: 2000,
              showConfirmButton: false
            }).then(() => {
              // Navigate back to tickets list
              window.location.href = '/tickets';
            });
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Cancellation Failed',
              text: 'Unable to cancel the booking. Please try again.',
              confirmButtonText: 'OK'
            });
          }
        },
        error: (error) => {
          console.error('Error checking ticket status:', error);
          Swal.fire({
            icon: 'error',
            title: 'Status Check Failed',
            text: 'Unable to verify cancellation status. Please check your bookings.',
            confirmButtonText: 'View My Tickets'
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.href = '/tickets';
            }
          });
        }
      });
  }

  onCancelDelete(): void {
    this.showDeleteModal = false;
  }
}
