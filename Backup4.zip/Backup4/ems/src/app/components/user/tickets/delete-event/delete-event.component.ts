import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-delete-ticket',
  standalone: true,
  imports: [CommonModule],
  template: `
    <!-- Bootstrap Modal Backdrop -->
    <div class="modal-backdrop fade show"></div>

    <!-- Bootstrap Modal -->
    <div class="modal d-block" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header border-0">
            <h5 class="modal-title text-danger">
              <i class="bi bi-exclamation-triangle-fill me-2"></i>Cancel Booking
            </h5>
            <button type="button" class="btn-close" (click)="onCancel()"></button>
          </div>

          <div class="modal-body text-center p-4">
            <div class="mb-4">
              <i class="bi bi-ticket-detailed display-1 text-danger"></i>
            </div>
            <h4>Are you sure you want to cancel this ticket?</h4>
            <p class="text-muted mb-4">Event: {{eventName}}</p>

            <div class="alert alert-info">
              <div class="d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-4 me-2"></i>
                <div class="text-start">
                  <strong>Refund Information</strong>
                  <p class="mb-0">Your refund amount of ₹{{amount}} will be processed within 12 hours.</p>
                </div>
              </div>
            </div>

            <div class="alert alert-warning">
              <div class="d-flex align-items-center">
                <i class="bi bi-exclamation-triangle-fill fs-4 me-2"></i>
                <div class="text-start">
                  <strong>Please Note</strong>
                  <p class="mb-0">This action cannot be undone.</p>
                </div>
              </div>
            </div>
          </div>

          <div class="modal-footer border-0 justify-content-center gap-2">
            <button type="button" class="btn btn-outline-secondary px-4" (click)="onCancel()">
              <i class="bi bi-x-circle me-2"></i>Keep Ticket
            </button>
            <button type="button" class="btn btn-danger px-4" (click)="onConfirm()">
              <i class="bi bi-check-circle me-2"></i>Yes, Cancel Ticket
            </button>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    :host {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1050;
    }
    .modal-content {
      border-radius: 1rem;
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    }
    .alert {
      border-radius: 0.5rem;
      margin-bottom: 1rem;
    }
    .btn {
      padding: 0.5rem 1.5rem;
      border-radius: 0.5rem;
    }
    .modal-body {
      padding: 2rem;
    }
  `]
})
export class DeleteTicketComponent {
  @Input() eventName: string = '';
  @Input() amount: number = 0;
  @Output() confirm = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();

  onConfirm() {
    this.confirm.emit();
  }

  onCancel() {
    this.cancel.emit();
  }
}
