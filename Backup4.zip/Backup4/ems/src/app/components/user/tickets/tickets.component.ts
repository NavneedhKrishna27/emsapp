import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/authServices/auth.service';

interface Ticket {
  ticketID: number;
  userID: number;
  eventID: number;
  eventName: string;
  ticketCount: number;
  bookingDate: string;
  eventDate: string;
  status: string;
}

@Component({
  selector: 'app-tickets',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './tickets.component.html',
  styleUrls: ['./tickets.component.css']
})
export class TicketsComponent implements OnInit {
  tickets: Ticket[] = [];
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149';
  sortField: string = 'bookingDate';
  sortDirection: 'asc' | 'desc' = 'desc';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loadTickets();
  }

  private loadTickets() {
    const userId = this.authService.getUserId();
    if (!userId) {
      this.error = 'Please login to view tickets';
      this.loading = false;
      return;
    }

    this.loading = true;
    this.http.get<Ticket[]>(`${this.baseUrl}/api/Ticket/user/${userId}`)
      .subscribe({
        next: (response) => {
          this.tickets = this.sortTickets(response);
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading tickets:', error);
          this.error = 'Failed to load tickets';
          this.loading = false;
        }
      });
  }

  sortTickets(tickets: Ticket[]): Ticket[] {
    return tickets.sort((a, b) => {
      let comparison = 0;
      switch (this.sortField) {
        case 'bookingDate':
          comparison = new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime();
          break;
        case 'status':
          comparison = a.status.localeCompare(b.status);
          break;
        case 'eventDate':
          comparison = new Date(b.eventDate).getTime() - new Date(a.eventDate).getTime();
          break;
        default:
          comparison = new Date(b.bookingDate).getTime() - new Date(a.bookingDate).getTime();
      }
      return this.sortDirection === 'asc' ? -comparison : comparison;
    });
  }

  changeSorting(field: string) {
    if (this.sortField === field) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = field;
      this.sortDirection = 'desc';
    }
    this.tickets = this.sortTickets([...this.tickets]);
  }

  getStatusClass(status: string): string {
    switch (status?.toLowerCase()) {
      case 'confirmed':
        return 'status-confirmed';
      case 'cancelled':
        return 'status-cancelled';
      case 'pending':
        return 'status-pending';
      default:
        return '';
    }
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}
