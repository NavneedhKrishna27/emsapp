import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../../core/userServices/user-service.service';
import { AuthService } from '../../../core/authServices/auth.service';
import { UserProfile } from '../../../interfaces/user.interface';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']  
})
export class ProfileComponent implements OnInit {
  profile: UserProfile | null = null;
  editForm: FormGroup;
  isEditing = false;
  isSubmitting = false;
  error: string | null = null;
  loading: boolean = true;

  constructor(
    private userService: UserService,
    private authService: AuthService,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.editForm = this.fb.group({
      name: ['', Validators.required],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]]
    });
  }

  get userInitials(): string {
    if (!this.profile?.name) {
      return '';
    }
    
    return this.profile.name
      .split(' ')
      .map((n: string) => n[0])
      .join('')
      .toUpperCase();
  }

  ngOnInit(): void {
    if (!this.authService.isAuthenticated()) {
      this.router.navigate(['/login']);
      return;
    }
    
    // Only force refresh when explicitly needed
    this.loadProfile(false);
  }

  loadProfile(forceRefresh: boolean = false): void {
    this.error = null;
    this.loading = true;
    
    this.userService.getUserProfile(forceRefresh).subscribe({
      next: (data: UserProfile) => {
        this.profile = data;
        this.editForm.patchValue({
          name: data.name,
          contactNumber: data.contactNumber
        });
        this.loading = false;
      },
      error: (error: Error) => {
        console.error('Error loading profile:', error);
        this.error = error.message;
        this.loading = false;
        if (error.message === 'No authenticated user found') {
          this.router.navigate(['/login']);
        }
      }
    });
  }

  startEdit(): void {
    this.isEditing = true;
  }

  cancelEdit(): void {
    this.isEditing = false;
    this.editForm.patchValue({
      name: this.profile?.name,
      contactNumber: this.profile?.contactNumber
    });
  }

  onSubmit(): void {
    if (this.editForm.valid) {
      this.isSubmitting = true;
      const updateData: Partial<UserProfile> = {
        name: this.editForm.value.name,
        contactNumber: this.editForm.value.contactNumber,
        userType: this.profile?.userType
      };

      this.userService.updateUserProfile(updateData).subscribe({
        next: () => {
          this.isEditing = false;
          this.isSubmitting = false;
          this.loadProfile(); // Reload profile after update
        },
        error: (error: unknown) => {
          console.error('Error updating profile:', error);
          this.isSubmitting = false;
          this.error = 'Failed to update profile. Please try again later.';
        }
      });
    }
  }
}
