import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/authServices/auth.service';

interface Notification {
  notificationID: number;
  userID: number;
  eventID: number;
  message: string;
  sentTimestamp: string;
}

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  notifications: Notification[] = [];
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149';

  constructor(
    private http: HttpClient,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loadNotifications();
  }

  private loadNotifications() {
    const userId = this.authService.getUserId();
    if (!userId) {
      this.error = 'Please login to view notifications';
      this.loading = false;
      return;
    }

    this.http.get<Notification[]>(`${this.baseUrl}/api/Notification/user/${userId}`)
      .subscribe({
        next: (response) => {
          this.notifications = response.sort((a, b) =>
            new Date(b.sentTimestamp).getTime() - new Date(a.sentTimestamp).getTime()
          );
          this.loading = false;
        },
        error: (error) => {
          console.error('Error loading notifications:', error);
          this.error = 'Failed to load notifications';
          this.loading = false;
        }
      });
  }

  viewEvent(eventId: number) {
    this.router.navigate(['/user/events', eventId]);
  }

  getTimeAgo(timestamp: string): string {
    const now = new Date();
    const sentTime = new Date(timestamp);
    const diff = now.getTime() - sentTime.getTime();

    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    return 'Just now';
  }

  getNotificationIcon(message: string): string {
    if (message.toLowerCase().includes('confirmed')) return 'bi-check-circle-fill text-success';
    if (message.toLowerCase().includes('cancelled')) return 'bi-x-circle-fill text-danger';
    return 'bi-bell-fill text-primary';
  }
}
