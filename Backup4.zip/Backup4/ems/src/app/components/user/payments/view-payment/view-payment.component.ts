import { Component } from '@angular/core';

@Component({
  selector: 'app-view-payment',
  imports: [],
  templateUrl: './view-payment.component.html',
  styleUrl: './view-payment.component.css'
})
export class ViewPaymentComponent {

}
