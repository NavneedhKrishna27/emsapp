// src/app/core/authServices/auth.service.ts
import { Injectable, PLATFORM_ID, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, Observable, throwError, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { LoginRequest, RegisterRequest, AuthResponse } from '../../interfaces/auth.interface';
import { UserProfile } from '../../interfaces/user.interface';
import { jwtDecode } from 'jwt-decode';

interface DecodedToken {
  nameidentifier?: string;
  userId?: string;
  UserID: string;
  email: string;
  role: string;
  nbf: number;
  exp: number;
  iat: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly TOKEN_KEY = 'token';
  private readonly USER_KEY = 'user';
  private readonly API_URL = 'https://localhost:7149/api';
  private isBrowser: boolean;
  
  private currentUserSubject = new BehaviorSubject<DecodedToken | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    @Inject(PLATFORM_ID) platformId: Object
  ) {
    this.isBrowser = isPlatformBrowser(platformId);
    this.initializeAuth();
  }

  private initializeAuth(): void {
    if (!this.isBrowser) {
      return;
    }

    const token = localStorage.getItem(this.TOKEN_KEY);
    const userData = localStorage.getItem(this.USER_KEY);
    
    if (token && userData) {
      try {
        const decodedToken = jwtDecode<DecodedToken>(token);
        const now = Date.now() / 1000;
        
        if (decodedToken.exp > now) {
          this.currentUserSubject.next(decodedToken);
        } else {
          this.logout();
        }
      } catch (error) {
        this.logout();
      }
    }
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.API_URL}/Auth/login`, credentials)
      .pipe(
        tap(response => {
          const decodedToken = jwtDecode<DecodedToken>(response.token);
          localStorage.setItem(this.TOKEN_KEY, response.token);
          localStorage.setItem(this.USER_KEY, JSON.stringify(decodedToken));
          this.currentUserSubject.next(decodedToken);
        }),
        catchError(error => {
          console.error('Login error:', error);
          return throwError(() => new Error('Login failed'));
        })
      );
  }

  register(userData: RegisterRequest): Observable<any> {
    return this.http.post<any>(`${this.API_URL}/Auth/register`, userData)
      .pipe(
        tap(response => {
          // Check if registration was successful (status 200)
          if (response) {
            // You can add additional handling here if needed
            console.log('Registration successful:', response);
          }
        }),
        catchError(error => {
          // If it's a successful response but treated as error
          if (error.status === 200) {
            return of(error.error); // Return the response
          }
          console.error('Registration error:', error);
          return throwError(() => new Error('Registration failed'));
        })
      );
  }

  logout(): void {
    if (this.isBrowser) {
      localStorage.removeItem(this.TOKEN_KEY);
      localStorage.removeItem(this.USER_KEY);
    }
    this.currentUserSubject.next(null);
  }

  getToken(): string | null {
    return this.isBrowser ? localStorage.getItem(this.TOKEN_KEY) : null;
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) return false;

    try {
      const decodedToken = jwtDecode<DecodedToken>(token);
      const now = Date.now() / 1000;
      return decodedToken.exp > now;
    } catch {
      return false;
    }
  }

  getUserId(): number | null {
    const currentUser = this.currentUserSubject.value;
    return currentUser ? parseInt(currentUser.UserID) : null;
  }

  getRole(): string | null {
    const currentUser = this.currentUserSubject.value;
    return currentUser ? currentUser.role : null;
  }

  getUserEmail(): string | null {
    const currentUser = this.currentUserSubject.value;
    return currentUser ? currentUser.email : null;
  }
}