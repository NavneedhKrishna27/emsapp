import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {
  private readonly baseUrl = 'https://localhost:7149/api';

  constructor(private http: HttpClient) {}

  async processFileUpload(file: File, eventName: string, type: string): Promise<string> {
    try {
      // Create form data
      const formData = new FormData();
      formData.append('file', file);
      formData.append('eventName', eventName);
      formData.append('fileType', type);

      // Upload file to server
      const response = await this.http.post<{path: string}>(
        `${this.baseUrl}/Event/upload-file`,
        formData
      ).toPromise();

      if (!response?.path) {
        throw new Error('Invalid server response');
      }

      // Store preview URL
      const blobUrl = URL.createObjectURL(file);
      sessionStorage.setItem('preview_' + response.path, blobUrl);

      return response.path;
    } catch (error) {
      console.error('Error uploading file:', error);
      throw new Error('Failed to upload file');
    }
  }

  async cleanup(filePath: string): Promise<void> {
    const previewUrl = sessionStorage.getItem('preview_' + filePath);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      sessionStorage.removeItem('preview_' + filePath);
    }
  }

  async deleteEventFiles(eventId: number): Promise<void> {
    try {
      await this.http.delete(`${this.baseUrl}/Event/delete-files/${eventId}`).toPromise();
    } catch (error) {
      console.error('Error deleting event files:', error);
      throw new Error('Failed to delete event files');
    }
  }
}
