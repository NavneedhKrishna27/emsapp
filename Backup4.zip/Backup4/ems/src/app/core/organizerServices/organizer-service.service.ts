import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../authServices/auth.service';

export interface OrganizerProfile {
  name: string;
  contactNumber: string;
  email?: string;
  userType: string;
  totalEvents: number;
  ongoingEvents: number;
  upcomingEvents: number;
  completedEvents: number;
  totalRevenue: number;
  totalTicketsSold: number;
}

export interface UpdateProfileRequest {
  name: string;
  contactNumber: string;
  userType: string;
}

@Injectable({
  providedIn: 'root'
})
export class OrganizerService {
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  getOrganizerProfile(userId: number): Observable<OrganizerProfile> {
    return this.http.get<OrganizerProfile>(
      `${this.baseUrl}/user/${userId}`,
      { headers: this.getHeaders() }
    );
  }

  updateOrganizerProfile(userId: string, data: UpdateProfileRequest): Observable<any> {
    return this.http.put<any>(`https://localhost:7149/api/user/${userId}`, data);
  }
}
