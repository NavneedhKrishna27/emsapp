import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from '../authServices/auth.service';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  uploadEventImages(eventId: number, formData: FormData): Observable<any> {
    return this.http.post(
      `${this.baseUrl}/Event/${eventId}/images`,
      formData,
      { headers: this.getHeaders() }
    );
  }
}