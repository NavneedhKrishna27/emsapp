export interface UserProfile {
  userID: number;
  name: string;
  email: string;
  contactNumber: string;
  userType: string;
}