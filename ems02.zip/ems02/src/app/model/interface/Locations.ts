export interface Ilocations {
  locationID: number;
  locationName: string;
}
