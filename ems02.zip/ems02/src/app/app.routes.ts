import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'organizer',
    loadChildren: () => import('./modules/organizer/organizer.routes').then(m => m.ORGANIZER_ROUTES)
  },
  {
    path: 'user',
    loadChildren: () => import('./modules/user/user.routes').then(m => m.USER_ROUTES)
  },
  {
    path: '',
    redirectTo: 'user',
    pathMatch: 'full'
  }
];
