import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';

interface Event {
  eventID: number;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  locationID: number;
  categoryID: number;
  price: number;
  isPrice: boolean;
  bookedCapacity: number;
}

interface Feedback {
  feedbackID: number;
  eventID: number;
  userID: number;
  rating: number;
  comments: string;
  submittedTimestamp: string;
}

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
  description: string;
}

interface EventStats {
  revenue: number;
  ticketsSold: number;
  ticketsPercentage: number;
  revenuePercentage: number;
}

@Component({
  selector: 'app-view-event',
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule]
})
export class ViewEventComponent implements OnInit {
  eventId!: number;
  event: Event | null = null;
  feedbacks: Feedback[] = [];
  averageRating: number = 0;
  location: Location | null = null;
  category: Category | null = null;
  stats: EventStats = {
    revenue: 0,
    ticketsSold: 0,
    ticketsPercentage: 0,
    revenuePercentage: 0
  };
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.eventId = parseInt(this.route.snapshot.paramMap.get('id') || '0', 10);
    this.fetchEventDetails();
  }

  private async fetchEventDetails() {
    try {
      // First fetch event to get IDs
      const event = await this.http.get<Event>(`${this.baseUrl}/Event/view-event/${this.eventId}`).toPromise();

      if (!event) {
        throw new Error('Event not found');
      }

      // Then fetch all related data
      const [feedbacks, rating, location, category, revenue, tickets] = await Promise.all([
        this.http.get<Feedback[]>(`${this.baseUrl}/Feedback?eventid=${this.eventId}`).toPromise(),
        this.http.get<{averageRating: number}>(`${this.baseUrl}/Feedback/average-rating/${this.eventId}`).toPromise(),
        this.http.get<Location>(`${this.baseUrl}/Location/${event.locationID}`).toPromise(),
        this.http.get<Category>(`${this.baseUrl}/Categories/${event.categoryID}`).toPromise(),
        this.http.get<number>(`${this.baseUrl}/Event/${this.eventId}/revenue`).toPromise(),
        this.http.get<number>(`${this.baseUrl}/Event/${this.eventId}/tickets-sold`).toPromise()
      ]);

      this.event = event;
      this.feedbacks = feedbacks || [];
      this.averageRating = rating?.averageRating || 0;
      this.location = location || null;
      this.category = category || null;

      // Calculate stats with proper type checking
      if (this.location && this.event) {
        const ticketsCount = tickets || 0;
        const revenueAmount = revenue || 0;

        this.stats = {
          revenue: revenueAmount,
          ticketsSold: ticketsCount,
          ticketsPercentage: this.location.capacity > 0 ?
            (ticketsCount / this.location.capacity) * 100 : 0,
          revenuePercentage: this.event.isPrice && this.location.capacity > 0 ?
            (revenueAmount / (this.event.price * this.location.capacity)) * 100 : 0
        };
      }

      this.loading = false;
    } catch (error) {
      console.error('Error fetching event details:', error);
      this.error = 'Failed to load event details';
      this.loading = false;
    }
  }

  isEventCompleted(): boolean {
    if (!this.event) return false;
    const endDate = new Date(this.event.endDate);
    return endDate < new Date();
  }

  getRatingStars(rating: number): string[] {
    return Array(5).fill(0).map((_, index) =>
      index < Math.floor(rating) ? 'bi-star-fill' : 'bi-star');
  }

  getProgressBarClass(percentage: number): string {
    if (percentage < 25) return 'bg-danger';
    if (percentage < 75) return 'bg-warning';
    return 'bg-success';
  }

  getEventStatus(): string {
    if (!this.event) return 'Unknown';
    const now = new Date();
    const startDate = new Date(this.event.startDate);
    const endDate = new Date(this.event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getStatusClass(): string {
    const status = this.getEventStatus();
    switch (status.toLowerCase()) {
      case 'active': return 'bg-warning text-dark';
      case 'completed': return 'bg-success';
      case 'upcoming': return 'bg-primary';
      default: return 'bg-secondary';
    }
  }
}
