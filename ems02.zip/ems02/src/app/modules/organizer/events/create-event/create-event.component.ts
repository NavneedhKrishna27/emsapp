import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface Location {
  locationID: number;
  locationName: string;
}

interface Category {
  categoryID: number;
  categoryName: string;
}

interface CreateEventRequest {
  eventID: number;
  name: string;
  categoryID: number;
  locationID: number;
  startDate: string;
  endDate: string;
  userID: number;
  description: string;
  isPrice: boolean;
  price: number;
  isActive: boolean;
  bookedCapacity: number;
}

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class CreateEventComponent implements OnInit {
  eventForm!: FormGroup;
  loading = true;
  error: string | null = null;
  locations: Location[] = [];
  categories: Category[] = [];
  private baseUrl = 'https://localhost:7149/api';

  constructor(
    private router: Router,
    private http: HttpClient,
    private fb: FormBuilder
  ) {}

  ngOnInit() {
    this.initForm();
    this.fetchData();
  }

  private initForm() {
    this.eventForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3)]],
      categoryID: ['', Validators.required],
      locationID: ['', Validators.required],
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      description: ['', Validators.required],
      isPrice: [false],
      price: [0]
    });
  }

  private async fetchData() {
    try {
      const [locations, categories] = await Promise.all([
        this.http.get<Location[]>(`${this.baseUrl}/Location`).toPromise(),
        this.http.get<Category[]>(`${this.baseUrl}/Categories`).toPromise()
      ]);

      if (locations && categories) {
        this.locations = locations;
        this.categories = categories;
        this.loading = false;
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      this.error = 'Failed to load required data';
      this.loading = false;
    }
  }

  onSubmit() {
    if (this.eventForm.valid) {
      const formValue = this.eventForm.value;

      const eventData: CreateEventRequest = {
        eventID: 0,
        name: formValue.name,
        categoryID: parseInt(formValue.categoryID),
        locationID: parseInt(formValue.locationID),
        startDate: new Date(formValue.startDate).toISOString(),
        endDate: new Date(formValue.endDate).toISOString(),
        userID: 1, // Replace with actual user ID
        description: formValue.description,
        isPrice: formValue.isPrice,
        price: formValue.isPrice ? formValue.price : 0,
        isActive: true,
        bookedCapacity: 0
      };

      this.loading = true;
      this.http.post(`${this.baseUrl}/Event/add-event`, eventData).subscribe({
        next: (response) => {
          this.loading = false; // Reset loading state
          alert('Event created successfully');
          this.router.navigate(['/events']);
        },
        error: (error) => {
          console.error('Error creating event:', error);
          this.error = 'Failed to create event. Please check all required fields.';
          this.loading = false; // Reset loading state on error
        },
        complete: () => {
          this.loading = false; // Ensure loading is reset even if something unexpected happens
        }
      });
    } else {
      this.markFormGroupTouched(this.eventForm);
    }
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
