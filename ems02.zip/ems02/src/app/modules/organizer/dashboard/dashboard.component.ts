import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { forkJoin } from 'rxjs';
import { Router } from '@angular/router';

interface DashboardStats {
  totalEvents: number;
  activeEvents: number;
  upcomingEvents: number;
  completedEvents: number;
  totalRevenue: number;
  totalTicketsSold: number;
}

interface Location {
  locationID: number;
  locationName: string;
  capacity: number;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  primaryContact: string;
  secondaryContact: string;
}

interface Event {
  eventID: number;
  name: string;
  startDate: string;
  endDate: string;
  isPrice: boolean;
  price: number;
  bookedCapacity: number;
  locationID: number; // Add this
  capacity?: number; // This will be set from location capacity
}

interface EventProgress {
  event: Event;
  revenue: number;
  ticketsSold: number;
  revenuePercentage: number;
  ticketsPercentage: number;
  maxPossibleRevenue: number;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  stats: DashboardStats = {
    totalEvents: 0,
    activeEvents: 0,
    upcomingEvents: 0,
    completedEvents: 0,
    totalRevenue: 0,
    totalTicketsSold: 0
  };

  recentEvents: Event[] = [];
  eventProgress: EventProgress[] = [];
  loading = true;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';

  sortBy: string = 'name';
  sortDirection: 'asc' | 'desc' = 'asc';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit() {
    this.fetchDashboardData();
  }

  private async calculateEventProgress(events: Event[]) {
    const progress: EventProgress[] = [];
    let totalRevenue = 0;
    let totalTickets = 0;

    for (const event of events) {
      try {
        const [revenue, tickets, location] = await Promise.all([
          this.http.get<number>(`${this.baseUrl}/Event/${event.eventID}/revenue`).toPromise(),
          this.http.get<number>(`${this.baseUrl}/Event/${event.eventID}/tickets-sold`).toPromise(),
          this.http.get<Location>(`${this.baseUrl}/Location/${event.locationID}`).toPromise()
        ]);

        const maxCapacity = location?.capacity || 0;
        const maxPossibleRevenue = event.isPrice ? event.price * maxCapacity : 0;

        progress.push({
          event: { ...event, capacity: maxCapacity },
          revenue: revenue || 0,
          ticketsSold: tickets || 0,
          revenuePercentage: maxPossibleRevenue > 0 ? ((revenue || 0) / maxPossibleRevenue) * 100 : 0,
          ticketsPercentage: ((tickets || 0) / maxCapacity) * 100,
          maxPossibleRevenue
        });

        totalRevenue += revenue || 0;
        totalTickets += tickets || 0;
      } catch (error) {
        console.error(`Error processing event ${event.eventID}:`, error);
      }
    }

    return { progress, totalRevenue, totalTickets };
  }

  private fetchDashboardData() {
    forkJoin({
      current: this.http.get<Event[]>(`${this.baseUrl}/Event/current`),
      upcoming: this.http.get<Event[]>(`${this.baseUrl}/Event/upcoming`),
      completed: this.http.get<Event[]>(`${this.baseUrl}/Event/completed`)
    }).subscribe({
      next: async (data) => {
        this.stats.activeEvents = data.current.length;
        this.stats.upcomingEvents = data.upcoming.length;
        this.stats.completedEvents = data.completed.length;
        this.stats.totalEvents = this.stats.activeEvents + this.stats.upcomingEvents + this.stats.completedEvents;

        // Get all events
        const allEvents = [...data.current, ...data.upcoming, ...data.completed];

        // Calculate totals
        try {
          const { progress, totalRevenue, totalTickets } = await this.calculateEventProgress(allEvents);

          this.eventProgress = progress;
          this.stats.totalRevenue = totalRevenue;
          this.stats.totalTicketsSold = totalTickets;

          // Sort by start date and get recent events
          this.recentEvents = [...data.current, ...data.upcoming]
            .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
            .slice(0, 5);

        } catch (error) {
          console.error('Error calculating progress:', error);
          this.error = 'Failed to calculate event progress';
        }

        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching dashboard data:', error);
        this.error = 'Failed to load dashboard data';
        this.loading = false;
      }
    });
  }

  getEventStatus(event: Event): string {
    const now = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'active': return 'badge-active';
      case 'completed': return 'badge-completed';
      case 'upcoming': return 'badge-upcoming';
      default: return '';
    }
  }

  getStatusIcon(event: Event): string {
    const status = this.getEventStatus(event).toLowerCase();
    switch (status) {
      case 'active':
        return 'bi-play-circle-fill';
      case 'upcoming':
        return 'bi-calendar-event';
      case 'completed':
        return 'bi-check-circle-fill';
      default:
        return 'bi-question-circle';
    }
  }

  getProgressBarClass(percentage: number): string {
    if (percentage < 25) return 'bg-danger';
    if (percentage < 75) return 'bg-warning';
    return 'bg-success';
  }

  get sortedEventProgress(): EventProgress[] {
    return [...this.eventProgress].sort((a, b) => {
      let comparison = 0;
      switch (this.sortBy) {
        case 'name':
          comparison = a.event.name.localeCompare(b.event.name);
          break;
        case 'revenue':
          comparison = a.revenue - b.revenue;
          break;
        case 'tickets':
          comparison = a.ticketsSold - b.ticketsSold;
          break;
        case 'status':
          comparison = this.getEventStatus(a.event).localeCompare(this.getEventStatus(b.event));
          break;
      }
      return this.sortDirection === 'asc' ? comparison : -comparison;
    });
  }

  sortEvents(criteria: string) {
    if (this.sortBy === criteria) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortBy = criteria;
      this.sortDirection = 'asc';
    }
  }

  getSortIcon(column: string): string {
    if (this.sortBy !== column) return 'bi-arrow-down-up';
    return this.sortDirection === 'asc' ? 'bi-arrow-up' : 'bi-arrow-down';
  }

  viewEvent(eventId: number) {
    this.router.navigate(['/events/view', eventId]);
  }
}
