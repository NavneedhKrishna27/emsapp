import { Component } from '@angular/core';

@Component({
  selector: 'app-organizer',
  imports: [],
  templateUrl: './organizer.component.html',
  styleUrl: './organizer.component.css'
})
export class OrganizerComponent {

}
