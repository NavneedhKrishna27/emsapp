import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgSelectModule } from '@ng-select/ng-select';

interface Event {
  eventID: number;
  name: string;
  startDate: string;
  endDate: string;
  isPrice: boolean;
  price: number;
  bookedCapacity: number;
  locationID: number;
}

interface EventReport {
  eventId: number;
  eventName: string;
  ticketsSold: number;
  totalTickets: number;
  revenue: number;
  targetRevenue: number;
  profit: number;
  targetProfit: number;
  feedbacks: Feedback[];
  status: 'Upcoming' | 'Active' | 'Completed';
  startDate: string;
  endDate: string;
  totalRevenue: number;
  averageTicketPrice: number;
  bookingRate: number;
  peakBookingTime?: string;
  categoryName?: string;
  locationDetails: {
    name: string;
    address: string;
    capacity: number;
    utilization: number;
  };
  statistics: {
    dailyBookings: { date: string; count: number }[];
    revenueByDay: { date: string; amount: number }[];
  };
}

interface Feedback {
  customerName: string;
  rating: number;
  comment: string;
  date: string;
}

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule, NgSelectModule],
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  selectedEventId: number | null = null;
  events: Event[] = [];
  eventReport: EventReport | null = null;
  loading = false;
  error: string | null = null;
  private baseUrl = 'https://localhost:7149/api';
  searchTerm: string = '';
  defaultEventId: number = 1; // Set your default event ID

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchEvents();
    // Load default event
    if (this.defaultEventId) {
      this.fetchEventReport(this.defaultEventId);
    }
  }

  fetchEvents() {
    this.loading = true;
    this.http.get<Event[]>(`${this.baseUrl}/Event/index`).subscribe({
      next: (events) => {
        if (!events || events.length === 0) {
          this.error = 'No events found';
        } else {
          this.events = events;
          this.error = null;
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error fetching events:', error);
        this.error = 'Failed to load events. Please try again later.';
        this.loading = false;
      }
    });
  }

  onEventChange(selectedEvent: any) {
    if (selectedEvent) {
      this.loading = true;
      this.selectedEventId = selectedEvent.eventID;
      this.fetchEventReport(selectedEvent.eventID);
    } else {
      this.eventReport = null;
    }
  }

  private async fetchEventReport(eventId: number) {
    try {
      const event = await this.http.get<Event>(`${this.baseUrl}/Event/view-event/${eventId}`).toPromise();
      if (!event) throw new Error('Event not found');

      const [revenue, tickets, location] = await Promise.all([
        this.http.get<number>(`${this.baseUrl}/Event/${eventId}/revenue`).toPromise(),
        this.http.get<number>(`${this.baseUrl}/Event/${eventId}/tickets-sold`).toPromise(),
        this.http.get<any>(`${this.baseUrl}/Location/${event.locationID}`).toPromise()
      ]);

      // Calculate target revenue and profit
      const targetRevenue = event.isPrice ? event.price * location.capacity : 0;
      const targetProfit = targetRevenue * 0.7; // Assuming 30% operational costs

      this.eventReport = {
        eventId: event.eventID,
        eventName: event.name,
        ticketsSold: tickets || 0,
        totalTickets: location.capacity,
        revenue: revenue || 0,
        targetRevenue: targetRevenue,
        profit: (revenue || 0) * 0.7,
        targetProfit: targetProfit,
        feedbacks: [],
        status: this.getEventStatus(event),
        startDate: event.startDate,
        endDate: event.endDate,
        totalRevenue: revenue || 0,
        averageTicketPrice: tickets ? (revenue || 0) / tickets : 0,
        bookingRate: tickets ? (tickets / location.capacity) * 100 : 0,
        locationDetails: {
          name: location.name,
          address: location.address,
          capacity: location.capacity,
          utilization: tickets ? (tickets / location.capacity) * 100 : 0
        },
        statistics: {
          dailyBookings: [],
          revenueByDay: []
        }
      };

      // Fetch feedbacks if event is completed
      if (this.eventReport.status === 'Completed') {
        const feedbacks = await this.http.get<Feedback[]>(`${this.baseUrl}/Feedback?eventid=${eventId}`).toPromise();
        this.eventReport.feedbacks = feedbacks || [];
      }

    } catch (error) {
      console.error('Error fetching report:', error);
      this.error = 'Failed to load report';
    } finally {
      this.loading = false;
    }
  }

  getEventStatus(event: Event): 'Upcoming' | 'Active' | 'Completed' {
    const now = new Date();
    const startDate = new Date(event.startDate);
    const endDate = new Date(event.endDate);

    if (now < startDate) return 'Upcoming';
    if (now > endDate) return 'Completed';
    return 'Active';
  }

  getProgressClass(percentage: number): string {
    if (percentage >= 90) return 'bg-success';
    if (percentage >= 60) return 'bg-info';
    if (percentage >= 30) return 'bg-warning';
    return 'bg-danger';
  }

  getProgressBarClass(percentage: number): string {
    if (percentage >= 90) {
      return 'bg-success';
    } else if (percentage >= 60) {
      return 'bg-info';
    } else if (percentage >= 30) {
      return 'bg-warning';
    } else {
      return 'bg-danger';
    }
  }

  downloadReport() {
    if (!this.eventReport) return;

    const reportData = {
      ...this.eventReport,
      generatedDate: new Date().toISOString(),
      ticketProgress: this.getTicketProgress(),
      revenueProgress: this.getRevenueProgress(),
      profitProgress: this.getProfitProgress()
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `event-report-${this.eventReport.eventId}.json`;
    link.click();
    window.URL.revokeObjectURL(url);
  }

  getTicketProgress(): number {
    if (!this.eventReport || !this.eventReport.totalTickets) return 0;
    return (this.eventReport.ticketsSold / this.eventReport.totalTickets) * 100;
  }

  getRevenueProgress(): number {
    if (!this.eventReport || !this.eventReport.targetRevenue) return 0;
    return (this.eventReport.revenue / this.eventReport.targetRevenue) * 100;
  }

  getProfitProgress(): number {
    if (!this.eventReport || !this.eventReport.targetProfit) return 0;
    return (this.eventReport.profit / this.eventReport.targetProfit) * 100;
  }

  getRatingStars(rating: number): string[] {
    return Array(5).fill(0).map((_, index) =>
      index < rating ? 'bi-star-fill' : 'bi-star');
  }

  get filteredEvents() {
    return this.events.filter(event =>
      event.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  onSearch(searchTerm: string) {
    if (searchTerm) {
      this.loading = true;
      const filteredEvents = this.events.filter(event =>
        event.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      this.events = filteredEvents;
      this.loading = false;
    } else {
      this.fetchEvents();
    }
  }
}
